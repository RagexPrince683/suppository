package mcheli;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.gltd.MCH_EntityGLTD;
import mcheli.uav.MCH_EntityUavStation;
import mcheli.wrapper.W_EntityRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemRenderer;

@SideOnly(Side.CLIENT)
public class MCH_ItemRendererDummy extends ItemRenderer {

    protected static Minecraft mc;
    protected static ItemRenderer backupItemRenderer;
    protected static MCH_ItemRendererDummy instance;

    public MCH_ItemRendererDummy(Minecraft par1Minecraft) {
        super(par1Minecraft);
        MCH_ItemRendererDummy.mc = par1Minecraft;
    }

    public void renderItemInFirstPerson(float par1) {
        if (MCH_ItemRendererDummy.mc.thePlayer == null) {
            super.renderItemInFirstPerson(par1);
        } else if (!(MCH_ItemRendererDummy.mc.thePlayer.ridingEntity instanceof MCH_EntityAircraft) && !(MCH_ItemRendererDummy.mc.thePlayer.ridingEntity instanceof MCH_EntityUavStation) && !(MCH_ItemRendererDummy.mc.thePlayer.ridingEntity instanceof MCH_EntityGLTD)) {
            super.renderItemInFirstPerson(par1);
        }

    }

    public static void enableDummyItemRenderer() {
        if (MCH_ItemRendererDummy.instance == null) {
            MCH_ItemRendererDummy.instance = new MCH_ItemRendererDummy(Minecraft.getMinecraft());
        }

        if (!(MCH_ItemRendererDummy.mc.entityRenderer.itemRenderer instanceof MCH_ItemRendererDummy)) {
            MCH_ItemRendererDummy.backupItemRenderer = MCH_ItemRendererDummy.mc.entityRenderer.itemRenderer;
        }

        W_EntityRenderer.setItemRenderer(MCH_ItemRendererDummy.mc, MCH_ItemRendererDummy.instance);
    }

    public static void disableDummyItemRenderer() {
        if (MCH_ItemRendererDummy.backupItemRenderer != null) {
            W_EntityRenderer.setItemRenderer(MCH_ItemRendererDummy.mc, MCH_ItemRendererDummy.backupItemRenderer);
        }

    }
}

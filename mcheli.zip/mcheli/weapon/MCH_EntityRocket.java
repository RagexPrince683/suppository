package mcheli.weapon;

import net.minecraft.world.World;

public class MCH_EntityRocket extends MCH_EntityBaseBullet {

    public MCH_EntityRocket(World par1World) {
        super(par1World);
    }

    public MCH_EntityRocket(World par1World, double posX, double posY, double posZ, double targetX, double targetY, double targetZ, float yaw, float pitch, double acceleration) {
        super(par1World, posX, posY, posZ, targetX, targetY, targetZ, yaw, pitch, acceleration);
    }

    public void onUpdate() {
        super.onUpdate();
        this.onUpdateBomblet();
        if (this.isBomblet <= 0 && this.getInfo() != null && !this.getInfo().disableSmoke) {
            this.spawnParticle(this.getInfo().trajectoryParticleName, 3, 5.0F * this.getInfo().smokeSize * 0.5F);
        }

    }

    public void sprinkleBomblet() {
        if (!this.worldObj.isRemote) {
            MCH_EntityRocket e = new MCH_EntityRocket(this.worldObj, this.posX, this.posY, this.posZ, this.motionX, this.motionY, this.motionZ, this.rotationYaw, this.rotationPitch, this.acceleration);

            e.setName(this.getName());
            e.setParameterFromWeapon((MCH_EntityBaseBullet) this, this.shootingAircraft, this.shootingEntity);
            float MOTION = this.getInfo().bombletDiff;
            float RANDOM = 1.2F;

            e.motionX += ((double) this.rand.nextFloat() - 0.5D) * (double) MOTION;
            e.motionY += ((double) this.rand.nextFloat() - 0.5D) * (double) MOTION;
            e.motionZ += ((double) this.rand.nextFloat() - 0.5D) * (double) MOTION;
            e.setBomblet();
            this.worldObj.spawnEntityInWorld(e);
        }

    }

    public MCH_BulletModel getDefaultBulletModel() {
        return MCH_DefaultBulletModels.Rocket;
    }
}

package mcheli.weapon;

import net.minecraft.entity.Entity;

public interface MCH_IEntityLockChecker {

    boolean canLockEntity(Entity entity);
}

package mcheli.weapon;

import mcheli.wrapper.W_WorldFunc;
import net.minecraft.block.Block;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class MCH_EntityASMissile extends MCH_EntityBaseBullet {

    public double targetPosX;
    public double targetPosY;
    public double targetPosZ;

    public MCH_EntityASMissile(World par1World) {
        super(par1World);
        this.targetPosX = 0.0D;
        this.targetPosY = 0.0D;
        this.targetPosZ = 0.0D;
    }

    public float getGravity() {
        return this.getBomblet() == 1 ? -0.03F : super.getGravity();
    }

    public float getGravityInWater() {
        return this.getBomblet() == 1 ? -0.03F : super.getGravityInWater();
    }

    public void onUpdate() {
        super.onUpdate();
        if (this.getInfo() != null && !this.getInfo().disableSmoke && this.getBomblet() == 0) {
            this.spawnParticle(this.getInfo().trajectoryParticleName, 3, 10.0F * this.getInfo().smokeSize * 0.5F);
        }

        if (this.getInfo() != null && !this.worldObj.isRemote && this.isBomblet != 1) {
            Block a = W_WorldFunc.getBlock(this.worldObj, (int) this.targetPosX, (int) this.targetPosY, (int) this.targetPosZ);

            if (a != null && a.isCollidable()) {
                double dist = this.getDistance(this.targetPosX, this.targetPosY, this.targetPosZ);

                if (dist < (double) this.getInfo().proximityFuseDist) {
                    if (this.getInfo().bomblet > 0) {
                        for (int x = 0; x < this.getInfo().bomblet; ++x) {
                            this.sprinkleBomblet();
                        }
                    } else {
                        MovingObjectPosition movingobjectposition = new MovingObjectPosition(this);

                        this.onImpact(movingobjectposition, 1.0F);
                    }

                    this.setDead();
                } else {
                    double y;
                    double z;
                    double d;
                    double d0;

                    if ((double) this.getGravity() == 0.0D) {
                        d0 = 0.0D;
                        if (this.getCountOnUpdate() < 10) {
                            d0 = 20.0D;
                        }

                        y = this.targetPosX - this.posX;
                        z = this.targetPosY + d0 - this.posY;
                        d = this.targetPosZ - this.posZ;
                        double d1 = (double) MathHelper.sqrt_double(y * y + z * z + d * d);

                        this.motionX = y * this.acceleration / d1;
                        this.motionY = z * this.acceleration / d1;
                        this.motionZ = d * this.acceleration / d1;
                    } else {
                        d0 = this.targetPosX - this.posX;
                        y = this.targetPosY - this.posY;
                        y *= 0.3D;
                        z = this.targetPosZ - this.posZ;
                        d = (double) MathHelper.sqrt_double(d0 * d0 + y * y + z * z);
                        this.motionX = d0 * this.acceleration / d;
                        this.motionZ = z * this.acceleration / d;
                    }
                }
            }
        }

        double d1 = (double) ((float) Math.atan2(this.motionZ, this.motionX));

        this.rotationYaw = (float) (d1 * 180.0D / 3.141592653589793D) - 90.0F;
        double r = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);

        this.rotationPitch = -((float) (Math.atan2(this.motionY, r) * 180.0D / 3.141592653589793D));
        this.onUpdateBomblet();
    }

    public void sprinkleBomblet() {
        if (!this.worldObj.isRemote) {
            MCH_EntityASMissile e = new MCH_EntityASMissile(this.worldObj, this.posX, this.posY, this.posZ, this.motionX, this.motionY, this.motionZ, (float) this.rand.nextInt(360), 0.0F, this.acceleration);

            e.setParameterFromWeapon((MCH_EntityBaseBullet) this, this.shootingAircraft, this.shootingEntity);
            e.setName(this.getName());
            float MOTION = 0.5F;
            float RANDOM = this.getInfo().bombletDiff;

            e.motionX = this.motionX * 0.5D + (double) ((this.rand.nextFloat() - 0.5F) * RANDOM);
            e.motionY = this.motionY * 0.5D / 2.0D + (double) ((this.rand.nextFloat() - 0.5F) * RANDOM / 2.0F);
            e.motionZ = this.motionZ * 0.5D + (double) ((this.rand.nextFloat() - 0.5F) * RANDOM);
            e.setBomblet();
            this.worldObj.spawnEntityInWorld(e);
        }

    }

    public MCH_EntityASMissile(World par1World, double posX, double posY, double posZ, double targetX, double targetY, double targetZ, float yaw, float pitch, double acceleration) {
        super(par1World, posX, posY, posZ, targetX, targetY, targetZ, yaw, pitch, acceleration);
    }

    public MCH_BulletModel getDefaultBulletModel() {
        return MCH_DefaultBulletModels.ASMissile;
    }
}

package mcheli.weapon;

import net.minecraftforge.client.model.IModelCustom;

public class MCH_BulletModel {

    public final String name;
    public final IModelCustom model;

    public MCH_BulletModel(String n, IModelCustom m) {
        this.name = n;
        this.model = m;
    }
}

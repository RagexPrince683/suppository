package mcheli.weapon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.wrapper.W_Item;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class MCH_WeaponInfoManager {

    private static MCH_WeaponInfoManager instance = new MCH_WeaponInfoManager();
    private static HashMap map;
    private static String lastPath;

    private MCH_WeaponInfoManager() {
        MCH_WeaponInfoManager.map = new HashMap();
    }

    public static boolean reload() {
        boolean ret = false;

        try {
            MCH_WeaponInfoManager.map.clear();
            ret = load(MCH_WeaponInfoManager.lastPath);
            setRoundItems();
            MCH_MOD.proxy.registerModels();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return ret;
    }

    public static boolean load(String path) {
        MCH_WeaponInfoManager.lastPath = path;
        path = path.replace('\\', '/');
        File dir = new File(path);
        File[] files = dir.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                String s = pathname.getName().toLowerCase();

                return pathname.isFile() && s.length() >= 5 && s.substring(s.length() - 4).compareTo(".txt") == 0;
            }
        });

        if (files != null && files.length > 0) {
            File[] arr$ = files;
            int len$ = files.length;

            for (int i$ = 0; i$ < len$; ++i$) {
                File f = arr$[i$];
                BufferedReader br = null;
                int line = 0;

                try {
                    String e = f.getName().toLowerCase();

                    e = e.substring(0, e.length() - 4);
                    if (!MCH_WeaponInfoManager.map.containsKey(e)) {
                        br = new BufferedReader(new FileReader(f));
                        MCH_WeaponInfo info = new MCH_WeaponInfo(e);

                        String str;

                        while ((str = br.readLine()) != null) {
                            ++line;
                            str = str.trim();
                            int eqIdx = str.indexOf(61);

                            if (eqIdx >= 0 && str.length() > eqIdx + 1) {
                                info.loadItemData(str.substring(0, eqIdx).trim().toLowerCase(), str.substring(eqIdx + 1).trim());
                            }
                        }

                        info.checkData();
                        MCH_WeaponInfoManager.map.put(e, info);
                    }
                } catch (IOException ioexception) {
                    if (line > 0) {
                        MCH_Lib.Log("### Load failed %s : line=%d", new Object[] { f.getName(), Integer.valueOf(line)});
                    } else {
                        MCH_Lib.Log("### Load failed %s", new Object[] { f.getName()});
                    }

                    ioexception.printStackTrace();
                } finally {
                    try {
                        if (br != null) {
                            br.close();
                        }
                    } catch (Exception exception) {
                        ;
                    }

                }
            }

            MCH_Lib.Log("[mcheli] Read %d weapons", new Object[] { Integer.valueOf(MCH_WeaponInfoManager.map.size())});
            return MCH_WeaponInfoManager.map.size() > 0;
        } else {
            return false;
        }
    }

    public static void setRoundItems() {
        Iterator i$ = MCH_WeaponInfoManager.map.values().iterator();

        while (i$.hasNext()) {
            MCH_WeaponInfo w = (MCH_WeaponInfo) i$.next();

            MCH_WeaponInfo.RoundItem r;
            Item item;

            for (Iterator i$1 = w.roundItems.iterator(); i$1.hasNext(); r.itemStack = new ItemStack(item, 1, r.damage)) {
                r = (MCH_WeaponInfo.RoundItem) i$1.next();
                item = W_Item.getItemByName(r.itemName);
            }
        }

    }

    public static MCH_WeaponInfo get(String name) {
        return (MCH_WeaponInfo) MCH_WeaponInfoManager.map.get(name);
    }

    public static boolean contains(String name) {
        return MCH_WeaponInfoManager.map.containsKey(name);
    }

    public static Set getKeySet() {
        return MCH_WeaponInfoManager.map.keySet();
    }

    public static Collection getValues() {
        return MCH_WeaponInfoManager.map.values();
    }
}

package mcheli.weapon;

import mcheli.MCH_Config;
import mcheli.MCH_MOD;
import mcheli.particles.MCH_ParticleParam;
import mcheli.particles.MCH_ParticlesUtil;
import mcheli.wrapper.W_Blocks;
import mcheli.wrapper.W_MovingObjectPosition;
import mcheli.wrapper.W_WorldFunc;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class MCH_EntityMarkerRocket extends MCH_EntityBaseBullet {

    public int countDown;

    public MCH_EntityMarkerRocket(World par1World) {
        super(par1World);
        this.setMarkerStatus(0);
        this.countDown = 0;
    }

    public MCH_EntityMarkerRocket(World par1World, double posX, double posY, double posZ, double targetX, double targetY, double targetZ, float yaw, float pitch, double acceleration) {
        super(par1World, posX, posY, posZ, targetX, targetY, targetZ, yaw, pitch, acceleration);
        this.setMarkerStatus(0);
        this.countDown = 0;
    }

    protected void entityInit() {
        super.entityInit();
        this.getDataWatcher().addObject(28, Byte.valueOf((byte) 0));
    }

    public void setMarkerStatus(int n) {
        if (!this.worldObj.isRemote) {
            this.getDataWatcher().updateObject(28, Byte.valueOf((byte) n));
        }

    }

    public int getMarkerStatus() {
        return this.getDataWatcher().getWatchableObjectByte(28);
    }

    public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
        return false;
    }

    public void onUpdate() {
        int status = this.getMarkerStatus();

        if (this.worldObj.isRemote) {
            if (this.getInfo() == null) {
                super.onUpdate();
            }

            if (this.getInfo() != null && !this.getInfo().disableSmoke && status != 0) {
                if (status == 1) {
                    super.onUpdate();
                    this.spawnParticle(this.getInfo().trajectoryParticleName, 3, 5.0F * this.getInfo().smokeSize * 0.5F);
                } else {
                    float num = this.rand.nextFloat() * 0.3F;

                    this.spawnParticle("explode", 5, (float) (10 + this.rand.nextInt(4)), this.rand.nextFloat() * 0.2F + 0.8F, num, num, (this.rand.nextFloat() - 0.5F) * 0.7F, 0.3F + this.rand.nextFloat() * 0.3F, (this.rand.nextFloat() - 0.5F) * 0.7F);
                }
            }
        } else if (status != 0 && !this.isInWater()) {
            if (status == 1) {
                super.onUpdate();
            } else if (this.countDown > 0) {
                --this.countDown;
                if (this.countDown == 40) {
                    int i = 6 + this.rand.nextInt(2);

                    for (int i = 0; i < i; ++i) {
                        MCH_EntityBomb e = new MCH_EntityBomb(this.worldObj, this.posX + (double) ((this.rand.nextFloat() - 0.5F) * 15.0F), (double) (260.0F + this.rand.nextFloat() * 10.0F + (float) (i * 30)), this.posZ + (double) ((this.rand.nextFloat() - 0.5F) * 15.0F), 0.0D, -0.5D, 0.0D, 0.0F, 90.0F, 4.0D);

                        e.setName(this.getName());
                        e.explosionPower = 3 + this.rand.nextInt(2);
                        e.explosionPowerInWater = 0;
                        e.setPower(30);
                        e.piercing = 0;
                        e.shootingAircraft = this.shootingAircraft;
                        e.shootingEntity = this.shootingEntity;
                        this.worldObj.spawnEntityInWorld(e);
                    }
                }
            } else {
                this.setDead();
            }
        } else {
            this.setDead();
        }

    }

    public void spawnParticle(String name, int num, float size, float r, float g, float b, float mx, float my, float mz) {
        if (this.worldObj.isRemote) {
            if (name.isEmpty() || num < 1 || num > 50) {
                return;
            }

            double x = (this.posX - this.prevPosX) / (double) num;
            double y = (this.posY - this.prevPosY) / (double) num;
            double z = (this.posZ - this.prevPosZ) / (double) num;

            for (int i = 0; i < num; ++i) {
                MCH_ParticleParam prm = new MCH_ParticleParam(this.worldObj, "smoke", this.prevPosX + x * (double) i, this.prevPosY + y * (double) i, this.prevPosZ + z * (double) i);

                prm.motionX = (double) mx;
                prm.motionY = (double) my;
                prm.motionZ = (double) mz;
                prm.size = size + this.rand.nextFloat();
                prm.setColor(1.0F, r, g, b);
                prm.isEffectWind = true;
                MCH_ParticlesUtil.spawnParticle(prm);
            }
        }

    }

    protected void onImpact(MovingObjectPosition m, float damageFactor) {
        if (!this.worldObj.isRemote) {
            if (m.entityHit == null && !W_MovingObjectPosition.isHitTypeEntity(m)) {
                int x = m.blockX;
                int y = m.blockY;
                int z = m.blockZ;

                switch (m.sideHit) {
                case 0:
                    --y;
                    break;

                case 1:
                    ++y;
                    break;

                case 2:
                    --z;
                    break;

                case 3:
                    ++z;
                    break;

                case 4:
                    --x;
                    break;

                case 5:
                    ++x;
                }

                if (this.worldObj.isAirBlock(x, y, z)) {
                    MCH_Config mch_config = MCH_MOD.config;

                    if (MCH_Config.Explosion_FlamingBlock.prmBool) {
                        W_WorldFunc.setBlock(this.worldObj, x, y, z, W_Blocks.fire);
                    }

                    int noAirBlockCount = 0;

                    for (int i = y + 1; i < 256; ++i) {
                        if (!this.worldObj.isAirBlock(x, i, z)) {
                            ++noAirBlockCount;
                            if (noAirBlockCount >= 5) {
                                break;
                            }
                        }
                    }

                    if (noAirBlockCount < 5) {
                        this.setMarkerStatus(2);
                        this.setPosition((double) x + 0.5D, (double) y + 1.1D, (double) z + 0.5D);
                        this.prevPosX = this.posX;
                        this.prevPosY = this.posY;
                        this.prevPosZ = this.posZ;
                        this.countDown = 100;
                    } else {
                        this.setDead();
                    }
                } else {
                    this.setDead();
                }

            }
        }
    }

    public MCH_BulletModel getDefaultBulletModel() {
        return MCH_DefaultBulletModels.Rocket;
    }
}

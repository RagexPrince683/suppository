package mcheli.vehicle;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import mcheli.MCH_Config;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.aircraft.MCH_AircraftInfo;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.aircraft.MCH_PacketStatusRequest;
import mcheli.weapon.MCH_WeaponParam;
import mcheli.weapon.MCH_WeaponSet;
import mcheli.wrapper.W_Entity;
import mcheli.wrapper.W_Lib;
import mcheli.wrapper.W_WorldFunc;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class MCH_EntityVehicle extends MCH_EntityAircraft {

    private MCH_VehicleInfo vehicleInfo = null;
    public boolean isUsedPlayer;
    public float lastRiderYaw;
    public float lastRiderPitch;

    public MCH_EntityVehicle(World world) {
        super(world);
        this.currentSpeed = 0.07D;
        this.preventEntitySpawning = true;
        this.setSize(2.0F, 0.7F);
        this.yOffset = this.height / 2.0F;
        this.motionX = 0.0D;
        this.motionY = 0.0D;
        this.motionZ = 0.0D;
        this.isUsedPlayer = false;
        this.lastRiderYaw = 0.0F;
        this.lastRiderPitch = 0.0F;
        this.weapons = this.createWeapon(0);
    }

    public String getKindName() {
        return "vehicles";
    }

    public String getEntityType() {
        return "Vehicle";
    }

    public MCH_VehicleInfo getVehicleInfo() {
        return this.vehicleInfo;
    }

    public void changeType(String type) {
        if (!type.isEmpty()) {
            this.vehicleInfo = MCH_VehicleInfoManager.get(type);
        }

        if (this.vehicleInfo == null) {
            MCH_Lib.Log((Entity) this, "##### MCH_EntityVehicle changeVehicleType() Vehicle info null %d, %s, %s", new Object[] { Integer.valueOf(W_Entity.getEntityId(this)), type, this.getEntityName()});
            this.setDead();
        } else {
            this.setAcInfo(this.vehicleInfo);
            this.newSeats(this.getAcInfo().getNumSeatAndRack());
            this.weapons = this.createWeapon(1 + this.getSeatNum());
            this.initPartRotation(this.rotationYaw, this.rotationPitch);
        }

    }

    public boolean canMountWithNearEmptyMinecart() {
        MCH_Config mch_config = MCH_MOD.config;

        return MCH_Config.MountMinecartVehicle.prmBool;
    }

    protected void entityInit() {
        super.entityInit();
    }

    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
        super.writeEntityToNBT(par1NBTTagCompound);
    }

    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
        super.readEntityFromNBT(par1NBTTagCompound);
        if (this.vehicleInfo == null) {
            this.vehicleInfo = MCH_VehicleInfoManager.get(this.getTypeName());
            if (this.vehicleInfo == null) {
                MCH_Lib.Log((Entity) this, "##### MCH_EntityVehicle readEntityFromNBT() Vehicle info null %d, %s", new Object[] { Integer.valueOf(W_Entity.getEntityId(this)), this.getEntityName()});
                this.setDead();
            } else {
                this.setAcInfo(this.vehicleInfo);
            }
        }

    }

    public Item getItem() {
        return this.getVehicleInfo() != null ? this.getVehicleInfo().item : null;
    }

    public void setDead() {
        super.setDead();
    }

    public float getSoundVolume() {
        return (float) this.getCurrentThrottle() * 2.0F;
    }

    public float getSoundPitch() {
        return (float) (this.getCurrentThrottle() * 0.5D);
    }

    public String getDefaultSoundName() {
        return "";
    }

    @SideOnly(Side.CLIENT)
    public void zoomCamera() {
        if (this.canZoom()) {
            float z = this.camera.getCameraZoom();

            ++z;
            this.camera.setCameraZoom((double) z <= (double) this.getZoomMax() + 0.01D ? z : 1.0F);
        }

    }

    public void _updateCameraRotate(float yaw, float pitch) {
        this.camera.prevRotationYaw = this.camera.rotationYaw;
        this.camera.prevRotationPitch = this.camera.rotationPitch;
        if (pitch > 89.0F) {
            pitch = 89.0F;
        }

        if (pitch < -89.0F) {
            pitch = -89.0F;
        }

        this.camera.rotationYaw = yaw;
        this.camera.rotationPitch = pitch;
    }

    public boolean isCameraView(Entity entity) {
        return true;
    }

    public boolean useCurrentWeapon(MCH_WeaponParam prm) {
        if (prm.user != null) {
            MCH_WeaponSet breforeUseWeaponPitch = this.getCurrentWeapon(prm.user);

            if (breforeUseWeaponPitch != null) {
                MCH_AircraftInfo.Weapon breforeUseWeaponYaw = this.getAcInfo().getWeaponByName(breforeUseWeaponPitch.getInfo().name);

                if (breforeUseWeaponYaw != null && breforeUseWeaponYaw.maxYaw != 0.0F && breforeUseWeaponYaw.minYaw != 0.0F) {
                    return super.useCurrentWeapon(prm);
                }
            }
        }

        float breforeUseWeaponPitch1 = this.rotationPitch;
        float breforeUseWeaponYaw1 = this.rotationYaw;

        this.rotationPitch = prm.user.rotationPitch;
        this.rotationYaw = prm.user.rotationYaw;
        boolean result = super.useCurrentWeapon(prm);

        this.rotationPitch = breforeUseWeaponPitch1;
        this.rotationYaw = breforeUseWeaponYaw1;
        return result;
    }

    public void onUpdateAircraft() {
        if (this.vehicleInfo == null) {
            this.changeType(this.getTypeName());
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
        } else {
            if (!this.isRequestedSyncStatus) {
                this.isRequestedSyncStatus = true;
                if (this.worldObj.isRemote) {
                    MCH_PacketStatusRequest.requestStatus(this);
                }
            }

            if (this.lastRiddenByEntity == null && this.getRiddenByEntity() != null) {
                this.getRiddenByEntity().rotationPitch = 0.0F;
                this.getRiddenByEntity().prevRotationPitch = 0.0F;
                this.initCurrentWeapon(this.getRiddenByEntity());
            }

            this.updateWeapons();
            this.onUpdate_Seats();
            this.onUpdate_Control();
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            if (this.isInWater()) {
                this.rotationPitch *= 0.9F;
            }

            if (this.worldObj.isRemote) {
                this.onUpdate_Client();
            } else {
                this.onUpdate_Server();
            }

        }
    }

    protected void onUpdate_Control() {
        double max_y = 1.0D;

        if (this.riddenByEntity != null && !this.riddenByEntity.isDead) {
            if (this.getVehicleInfo().isEnableMove || this.getVehicleInfo().isEnableRot) {
                this.onUpdate_ControlOnGround();
            }
        } else if (this.getCurrentThrottle() > 0.0D) {
            this.addCurrentThrottle(-0.00125D);
        } else {
            this.setCurrentThrottle(0.0D);
        }

        if (this.getCurrentThrottle() < 0.0D) {
            this.setCurrentThrottle(0.0D);
        }

        if (this.worldObj.isRemote) {
            if (!W_Lib.isClientPlayer(this.getRiddenByEntity())) {
                double ct = this.getThrottle();

                if (this.getCurrentThrottle() > ct) {
                    this.addCurrentThrottle(-0.005D);
                }

                if (this.getCurrentThrottle() < ct) {
                    this.addCurrentThrottle(0.005D);
                }
            }
        } else {
            this.setThrottle(this.getCurrentThrottle());
        }

    }

    protected void onUpdate_ControlOnGround() {
        if (!this.worldObj.isRemote) {
            boolean move = false;
            float yaw = this.rotationYaw;
            double x = 0.0D;
            double z = 0.0D;

            if (this.getVehicleInfo().isEnableMove) {
                if (this.throttleUp) {
                    yaw = this.rotationYaw;
                    x += Math.sin((double) yaw * 3.141592653589793D / 180.0D);
                    z += Math.cos((double) yaw * 3.141592653589793D / 180.0D);
                    move = true;
                }

                if (this.throttleDown) {
                    yaw = this.rotationYaw - 180.0F;
                    x += Math.sin((double) yaw * 3.141592653589793D / 180.0D);
                    z += Math.cos((double) yaw * 3.141592653589793D / 180.0D);
                    move = true;
                }
            }

            if (this.getVehicleInfo().isEnableMove) {
                if (this.moveLeft && !this.moveRight) {
                    this.rotationYaw = (float) ((double) this.rotationYaw - 0.5D);
                }

                if (this.moveRight && !this.moveLeft) {
                    this.rotationYaw = (float) ((double) this.rotationYaw + 0.5D);
                }
            }

            if (move) {
                double d = Math.sqrt(x * x + z * z);

                this.motionX -= x / d * 0.029999999329447746D;
                this.motionZ += z / d * 0.029999999329447746D;
            }
        }

    }

    protected void onUpdate_Particle() {
        double particlePosY = this.posY;
        boolean b = false;

        int y;
        int k;

        for (y = 0; y < 5 && !b; ++y) {
            int pn;
            int z;

            for (pn = -1; pn <= 1; ++pn) {
                for (z = -1; z <= 1; ++z) {
                    k = W_WorldFunc.getBlockId(this.worldObj, (int) (this.posX + 0.5D) + pn, (int) (this.posY + 0.5D) - y, (int) (this.posZ + 0.5D) + z);
                    if (k != 0 && !b) {
                        particlePosY = (double) ((int) (this.posY + 1.0D) - y);
                        b = true;
                    }
                }
            }

            for (pn = -3; b && pn <= 3; ++pn) {
                for (z = -3; z <= 3; ++z) {
                    if (W_WorldFunc.isBlockWater(this.worldObj, (int) (this.posX + 0.5D) + pn, (int) (this.posY + 0.5D) - y, (int) (this.posZ + 0.5D) + z)) {
                        for (k = 0; (double) k < 7.0D * this.getCurrentThrottle(); ++k) {
                            this.worldObj.spawnParticle("splash", this.posX + 0.5D + (double) pn + (this.rand.nextDouble() - 0.5D) * 2.0D, particlePosY + this.rand.nextDouble(), this.posZ + 0.5D + (double) z + (this.rand.nextDouble() - 0.5D) * 2.0D, (double) pn + (this.rand.nextDouble() - 0.5D) * 2.0D, -0.3D, (double) z + (this.rand.nextDouble() - 0.5D) * 2.0D);
                        }
                    }
                }
            }
        }

        double d0 = (double) (5 - y + 1) / 5.0D;

        if (b) {
            for (k = 0; k < (int) (this.getCurrentThrottle() * 6.0D * d0); ++k) {
                float f3 = 0.25F;

                this.worldObj.spawnParticle("explode", this.posX + (this.rand.nextDouble() - 0.5D), particlePosY + (this.rand.nextDouble() - 0.5D), this.posZ + (this.rand.nextDouble() - 0.5D), (this.rand.nextDouble() - 0.5D) * 2.0D, -0.4D, (this.rand.nextDouble() - 0.5D) * 2.0D);
            }
        }

    }

    protected void onUpdate_Client() {
        this.updateCameraViewers();
        if (this.riddenByEntity != null && W_Lib.isClientPlayer(this.getRiddenByEntity())) {
            this.getRiddenByEntity().rotationPitch = this.getRiddenByEntity().prevRotationPitch;
        }

        if (this.aircraftPosRotInc > 0) {
            double rpinc = (double) this.aircraftPosRotInc;
            double yaw = MathHelper.wrapAngleTo180_double(this.aircraftYaw - (double) this.rotationYaw);

            this.rotationYaw = (float) ((double) this.rotationYaw + yaw / rpinc);
            this.rotationPitch = (float) ((double) this.rotationPitch + (this.aircraftPitch - (double) this.rotationPitch) / rpinc);
            this.setPosition(this.posX + (this.aircraftX - this.posX) / rpinc, this.posY + (this.aircraftY - this.posY) / rpinc, this.posZ + (this.aircraftZ - this.posZ) / rpinc);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            --this.aircraftPosRotInc;
        } else {
            this.setPosition(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            if (this.onGround) {
                this.motionX *= 0.95D;
                this.motionZ *= 0.95D;
            }

            if (this.isInWater()) {
                this.motionX *= 0.99D;
                this.motionZ *= 0.99D;
            }
        }

        if (this.riddenByEntity != null) {
            ;
        }

        this.updateCamera(this.posX, this.posY, this.posZ);
    }

    private void onUpdate_Server() {
        double prevMotion = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);

        this.updateCameraViewers();
        double dp = 0.0D;

        if (this.canFloatWater()) {
            dp = this.getWaterDepth();
        }

        if (dp == 0.0D) {
            this.motionY += (double) (!this.isInWater() ? this.getAcInfo().gravity : this.getAcInfo().gravityInWater);
        } else if (dp < 1.0D) {
            this.motionY -= 1.0E-4D;
            this.motionY += 0.007D * this.getCurrentThrottle();
        } else {
            if (this.motionY < 0.0D) {
                this.motionY /= 2.0D;
            }

            this.motionY += 0.007D;
        }

        double motion = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        float speedLimit = this.getAcInfo().speed;

        if (motion > (double) speedLimit) {
            this.motionX *= (double) speedLimit / motion;
            this.motionZ *= (double) speedLimit / motion;
            motion = (double) speedLimit;
        }

        if (motion > prevMotion && this.currentSpeed < (double) speedLimit) {
            this.currentSpeed += ((double) speedLimit - this.currentSpeed) / 35.0D;
            if (this.currentSpeed > (double) speedLimit) {
                this.currentSpeed = (double) speedLimit;
            }
        } else {
            this.currentSpeed -= (this.currentSpeed - 0.07D) / 35.0D;
            if (this.currentSpeed < 0.07D) {
                this.currentSpeed = 0.07D;
            }
        }

        if (this.onGround) {
            this.motionX *= 0.5D;
            this.motionZ *= 0.5D;
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionY *= 0.95D;
        this.motionX *= 0.99D;
        this.motionZ *= 0.99D;
        this.onUpdate_updateBlock();
        if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
            this.unmountEntity();
            this.riddenByEntity = null;
        }

    }

    public void onUpdateAngles(float partialTicks) {}

    public void _updateRiderPosition() {
        float yaw = this.rotationYaw;

        if (this.riddenByEntity != null) {
            this.rotationYaw = this.riddenByEntity.rotationYaw;
        }

        super.updateRiderPosition();
        this.rotationYaw = yaw;
    }

    public boolean canSwitchFreeLook() {
        return false;
    }
}

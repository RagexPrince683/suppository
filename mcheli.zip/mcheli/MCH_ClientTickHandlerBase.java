package mcheli;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.wrapper.W_McClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.entity.Entity;

@SideOnly(Side.CLIENT)
public abstract class MCH_ClientTickHandlerBase {

    protected Minecraft mc;
    public static float playerRotMinPitch = -90.0F;
    public static float playerRotMaxPitch = 90.0F;
    public static boolean playerRotLimitPitch = false;
    public static float playerRotMinYaw = -180.0F;
    public static float playerRotMaxYaw = 180.0F;
    public static boolean playerRotLimitYaw = false;
    private static int mouseWheel = 0;

    public abstract void updateKeybind(MCH_Config mch_config);

    public static void setRotLimitPitch(float min, float max, Entity player) {
        MCH_ClientTickHandlerBase.playerRotMinPitch = min;
        MCH_ClientTickHandlerBase.playerRotMaxPitch = max;
        MCH_ClientTickHandlerBase.playerRotLimitPitch = true;
        if (player != null) {
            player.rotationPitch = MCH_Lib.RNG(player.rotationPitch, MCH_ClientTickHandlerBase.playerRotMinPitch, MCH_ClientTickHandlerBase.playerRotMaxPitch);
        }

    }

    public static void setRotLimitYaw(float min, float max, Entity e) {
        MCH_ClientTickHandlerBase.playerRotMinYaw = min;
        MCH_ClientTickHandlerBase.playerRotMaxYaw = max;
        MCH_ClientTickHandlerBase.playerRotLimitYaw = true;
        if (e != null) {
            if (e.rotationPitch < MCH_ClientTickHandlerBase.playerRotMinPitch) {
                e.rotationPitch = MCH_ClientTickHandlerBase.playerRotMinPitch;
                e.prevRotationPitch = MCH_ClientTickHandlerBase.playerRotMinPitch;
            } else if (e.rotationPitch > MCH_ClientTickHandlerBase.playerRotMaxPitch) {
                e.rotationPitch = MCH_ClientTickHandlerBase.playerRotMaxPitch;
                e.prevRotationPitch = MCH_ClientTickHandlerBase.playerRotMaxPitch;
            }
        }

    }

    public static void initRotLimit() {
        MCH_ClientTickHandlerBase.playerRotMinPitch = -90.0F;
        MCH_ClientTickHandlerBase.playerRotMaxPitch = 90.0F;
        MCH_ClientTickHandlerBase.playerRotLimitYaw = false;
        MCH_ClientTickHandlerBase.playerRotMinYaw = -180.0F;
        MCH_ClientTickHandlerBase.playerRotMaxYaw = 180.0F;
        MCH_ClientTickHandlerBase.playerRotLimitYaw = false;
    }

    public static void applyRotLimit(Entity e) {
        if (e != null) {
            if (MCH_ClientTickHandlerBase.playerRotLimitPitch) {
                if (e.rotationPitch < MCH_ClientTickHandlerBase.playerRotMinPitch) {
                    e.rotationPitch = MCH_ClientTickHandlerBase.playerRotMinPitch;
                    e.prevRotationPitch = MCH_ClientTickHandlerBase.playerRotMinPitch;
                } else if (e.rotationPitch > MCH_ClientTickHandlerBase.playerRotMaxPitch) {
                    e.rotationPitch = MCH_ClientTickHandlerBase.playerRotMaxPitch;
                    e.prevRotationPitch = MCH_ClientTickHandlerBase.playerRotMaxPitch;
                }
            }

            if (MCH_ClientTickHandlerBase.playerRotLimitYaw) {
                ;
            }
        }

    }

    public MCH_ClientTickHandlerBase(Minecraft minecraft) {
        this.mc = minecraft;
    }

    public static boolean updateMouseWheel(int wheel) {
        boolean cancelEvent = false;

        if (wheel != 0) {
            MCH_Config mch_config = MCH_MOD.config;

            if (MCH_Config.SwitchWeaponWithMouseWheel.prmBool) {
                setMouseWheel(0);
                EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;

                if (player != null) {
                    MCH_EntityAircraft ac = MCH_EntityAircraft.getAircraft_RiddenOrControl(player);

                    if (ac != null) {
                        int cwid = ac.getWeaponIDBySeatID(ac.getSeatIdByEntity(player));
                        int nwid = ac.getNextWeaponID(player, 1);

                        if (cwid != nwid) {
                            setMouseWheel(wheel);
                            cancelEvent = true;
                        }
                    }
                }
            }
        }

        return cancelEvent;
    }

    protected abstract void onTick(boolean flag);

    public static void playSoundOK() {
        W_McClient.DEF_playSoundFX("random.click", 1.0F, 1.0F);
    }

    public static void playSoundNG() {
        W_McClient.MOD_playSoundFX("ng", 1.0F, 1.0F);
    }

    public static void playSound(String name) {
        W_McClient.MOD_playSoundFX(name, 1.0F, 1.0F);
    }

    public static void playSound(String name, float vol, float pitch) {
        W_McClient.MOD_playSoundFX(name, vol, pitch);
    }

    public static int getMouseWheel() {
        return MCH_ClientTickHandlerBase.mouseWheel;
    }

    public static void setMouseWheel(int mouseWheel) {
        MCH_ClientTickHandlerBase.mouseWheel = mouseWheel;
    }
}

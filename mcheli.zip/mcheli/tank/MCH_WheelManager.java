package mcheli.tank;

import java.util.List;
import java.util.Random;
import mcheli.MCH_Config;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.aircraft.MCH_AircraftInfo;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.particles.MCH_ParticlesUtil;
import mcheli.wrapper.W_Block;
import mcheli.wrapper.W_Blocks;
import mcheli.wrapper.W_Lib;
import mcheli.wrapper.W_WorldFunc;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class MCH_WheelManager {

    public final MCH_EntityAircraft parent;
    public MCH_EntityWheel[] wheels;
    private double minZ;
    private double maxZ;
    private double avgZ;
    public Vec3 weightedCenter;
    public float targetPitch;
    public float targetRoll;
    public float prevYaw;
    private static Random rand = new Random();

    public MCH_WheelManager(MCH_EntityAircraft ac) {
        this.parent = ac;
        this.wheels = new MCH_EntityWheel[0];
        this.weightedCenter = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
    }

    public void createWheels(World w, List list, Vec3 weightedCenter) {
        this.wheels = new MCH_EntityWheel[list.size() * 2];
        this.minZ = 999999.0D;
        this.maxZ = -999999.0D;
        this.weightedCenter = weightedCenter;

        for (int i = 0; i < this.wheels.length; ++i) {
            MCH_EntityWheel wheel = new MCH_EntityWheel(w);

            wheel.setParents(this.parent);
            Vec3 wp = ((MCH_AircraftInfo.Wheel) list.get(i / 2)).pos;

            wheel.setWheelPos(Vec3.createVectorHelper(i % 2 == 0 ? wp.xCoord : -wp.xCoord, wp.yCoord, wp.zCoord), this.weightedCenter);
            Vec3 v = this.parent.getTransformedPosition(wheel.pos.xCoord, wheel.pos.yCoord, wheel.pos.zCoord);

            wheel.setLocationAndAngles(v.xCoord, v.yCoord + 1.0D, v.zCoord, 0.0F, 0.0F);
            this.wheels[i] = wheel;
            if (wheel.pos.zCoord <= this.minZ) {
                this.minZ = wheel.pos.zCoord;
            }

            if (wheel.pos.zCoord >= this.maxZ) {
                this.maxZ = wheel.pos.zCoord;
            }
        }

        this.avgZ = this.maxZ - this.minZ;
    }

    public void move(double x, double y, double z) {
        MCH_EntityAircraft ac = this.parent;

        if (ac.getAcInfo() != null) {
            boolean showLog = ac.ticksExisted % 1 == 1;

            if (showLog) {
                MCH_Lib.DbgLog(ac.worldObj, "[" + (ac.worldObj.isRemote ? "Client" : "Server") + "] ==============================", new Object[0]);
            }

            MCH_EntityWheel[] zmog = this.wheels;
            int rv = zmog.length;

            int wc;
            MCH_EntityWheel pitch;

            for (wc = 0; wc < rv; ++wc) {
                pitch = zmog[wc];
                pitch.prevPosX = pitch.posX;
                pitch.prevPosY = pitch.posY;
                pitch.prevPosZ = pitch.posZ;
                Vec3 roll = ac.getTransformedPosition(pitch.pos.xCoord, pitch.pos.yCoord, pitch.pos.zCoord);

                pitch.motionX = roll.xCoord - pitch.posX + x;
                pitch.motionY = roll.yCoord - pitch.posY;
                pitch.motionZ = roll.zCoord - pitch.posZ + z;
            }

            zmog = this.wheels;
            rv = zmog.length;

            for (wc = 0; wc < rv; ++wc) {
                pitch = zmog[wc];
                pitch.motionY *= 0.15D;
                pitch.moveEntity(pitch.motionX, pitch.motionY, pitch.motionZ);
                double d0 = 1.0D;

                pitch.moveEntity(0.0D, -0.1D * d0, 0.0D);
            }

            int i = -1;

            MCH_EntityWheel mch_entitywheel;

            for (rv = 0; rv < this.wheels.length / 2; ++rv) {
                i = rv;
                mch_entitywheel = this.wheels[rv * 2 + 0];
                pitch = this.wheels[rv * 2 + 1];
                if (!mch_entitywheel.isPlus && (mch_entitywheel.onGround || pitch.onGround)) {
                    i = -1;
                    break;
                }
            }

            if (i >= 0) {
                this.wheels[i * 2 + 0].onGround = true;
                this.wheels[i * 2 + 1].onGround = true;
            }

            i = -1;

            for (rv = this.wheels.length / 2 - 1; rv >= 0; --rv) {
                i = rv;
                mch_entitywheel = this.wheels[rv * 2 + 0];
                pitch = this.wheels[rv * 2 + 1];
                if (mch_entitywheel.isPlus && (mch_entitywheel.onGround || pitch.onGround)) {
                    i = -1;
                    break;
                }
            }

            if (i >= 0) {
                this.wheels[i * 2 + 0].onGround = true;
                this.wheels[i * 2 + 1].onGround = true;
            }

            Vec3 vec3 = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
            Vec3 vec31 = ac.getTransformedPosition(this.weightedCenter);

            vec31.xCoord -= ac.posX;
            vec31.yCoord = this.weightedCenter.yCoord;
            vec31.zCoord -= ac.posZ;

            for (int j = 0; j < this.wheels.length / 2; ++j) {
                MCH_EntityWheel mch_entitywheel1 = this.wheels[j * 2 + 0];
                MCH_EntityWheel ogpf = this.wheels[j * 2 + 1];
                Vec3 ogrf = Vec3.createVectorHelper(mch_entitywheel1.posX - (ac.posX + vec31.xCoord), mch_entitywheel1.posY - (ac.posY + vec31.yCoord), mch_entitywheel1.posZ - (ac.posZ + vec31.zCoord));
                Vec3 arr$ = Vec3.createVectorHelper(ogpf.posX - (ac.posX + vec31.xCoord), ogpf.posY - (ac.posY + vec31.yCoord), ogpf.posZ - (ac.posZ + vec31.zCoord));
                Vec3 len$ = mch_entitywheel1.pos.zCoord >= 0.0D ? arr$.crossProduct(ogrf) : ogrf.crossProduct(arr$);

                len$ = len$.normalize();
                double i$ = Math.abs(mch_entitywheel1.pos.zCoord / this.avgZ);

                if (!mch_entitywheel1.onGround && !ogpf.onGround) {
                    i$ = 0.0D;
                }

                vec3.xCoord += len$.xCoord * i$;
                vec3.yCoord += len$.yCoord * i$;
                vec3.zCoord += len$.zCoord * i$;
                if (showLog) {
                    len$.rotateAroundY((float) ((double) ac.getRotYaw() * 3.141592653589793D / 180.0D));
                    MCH_Lib.DbgLog(ac.worldObj, "%2d : %.2f :[%+.1f, %+.1f, %+.1f][%s %d %d][%+.2f(%+.2f), %+.2f(%+.2f)][%+.1f, %+.1f, %+.1f]", new Object[] { Integer.valueOf(j), Double.valueOf(i$), Double.valueOf(len$.xCoord), Double.valueOf(len$.yCoord), Double.valueOf(len$.zCoord), mch_entitywheel1.isPlus ? "+" : "-", Integer.valueOf(mch_entitywheel1.onGround ? 1 : 0), Integer.valueOf(ogpf.onGround ? 1 : 0), Double.valueOf(mch_entitywheel1.posY - mch_entitywheel1.prevPosY), Double.valueOf(mch_entitywheel1.motionY), Double.valueOf(ogpf.posY - ogpf.prevPosY), Double.valueOf(ogpf.motionY), Double.valueOf(len$.xCoord), Double.valueOf(len$.yCoord), Double.valueOf(len$.zCoord)});
                }
            }

            vec3 = vec3.normalize();
            if (vec3.yCoord > 0.01D && vec3.yCoord < 0.7D) {
                ac.motionX += vec3.xCoord / 50.0D;
                ac.motionZ += vec3.zCoord / 50.0D;
            }

            vec3.rotateAroundY((float) ((double) ac.getRotYaw() * 3.141592653589793D / 180.0D));
            float f = (float) (90.0D - Math.atan2(vec3.yCoord, vec3.zCoord) * 180.0D / 3.141592653589793D);
            float f1 = -((float) (90.0D - Math.atan2(vec3.yCoord, vec3.xCoord) * 180.0D / 3.141592653589793D));
            float f2 = ac.getAcInfo().onGroundPitchFactor;

            if (f - ac.getRotPitch() > f2) {
                f = ac.getRotPitch() + f2;
            }

            if (f - ac.getRotPitch() < -f2) {
                f = ac.getRotPitch() - f2;
            }

            float f3 = ac.getAcInfo().onGroundRollFactor;

            if (f1 - ac.getRotRoll() > f3) {
                f1 = ac.getRotRoll() + f3;
            }

            if (f1 - ac.getRotRoll() < -f3) {
                f1 = ac.getRotRoll() - f3;
            }

            this.targetPitch = f;
            this.targetRoll = f1;
            if (!W_Lib.isClientPlayer(ac.getRiddenByEntity())) {
                ac.setRotPitch(f);
                ac.setRotRoll(f1);
            }

            if (showLog) {
                MCH_Lib.DbgLog(ac.worldObj, "%+03d, %+03d :[%.2f, %.2f, %.2f] yaw=%.2f, pitch=%.2f, roll=%.2f", new Object[] { Integer.valueOf((int) f), Integer.valueOf((int) f1), Double.valueOf(vec3.xCoord), Double.valueOf(vec3.yCoord), Double.valueOf(vec3.zCoord), Float.valueOf(ac.getRotYaw()), Float.valueOf(this.targetPitch), Float.valueOf(this.targetRoll)});
            }

            MCH_EntityWheel[] amch_entitywheel = this.wheels;
            int k = amch_entitywheel.length;

            for (int l = 0; l < k; ++l) {
                MCH_EntityWheel wheel = amch_entitywheel[l];
                Vec3 v = this.getTransformedPosition(wheel.pos.xCoord, wheel.pos.yCoord, wheel.pos.zCoord, ac, ac.getRotYaw(), this.targetPitch, this.targetRoll);
                double offset = wheel.onGround ? 0.01D : -0.0D;
                double rangeH = 2.0D;
                double poy = (double) (wheel.stepHeight / 2.0F);
                int b = 0;

                if (wheel.posX > v.xCoord + rangeH) {
                    wheel.posX = v.xCoord + rangeH;
                    wheel.posY = v.yCoord + poy;
                    b |= 1;
                }

                if (wheel.posX < v.xCoord - rangeH) {
                    wheel.posX = v.xCoord - rangeH;
                    wheel.posY = v.yCoord + poy;
                    b |= 2;
                }

                if (wheel.posZ > v.zCoord + rangeH) {
                    wheel.posZ = v.zCoord + rangeH;
                    wheel.posY = v.yCoord + poy;
                    b |= 4;
                }

                if (wheel.posZ < v.zCoord - rangeH) {
                    wheel.posZ = v.zCoord - rangeH;
                    wheel.posY = v.yCoord + poy;
                    b |= 8;
                }

                wheel.setPositionAndRotation(wheel.posX, wheel.posY, wheel.posZ, 0.0F, 0.0F);
            }

        }
    }

    public Vec3 getTransformedPosition(double x, double y, double z, MCH_EntityAircraft ac, float yaw, float pitch, float roll) {
        Vec3 v = MCH_Lib.RotVec3(x, y, z, -yaw, -pitch, -roll);

        return v.addVector(ac.posX, ac.posY, ac.posZ);
    }

    public void updateBlock() {
        MCH_Config mch_config = MCH_MOD.config;

        if (MCH_Config.Collision_DestroyBlock.prmBool) {
            MCH_EntityAircraft ac = this.parent;
            MCH_EntityWheel[] arr$ = this.wheels;
            int len$ = arr$.length;

            for (int i$ = 0; i$ < len$; ++i$) {
                MCH_EntityWheel w = arr$[i$];
                Vec3 v = ac.getTransformedPosition(w.pos);
                int x = (int) (v.xCoord + 0.5D);
                int y = (int) (v.yCoord + 0.5D);
                int z = (int) (v.zCoord + 0.5D);
                Block block = ac.worldObj.getBlock(x, y, z);

                if (block == W_Block.getSnowLayer()) {
                    ac.worldObj.setBlockToAir(x, y, z);
                }

                if (block == W_Blocks.waterlily || block == W_Blocks.cake) {
                    W_WorldFunc.destroyBlock(ac.worldObj, x, y, z, false);
                }
            }

        }
    }

    public void particleLandingGear() {
        if (this.wheels.length > 0) {
            MCH_EntityAircraft ac = this.parent;
            double d = ac.motionX * ac.motionX + ac.motionZ * ac.motionZ + (double) Math.abs(this.prevYaw - ac.getRotYaw());

            this.prevYaw = ac.getRotYaw();
            if (d > 0.001D) {
                for (int i = 0; i < 2; ++i) {
                    MCH_EntityWheel w = this.wheels[MCH_WheelManager.rand.nextInt(this.wheels.length)];
                    Vec3 v = ac.getTransformedPosition(w.pos);
                    int x = MathHelper.floor_double(v.xCoord + 0.5D);
                    int y = MathHelper.floor_double(v.yCoord - 0.5D);
                    int z = MathHelper.floor_double(v.zCoord + 0.5D);
                    Block block = ac.worldObj.getBlock(x, y, z);

                    if (Block.isEqualTo(block, Blocks.air)) {
                        y = MathHelper.floor_double(v.yCoord + 0.5D);
                        block = ac.worldObj.getBlock(x, y, z);
                    }

                    if (!Block.isEqualTo(block, Blocks.air)) {
                        MCH_ParticlesUtil.spawnParticleTileCrack(ac.worldObj, x, y, z, v.xCoord + ((double) MCH_WheelManager.rand.nextFloat() - 0.5D), v.yCoord + 0.1D, v.zCoord + ((double) MCH_WheelManager.rand.nextFloat() - 0.5D), -ac.motionX * 4.0D + ((double) MCH_WheelManager.rand.nextFloat() - 0.5D) * 0.1D, (double) MCH_WheelManager.rand.nextFloat() * 0.5D, -ac.motionZ * 4.0D + ((double) MCH_WheelManager.rand.nextFloat() - 0.5D) * 0.1D);
                    }
                }
            }

        }
    }
}

package mcheli.tank;

import mcheli.MCH_Config;
import mcheli.MCH_Key;
import mcheli.MCH_Lib;
import mcheli.MCH_ViewEntityDummy;
import mcheli.aircraft.MCH_AircraftClientTickHandler;
import mcheli.aircraft.MCH_EntitySeat;
import mcheli.aircraft.MCH_SeatInfo;
import mcheli.uav.MCH_EntityUavStation;
import mcheli.wrapper.W_Network;
import mcheli.wrapper.W_Reflection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.entity.player.EntityPlayer;

public class MCH_ClientTankTickHandler extends MCH_AircraftClientTickHandler {

    public MCH_Key KeySwitchMode;
    public MCH_Key KeyZoom;
    public MCH_Key[] Keys;

    public MCH_ClientTankTickHandler(Minecraft minecraft, MCH_Config config) {
        super(minecraft, config);
        this.updateKeybind(config);
    }

    public void updateKeybind(MCH_Config config) {
        super.updateKeybind(config);
        this.KeySwitchMode = new MCH_Key(MCH_Config.KeySwitchMode.prmInt);
        this.KeyZoom = new MCH_Key(MCH_Config.KeyZoom.prmInt);
        this.Keys = new MCH_Key[] { this.KeyUp, this.KeyDown, this.KeyRight, this.KeyLeft, this.KeySwitchMode, this.KeyUseWeapon, this.KeySwWeaponMode, this.KeySwitchWeapon1, this.KeySwitchWeapon2, this.KeyZoom, this.KeyCameraMode, this.KeyUnmount, this.KeyUnmountForce, this.KeyFlare, this.KeyExtra, this.KeyFreeLook, this.KeyGUI, this.KeyGearUpDown, this.KeyBrake, this.KeyPutToRack, this.KeyDownFromRack};
    }

    protected void update(EntityPlayer player, MCH_EntityTank tank) {
        if (tank.getIsGunnerMode(player)) {
            MCH_SeatInfo seatInfo = tank.getSeatInfo(player);

            if (seatInfo != null) {
                setRotLimitPitch(seatInfo.minPitch, seatInfo.maxPitch, player);
            }
        }

        tank.updateRadar(10);
        tank.updateCameraRotate(player.rotationYaw, player.rotationPitch);
    }

    protected void onTick(boolean inGUI) {
        MCH_Key[] player = this.Keys;
        int tank = player.length;

        for (int isPilot = 0; isPilot < tank; ++isPilot) {
            MCH_Key viewEntityDummy = player[isPilot];

            viewEntityDummy.update();
        }

        this.isBeforeRiding = this.isRiding;
        EntityClientPlayerMP entityclientplayermp = this.mc.thePlayer;
        MCH_EntityTank mch_entitytank = null;
        boolean flag = true;

        if (entityclientplayermp != null) {
            if (entityclientplayermp.ridingEntity instanceof MCH_EntityTank) {
                mch_entitytank = (MCH_EntityTank) entityclientplayermp.ridingEntity;
            } else if (entityclientplayermp.ridingEntity instanceof MCH_EntitySeat) {
                MCH_EntitySeat mch_entityseat = (MCH_EntitySeat) entityclientplayermp.ridingEntity;

                if (mch_entityseat.getParent() instanceof MCH_EntityTank) {
                    flag = false;
                    mch_entitytank = (MCH_EntityTank) mch_entityseat.getParent();
                }
            } else if (entityclientplayermp.ridingEntity instanceof MCH_EntityUavStation) {
                MCH_EntityUavStation mch_entityuavstation = (MCH_EntityUavStation) entityclientplayermp.ridingEntity;

                if (mch_entityuavstation.getControlAircract() instanceof MCH_EntityTank) {
                    mch_entitytank = (MCH_EntityTank) mch_entityuavstation.getControlAircract();
                }
            }
        }

        if (mch_entitytank != null && mch_entitytank.getAcInfo() != null) {
            this.update(entityclientplayermp, mch_entitytank);
            MCH_ViewEntityDummy mch_viewentitydummy = MCH_ViewEntityDummy.getInstance(this.mc.theWorld);

            mch_viewentitydummy.update(mch_entitytank.camera);
            if (!inGUI) {
                if (!mch_entitytank.isDestroyed()) {
                    this.playerControl(entityclientplayermp, mch_entitytank, flag);
                }
            } else {
                this.playerControlInGUI(entityclientplayermp, mch_entitytank, flag);
            }

            boolean hideHand = true;

            if ((!flag || !mch_entitytank.isAlwaysCameraView()) && !mch_entitytank.getIsGunnerMode(entityclientplayermp) && mch_entitytank.getCameraId() <= 0) {
                MCH_Lib.setRenderViewEntity(entityclientplayermp);
                if (!flag && mch_entitytank.getCurrentWeaponID(entityclientplayermp) < 0) {
                    hideHand = false;
                }
            } else {
                MCH_Lib.setRenderViewEntity(mch_viewentitydummy);
            }

            if (hideHand) {
                MCH_Lib.disableFirstPersonItemRender(entityclientplayermp.getCurrentEquippedItem());
            }

            this.isRiding = true;
        } else {
            this.isRiding = false;
        }

        if (!this.isBeforeRiding && this.isRiding && mch_entitytank != null) {
            MCH_ViewEntityDummy.getInstance(this.mc.theWorld).setPosition(mch_entitytank.posX, mch_entitytank.posY + 0.5D, mch_entitytank.posZ);
        } else if (this.isBeforeRiding && !this.isRiding) {
            MCH_Lib.enableFirstPersonItemRender();
            MCH_Lib.setRenderViewEntity(entityclientplayermp);
            W_Reflection.setCameraRoll(0.0F);
        }

    }

    protected void playerControlInGUI(EntityPlayer player, MCH_EntityTank tank, boolean isPilot) {
        this.commonPlayerControlInGUI(player, tank, isPilot, new MCH_TankPacketPlayerControl());
    }

    protected void playerControl(EntityPlayer player, MCH_EntityTank tank, boolean isPilot) {
        MCH_TankPacketPlayerControl pc = new MCH_TankPacketPlayerControl();
        boolean send = false;

        send = this.commonPlayerControl(player, tank, isPilot, pc);
        if (tank.getAcInfo().defaultFreelook && pc.switchFreeLook > 0) {
            pc.switchFreeLook = 0;
        }

        if (isPilot) {
            if (this.KeySwitchMode.isKeyDown()) {
                if (tank.getIsGunnerMode(player) && tank.canSwitchCameraPos()) {
                    pc.switchMode = 0;
                    tank.switchGunnerMode(false);
                    send = true;
                    tank.setCameraId(1);
                } else if (tank.getCameraId() > 0) {
                    tank.setCameraId(tank.getCameraId() + 1);
                    if (tank.getCameraId() >= tank.getCameraPosNum()) {
                        tank.setCameraId(0);
                    }
                } else if (tank.canSwitchGunnerMode()) {
                    pc.switchMode = (byte) (tank.getIsGunnerMode(player) ? 0 : 1);
                    tank.switchGunnerMode(!tank.getIsGunnerMode(player));
                    send = true;
                    tank.setCameraId(0);
                } else if (tank.canSwitchCameraPos()) {
                    tank.setCameraId(1);
                } else {
                    playSoundNG();
                }
            }
        } else if (this.KeySwitchMode.isKeyDown()) {
            if (tank.canSwitchGunnerModeOtherSeat(player)) {
                tank.switchGunnerModeOtherSeat(player);
                send = true;
            } else {
                playSoundNG();
            }
        }

        if (this.KeyZoom.isKeyDown()) {
            boolean isUav = tank.isUAV() && !tank.getAcInfo().haveHatch();

            if (!tank.getIsGunnerMode(player) && !isUav) {
                if (isPilot && tank.getAcInfo().haveHatch()) {
                    if (tank.canFoldHatch()) {
                        pc.switchHatch = 2;
                        send = true;
                    } else if (tank.canUnfoldHatch()) {
                        pc.switchHatch = 1;
                        send = true;
                    }
                }
            } else {
                tank.zoomCamera();
                playSound("zoom", 0.5F, 1.0F);
            }
        }

        if (send) {
            W_Network.sendToServer(pc);
        }

    }
}

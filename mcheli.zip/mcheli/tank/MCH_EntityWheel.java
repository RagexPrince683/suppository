package mcheli.tank;

import java.util.ArrayList;
import java.util.List;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.aircraft.MCH_EntityHitBox;
import mcheli.aircraft.MCH_EntitySeat;
import mcheli.wrapper.W_Entity;
import mcheli.wrapper.W_Lib;
import mcheli.wrapper.W_WorldFunc;
import net.minecraft.block.Block;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class MCH_EntityWheel extends W_Entity {

    private MCH_EntityAircraft parents;
    public Vec3 pos;
    boolean isPlus;

    public MCH_EntityWheel(World w) {
        super(w);
        this.setSize(1.0F, 1.0F);
        this.stepHeight = 1.5F;
        this.isImmuneToFire = true;
        this.isPlus = false;
    }

    public void setWheelPos(Vec3 pos, Vec3 weightedCenter) {
        this.pos = pos;
        this.isPlus = pos.zCoord >= weightedCenter.zCoord;
    }

    public void travelToDimension(int dimensionId) {}

    public MCH_EntityAircraft getParents() {
        return this.parents;
    }

    public void setParents(MCH_EntityAircraft parents) {
        this.parents = parents;
    }

    protected void readEntityFromNBT(NBTTagCompound tagCompund) {
        this.setDead();
    }

    protected void writeEntityToNBT(NBTTagCompound tagCompound) {}

    public void moveEntity(double parX, double parY, double parZ) {
        this.worldObj.theProfiler.startSection("move");
        this.ySize *= 0.4F;
        double nowPosX = this.posX;
        double nowPosY = this.posY;
        double nowPosZ = this.posZ;
        double mx = parX;
        double my = parY;
        double mz = parZ;
        AxisAlignedBB axisalignedbb = this.boundingBox.copy();
        List list = this.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(parX, parY, parZ));

        for (int flag1 = 0; flag1 < list.size(); ++flag1) {
            parY = ((AxisAlignedBB) list.get(flag1)).calculateYOffset(this.boundingBox, parY);
        }

        this.boundingBox.offset(0.0D, parY, 0.0D);
        boolean flag = this.onGround || my != parY && my < 0.0D;

        int bkParY;

        for (bkParY = 0; bkParY < list.size(); ++bkParY) {
            parX = ((AxisAlignedBB) list.get(bkParY)).calculateXOffset(this.boundingBox, parX);
        }

        this.boundingBox.offset(parX, 0.0D, 0.0D);

        for (bkParY = 0; bkParY < list.size(); ++bkParY) {
            parZ = ((AxisAlignedBB) list.get(bkParY)).calculateZOffset(this.boundingBox, parZ);
        }

        this.boundingBox.offset(0.0D, 0.0D, parZ);
        if (this.stepHeight > 0.0F && flag && this.ySize < 0.05F && (mx != parX || mz != parZ)) {
            double bkParX = parX;
            double d0 = parY;
            double bkParZ = parZ;

            parX = mx;
            parY = (double) this.stepHeight;
            parZ = mz;
            AxisAlignedBB throwable = this.boundingBox.copy();

            this.boundingBox.setBB(axisalignedbb);
            list = this.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(mx, parY, mz));

            int crashreport;

            for (crashreport = 0; crashreport < list.size(); ++crashreport) {
                parY = ((AxisAlignedBB) list.get(crashreport)).calculateYOffset(this.boundingBox, parY);
            }

            this.boundingBox.offset(0.0D, parY, 0.0D);

            for (crashreport = 0; crashreport < list.size(); ++crashreport) {
                parX = ((AxisAlignedBB) list.get(crashreport)).calculateXOffset(this.boundingBox, parX);
            }

            this.boundingBox.offset(parX, 0.0D, 0.0D);

            for (crashreport = 0; crashreport < list.size(); ++crashreport) {
                parZ = ((AxisAlignedBB) list.get(crashreport)).calculateZOffset(this.boundingBox, parZ);
            }

            this.boundingBox.offset(0.0D, 0.0D, parZ);
            parY = (double) (-this.stepHeight);

            for (crashreport = 0; crashreport < list.size(); ++crashreport) {
                parY = ((AxisAlignedBB) list.get(crashreport)).calculateYOffset(this.boundingBox, parY);
            }

            this.boundingBox.offset(0.0D, parY, 0.0D);
            if (bkParX * bkParX + bkParZ * bkParZ >= parX * parX + parZ * parZ) {
                parX = bkParX;
                parY = d0;
                parZ = bkParZ;
                this.boundingBox.setBB(throwable);
            }
        }

        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("rest");
        this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
        this.posY = this.boundingBox.minY + (double) this.yOffset - (double) this.ySize;
        this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
        this.isCollidedHorizontally = mx != parX || mz != parZ;
        this.isCollidedVertically = my != parY;
        this.onGround = my != parY && my < 0.0D;
        this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
        this.updateFallState(parY, this.onGround);
        if (mx != parX) {
            this.motionX = 0.0D;
        }

        if (my != parY) {
            this.motionY = 0.0D;
        }

        if (mz != parZ) {
            this.motionZ = 0.0D;
        }

        try {
            this.doBlockCollisions();
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Checking entity tile collision");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being checked for collision");

            this.addEntityCrashInfo(crashreportcategory);
        }

        this.worldObj.theProfiler.endSection();
    }

    public List getCollidingBoundingBoxes(Entity par1Entity, AxisAlignedBB par2AxisAlignedBB) {
        ArrayList collidingBoundingBoxes = new ArrayList();

        collidingBoundingBoxes.clear();
        int i = MathHelper.floor_double(par2AxisAlignedBB.minX);
        int j = MathHelper.floor_double(par2AxisAlignedBB.maxX + 1.0D);
        int k = MathHelper.floor_double(par2AxisAlignedBB.minY);
        int l = MathHelper.floor_double(par2AxisAlignedBB.maxY + 1.0D);
        int i1 = MathHelper.floor_double(par2AxisAlignedBB.minZ);
        int j1 = MathHelper.floor_double(par2AxisAlignedBB.maxZ + 1.0D);

        for (int d0 = i; d0 < j; ++d0) {
            for (int l1 = i1; l1 < j1; ++l1) {
                if (par1Entity.worldObj.blockExists(d0, 64, l1)) {
                    for (int list = k - 1; list < l; ++list) {
                        Block j2 = W_WorldFunc.getBlock(par1Entity.worldObj, d0, list, l1);

                        if (j2 != null) {
                            j2.addCollisionBoxesToList(par1Entity.worldObj, d0, list, l1, par2AxisAlignedBB, collidingBoundingBoxes, par1Entity);
                        }
                    }
                }
            }
        }

        double d0 = 0.25D;
        List list = par1Entity.worldObj.getEntitiesWithinAABBExcludingEntity(par1Entity, par2AxisAlignedBB.expand(d0, d0, d0));

        for (int i = 0; i < list.size(); ++i) {
            Entity entity = (Entity) list.get(i);

            if (!W_Lib.isEntityLivingBase(entity) && !(entity instanceof MCH_EntitySeat) && !(entity instanceof MCH_EntityHitBox) && entity != this.parents) {
                AxisAlignedBB axisalignedbb1 = entity.getBoundingBox();

                if (axisalignedbb1 != null && axisalignedbb1.intersectsWith(par2AxisAlignedBB)) {
                    collidingBoundingBoxes.add(axisalignedbb1);
                }

                axisalignedbb1 = par1Entity.getCollisionBox(entity);
                if (axisalignedbb1 != null && axisalignedbb1.intersectsWith(par2AxisAlignedBB)) {
                    collidingBoundingBoxes.add(axisalignedbb1);
                }
            }
        }

        return collidingBoundingBoxes;
    }
}

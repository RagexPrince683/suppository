package mcheli.eval.eval.repl;

import mcheli.eval.eval.exp.AbstractExpression;
import mcheli.eval.eval.exp.Col1Expression;
import mcheli.eval.eval.exp.Col2Expression;
import mcheli.eval.eval.exp.Col2OpeExpression;
import mcheli.eval.eval.exp.Col3Expression;
import mcheli.eval.eval.exp.FunctionExpression;
import mcheli.eval.eval.exp.WordExpression;

public interface Replace {

    AbstractExpression replace0(WordExpression wordexpression);

    AbstractExpression replace1(Col1Expression col1expression);

    AbstractExpression replace2(Col2Expression col2expression);

    AbstractExpression replace2(Col2OpeExpression col2opeexpression);

    AbstractExpression replace3(Col3Expression col3expression);

    AbstractExpression replaceVar0(WordExpression wordexpression);

    AbstractExpression replaceVar1(Col1Expression col1expression);

    AbstractExpression replaceVar2(Col2Expression col2expression);

    AbstractExpression replaceVar2(Col2OpeExpression col2opeexpression);

    AbstractExpression replaceVar3(Col3Expression col3expression);

    AbstractExpression replaceFunc(FunctionExpression functionexpression);

    AbstractExpression replaceLet(Col2Expression col2expression);
}

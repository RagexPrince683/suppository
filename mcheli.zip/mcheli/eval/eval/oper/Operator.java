package mcheli.eval.eval.oper;

public interface Operator {

    Object power(Object object, Object object1);

    Object signPlus(Object object);

    Object signMinus(Object object);

    Object plus(Object object, Object object1);

    Object minus(Object object, Object object1);

    Object mult(Object object, Object object1);

    Object div(Object object, Object object1);

    Object mod(Object object, Object object1);

    Object bitNot(Object object);

    Object shiftLeft(Object object, Object object1);

    Object shiftRight(Object object, Object object1);

    Object shiftRightLogical(Object object, Object object1);

    Object bitAnd(Object object, Object object1);

    Object bitOr(Object object, Object object1);

    Object bitXor(Object object, Object object1);

    Object not(Object object);

    Object equal(Object object, Object object1);

    Object notEqual(Object object, Object object1);

    Object lessThan(Object object, Object object1);

    Object lessEqual(Object object, Object object1);

    Object greaterThan(Object object, Object object1);

    Object greaterEqual(Object object, Object object1);

    boolean bool(Object object);

    Object inc(Object object, int i);
}

package mcheli.eval.eval.var;

public interface Variable {

    void setValue(Object object, Object object1);

    Object getObject(Object object);

    long evalLong(Object object);

    double evalDouble(Object object);

    Object getObject(Object object, int i);

    void setValue(Object object, int i, Object object1);

    Object getObject(Object object, String s);

    void setValue(Object object, String s, Object object1);
}

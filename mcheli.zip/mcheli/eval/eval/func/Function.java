package mcheli.eval.eval.func;

public interface Function {

    long evalLong(Object object, String s, Long[] along) throws Throwable;

    double evalDouble(Object object, String s, Double[] adouble) throws Throwable;

    Object evalObject(Object object, String s, Object[] aobject) throws Throwable;
}

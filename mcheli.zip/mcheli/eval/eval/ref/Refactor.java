package mcheli.eval.eval.ref;

public interface Refactor {

    String getNewName(Object object, String s);

    String getNewFuncName(Object object, String s);
}

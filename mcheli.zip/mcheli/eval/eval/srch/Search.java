package mcheli.eval.eval.srch;

import mcheli.eval.eval.exp.AbstractExpression;
import mcheli.eval.eval.exp.Col1Expression;
import mcheli.eval.eval.exp.Col2Expression;
import mcheli.eval.eval.exp.Col3Expression;
import mcheli.eval.eval.exp.FunctionExpression;
import mcheli.eval.eval.exp.WordExpression;

public interface Search {

    boolean end();

    void search(AbstractExpression abstractexpression);

    void search0(WordExpression wordexpression);

    boolean search1_begin(Col1Expression col1expression);

    void search1_end(Col1Expression col1expression);

    boolean search2_begin(Col2Expression col2expression);

    boolean search2_2(Col2Expression col2expression);

    void search2_end(Col2Expression col2expression);

    boolean search3_begin(Col3Expression col3expression);

    boolean search3_2(Col3Expression col3expression);

    boolean search3_3(Col3Expression col3expression);

    void search3_end(Col3Expression col3expression);

    boolean searchFunc_begin(FunctionExpression functionexpression);

    boolean searchFunc_2(FunctionExpression functionexpression);

    void searchFunc_end(FunctionExpression functionexpression);
}

package mcheli.eval.eval.exp;

import mcheli.eval.eval.EvalException;
import mcheli.eval.eval.lex.Lex;

public class VariableExpression extends WordExpression {

    public static AbstractExpression create(Lex lex, int prio) {
        VariableExpression exp = new VariableExpression(lex.getWord());

        exp.setPos(lex.getString(), lex.getPos());
        exp.setPriority(prio);
        exp.share = lex.getShare();
        return exp;
    }

    public VariableExpression(String str) {
        super(str);
    }

    protected VariableExpression(VariableExpression from, ShareExpValue s) {
        super((WordExpression) from, s);
    }

    public AbstractExpression dup(ShareExpValue s) {
        return new VariableExpression(this, s);
    }

    public long evalLong() {
        try {
            return this.share.var.evalLong(this.getVarValue());
        } catch (EvalException evalexception) {
            throw evalexception;
        } catch (Exception exception) {
            throw new EvalException(2003, this.word, this.string, this.pos, exception);
        }
    }

    public double evalDouble() {
        try {
            return this.share.var.evalDouble(this.getVarValue());
        } catch (EvalException evalexception) {
            throw evalexception;
        } catch (Exception exception) {
            throw new EvalException(2003, this.word, this.string, this.pos, exception);
        }
    }

    public Object evalObject() {
        return this.getVarValue();
    }

    protected void let(Object val, int pos) {
        String name = this.getWord();

        try {
            this.share.var.setValue(name, val);
        } catch (EvalException evalexception) {
            throw evalexception;
        } catch (Exception exception) {
            throw new EvalException(2102, name, this.string, pos, exception);
        }
    }

    private Object getVarValue() {
        String word = this.getWord();

        Object val;

        try {
            val = this.share.var.getObject(word);
        } catch (EvalException evalexception) {
            throw evalexception;
        } catch (Exception exception) {
            throw new EvalException(2101, word, this.string, this.pos, exception);
        }

        if (val == null) {
            throw new EvalException(2103, word, this.string, this.pos, (Throwable) null);
        } else {
            return val;
        }
    }

    protected Object getVariable() {
        try {
            return this.share.var.getObject(this.word);
        } catch (EvalException evalexception) {
            throw evalexception;
        } catch (Exception exception) {
            throw new EvalException(2002, this.word, this.string, this.pos, (Throwable) null);
        }
    }
}

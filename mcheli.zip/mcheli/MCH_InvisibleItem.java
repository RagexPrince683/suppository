package mcheli;

import mcheli.wrapper.W_Item;

public class MCH_InvisibleItem extends W_Item {

    public MCH_InvisibleItem(int par1) {
        super(par1);
    }
}

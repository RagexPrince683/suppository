package mcheli.lweapon;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import mcheli.MCH_ClientTickHandlerBase;
import mcheli.MCH_Config;
import mcheli.MCH_Key;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.aircraft.MCH_AircraftInfo;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.gltd.MCH_EntityGLTD;
import mcheli.weapon.MCH_IEntityLockChecker;
import mcheli.weapon.MCH_WeaponBase;
import mcheli.weapon.MCH_WeaponCreator;
import mcheli.weapon.MCH_WeaponGuidanceSystem;
import mcheli.wrapper.W_Entity;
import mcheli.wrapper.W_EntityPlayer;
import mcheli.wrapper.W_McClient;
import mcheli.wrapper.W_Network;
import mcheli.wrapper.W_Reflection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.Vec3;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class MCH_ClientLightWeaponTickHandler extends MCH_ClientTickHandlerBase {

    private static FloatBuffer screenPos = BufferUtils.createFloatBuffer(3);
    private static FloatBuffer screenPosBB = BufferUtils.createFloatBuffer(3);
    private static FloatBuffer matModel = BufferUtils.createFloatBuffer(16);
    private static FloatBuffer matProjection = BufferUtils.createFloatBuffer(16);
    private static IntBuffer matViewport = BufferUtils.createIntBuffer(16);
    protected boolean isHeldItem = false;
    protected boolean isBeforeHeldItem = false;
    protected EntityPlayer prevThePlayer = null;
    protected ItemStack prevItemStack = null;
    public MCH_Key KeyAttack;
    public MCH_Key KeyUseWeapon;
    public MCH_Key KeySwWeaponMode;
    public MCH_Key KeyZoom;
    public MCH_Key KeyCameraMode;
    public MCH_Key[] Keys;
    protected static MCH_WeaponBase weapon;
    public static int reloadCount;
    public static int lockonSoundCount;
    public static int weaponMode;
    public static int selectedZoom;
    public static Entity markEntity = null;
    public static Vec3 markPos = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
    public static MCH_WeaponGuidanceSystem gs = new MCH_WeaponGuidanceSystem();
    public static double lockRange = 120.0D;

    public MCH_ClientLightWeaponTickHandler(Minecraft minecraft, MCH_Config config) {
        super(minecraft);
        this.updateKeybind(config);
        MCH_ClientLightWeaponTickHandler.gs.canLockInAir = false;
        MCH_ClientLightWeaponTickHandler.gs.canLockOnGround = false;
        MCH_ClientLightWeaponTickHandler.gs.canLockInWater = false;
        MCH_ClientLightWeaponTickHandler.gs.setLockCountMax(40);
        MCH_ClientLightWeaponTickHandler.gs.lockRange = 120.0D;
        MCH_ClientLightWeaponTickHandler.lockonSoundCount = 0;
        this.initWeaponParam((EntityPlayer) null);
    }

    public static void markEntity(Entity entity, double x, double y, double z) {
        if (MCH_ClientLightWeaponTickHandler.gs.getLockingEntity() == entity) {
            GL11.glGetFloat(2982, MCH_ClientLightWeaponTickHandler.matModel);
            GL11.glGetFloat(2983, MCH_ClientLightWeaponTickHandler.matProjection);
            GL11.glGetInteger(2978, MCH_ClientLightWeaponTickHandler.matViewport);
            GLU.gluProject((float) x, (float) y, (float) z, MCH_ClientLightWeaponTickHandler.matModel, MCH_ClientLightWeaponTickHandler.matProjection, MCH_ClientLightWeaponTickHandler.matViewport, MCH_ClientLightWeaponTickHandler.screenPos);
            MCH_AircraftInfo i = entity instanceof MCH_EntityAircraft ? ((MCH_EntityAircraft) entity).getAcInfo() : null;
            float w = i != null ? i.markerWidth : (entity.width > entity.height ? entity.width : entity.height);
            float h = i != null ? i.markerHeight : entity.height;

            GLU.gluProject((float) x + w, (float) y + h, (float) z + w, MCH_ClientLightWeaponTickHandler.matModel, MCH_ClientLightWeaponTickHandler.matProjection, MCH_ClientLightWeaponTickHandler.matViewport, MCH_ClientLightWeaponTickHandler.screenPosBB);
            MCH_ClientLightWeaponTickHandler.markEntity = entity;
        }

    }

    public static Vec3 getMartEntityPos() {
        return MCH_ClientLightWeaponTickHandler.gs.getLockingEntity() == MCH_ClientLightWeaponTickHandler.markEntity && MCH_ClientLightWeaponTickHandler.markEntity != null ? Vec3.createVectorHelper((double) MCH_ClientLightWeaponTickHandler.screenPos.get(0), (double) MCH_ClientLightWeaponTickHandler.screenPos.get(1), (double) MCH_ClientLightWeaponTickHandler.screenPos.get(2)) : null;
    }

    public static Vec3 getMartEntityBBPos() {
        return MCH_ClientLightWeaponTickHandler.gs.getLockingEntity() == MCH_ClientLightWeaponTickHandler.markEntity && MCH_ClientLightWeaponTickHandler.markEntity != null ? Vec3.createVectorHelper((double) MCH_ClientLightWeaponTickHandler.screenPosBB.get(0), (double) MCH_ClientLightWeaponTickHandler.screenPosBB.get(1), (double) MCH_ClientLightWeaponTickHandler.screenPosBB.get(2)) : null;
    }

    public void initWeaponParam(EntityPlayer player) {
        MCH_ClientLightWeaponTickHandler.reloadCount = 0;
        MCH_ClientLightWeaponTickHandler.weaponMode = 0;
        MCH_ClientLightWeaponTickHandler.selectedZoom = 0;
    }

    public void updateKeybind(MCH_Config config) {
        this.KeyAttack = new MCH_Key(MCH_Config.KeyAttack.prmInt);
        this.KeyUseWeapon = new MCH_Key(MCH_Config.KeyUseWeapon.prmInt);
        this.KeySwWeaponMode = new MCH_Key(MCH_Config.KeySwWeaponMode.prmInt);
        this.KeyZoom = new MCH_Key(MCH_Config.KeyZoom.prmInt);
        this.KeyCameraMode = new MCH_Key(MCH_Config.KeyCameraMode.prmInt);
        this.Keys = new MCH_Key[] { this.KeyAttack, this.KeyUseWeapon, this.KeySwWeaponMode, this.KeyZoom, this.KeyCameraMode};
    }

    protected void onTick(boolean inGUI) {
        MCH_Key[] player = this.Keys;
        int is = player.length;

        for (int pc = 0; pc < is; ++pc) {
            MCH_Key RELOAD_CNT = player[pc];

            RELOAD_CNT.update();
        }

        this.isBeforeHeldItem = this.isHeldItem;
        EntityClientPlayerMP entityclientplayermp = this.mc.thePlayer;

        if (this.prevThePlayer == null || this.prevThePlayer != entityclientplayermp) {
            this.initWeaponParam(entityclientplayermp);
            this.prevThePlayer = entityclientplayermp;
        }

        ItemStack itemstack = entityclientplayermp != null ? entityclientplayermp.getHeldItem() : null;

        if (entityclientplayermp == null || entityclientplayermp.ridingEntity instanceof MCH_EntityGLTD || entityclientplayermp.ridingEntity instanceof MCH_EntityAircraft) {
            itemstack = null;
        }

        if (MCH_ClientLightWeaponTickHandler.gs.getLockingEntity() == null) {
            MCH_ClientLightWeaponTickHandler.markEntity = null;
        }

        if (itemstack != null && itemstack.getItem() instanceof MCH_ItemLightWeaponBase) {
            MCH_ItemLightWeaponBase mch_itemlightweaponbase = (MCH_ItemLightWeaponBase) itemstack.getItem();

            if (this.prevItemStack == null || !this.prevItemStack.isItemEqual(itemstack) && !this.prevItemStack.getUnlocalizedName().equals(itemstack.getUnlocalizedName())) {
                this.initWeaponParam(entityclientplayermp);
                MCH_ClientLightWeaponTickHandler.weapon = MCH_WeaponCreator.createWeapon(entityclientplayermp.worldObj, MCH_ItemLightWeaponBase.getName(itemstack), Vec3.createVectorHelper(0.0D, 0.0D, 0.0D), 0.0F, 0.0F, (MCH_IEntityLockChecker) null, false);
                if (MCH_ClientLightWeaponTickHandler.weapon != null && MCH_ClientLightWeaponTickHandler.weapon.getInfo() != null && MCH_ClientLightWeaponTickHandler.weapon.getGuidanceSystem() != null) {
                    MCH_ClientLightWeaponTickHandler.gs = MCH_ClientLightWeaponTickHandler.weapon.getGuidanceSystem();
                }
            }

            if (MCH_ClientLightWeaponTickHandler.weapon == null || MCH_ClientLightWeaponTickHandler.gs == null) {
                return;
            }

            MCH_ClientLightWeaponTickHandler.gs.setWorld(entityclientplayermp.worldObj);
            MCH_ClientLightWeaponTickHandler.gs.lockRange = MCH_ClientLightWeaponTickHandler.lockRange;
            if (entityclientplayermp.getItemInUseDuration() > 10) {
                MCH_ClientLightWeaponTickHandler.selectedZoom %= MCH_ClientLightWeaponTickHandler.weapon.getInfo().zoom.length;
                W_Reflection.setCameraZoom(MCH_ClientLightWeaponTickHandler.weapon.getInfo().zoom[MCH_ClientLightWeaponTickHandler.selectedZoom]);
            } else {
                W_Reflection.restoreCameraZoom();
            }

            if (itemstack.getItemDamage() < itemstack.getMaxDamage()) {
                if (entityclientplayermp.getItemInUseDuration() > 10) {
                    MCH_ClientLightWeaponTickHandler.gs.lock(entityclientplayermp);
                    if (MCH_ClientLightWeaponTickHandler.gs.getLockCount() > 0) {
                        if (MCH_ClientLightWeaponTickHandler.lockonSoundCount > 0) {
                            --MCH_ClientLightWeaponTickHandler.lockonSoundCount;
                        } else {
                            MCH_ClientLightWeaponTickHandler.lockonSoundCount = 7;
                            MCH_ClientLightWeaponTickHandler.lockonSoundCount = (int) ((double) MCH_ClientLightWeaponTickHandler.lockonSoundCount * (1.0D - (double) MCH_ClientLightWeaponTickHandler.gs.getLockCount() / (double) MCH_ClientLightWeaponTickHandler.gs.getLockCountMax()));
                            if (MCH_ClientLightWeaponTickHandler.lockonSoundCount < 3) {
                                MCH_ClientLightWeaponTickHandler.lockonSoundCount = 2;
                            }

                            W_McClient.MOD_playSoundFX("lockon", 1.0F, 1.0F);
                        }
                    }
                } else {
                    W_Reflection.restoreCameraZoom();
                    MCH_ClientLightWeaponTickHandler.gs.clearLock();
                }

                MCH_ClientLightWeaponTickHandler.reloadCount = 0;
            } else {
                MCH_ClientLightWeaponTickHandler.lockonSoundCount = 0;
                if (W_EntityPlayer.hasItem(entityclientplayermp, mch_itemlightweaponbase.bullet) && entityclientplayermp.getItemInUseCount() <= 0) {
                    if (MCH_ClientLightWeaponTickHandler.reloadCount == 10) {
                        W_McClient.MOD_playSoundFX("fim92_reload", 1.0F, 1.0F);
                    }

                    boolean flag = true;

                    if (MCH_ClientLightWeaponTickHandler.reloadCount < 40) {
                        ++MCH_ClientLightWeaponTickHandler.reloadCount;
                        if (MCH_ClientLightWeaponTickHandler.reloadCount == 40) {
                            this.onCompleteReload();
                        }
                    }
                } else {
                    MCH_ClientLightWeaponTickHandler.reloadCount = 0;
                }

                MCH_ClientLightWeaponTickHandler.gs.clearLock();
            }

            if (!inGUI) {
                this.playerControl(entityclientplayermp, itemstack, (MCH_ItemLightWeaponBase) itemstack.getItem());
            }

            this.isHeldItem = MCH_ItemLightWeaponBase.isHeld(entityclientplayermp);
        } else {
            MCH_ClientLightWeaponTickHandler.lockonSoundCount = 0;
            MCH_ClientLightWeaponTickHandler.reloadCount = 0;
            this.isHeldItem = false;
        }

        if (this.isBeforeHeldItem != this.isHeldItem) {
            MCH_Lib.DbgLog(true, "LWeapon cancel", new Object[0]);
            if (!this.isHeldItem) {
                if (getPotionNightVisionDuration(entityclientplayermp) < 250) {
                    MCH_PacketLightWeaponPlayerControl mch_packetlightweaponplayercontrol = new MCH_PacketLightWeaponPlayerControl();

                    mch_packetlightweaponplayercontrol.camMode = 1;
                    W_Network.sendToServer(mch_packetlightweaponplayercontrol);
                    entityclientplayermp.removePotionEffectClient(Potion.nightVision.getId());
                }

                W_Reflection.restoreCameraZoom();
            }
        }

        this.prevItemStack = itemstack;
        MCH_ClientLightWeaponTickHandler.gs.update();
    }

    protected void onCompleteReload() {
        MCH_PacketLightWeaponPlayerControl pc = new MCH_PacketLightWeaponPlayerControl();

        pc.cmpReload = 1;
        W_Network.sendToServer(pc);
    }

    protected void playerControl(EntityPlayer player, ItemStack is, MCH_ItemLightWeaponBase item) {
        MCH_PacketLightWeaponPlayerControl pc = new MCH_PacketLightWeaponPlayerControl();
        boolean send = false;
        boolean autoShot = false;
        MCH_Config mch_config = MCH_MOD.config;

        if (MCH_Config.LWeaponAutoFire.prmBool && is.getItemDamage() < is.getMaxDamage() && MCH_ClientLightWeaponTickHandler.gs.isLockComplete()) {
            autoShot = true;
        }

        if (this.KeySwWeaponMode.isKeyDown() && MCH_ClientLightWeaponTickHandler.weapon.numMode > 1) {
            MCH_ClientLightWeaponTickHandler.weaponMode = (MCH_ClientLightWeaponTickHandler.weaponMode + 1) % MCH_ClientLightWeaponTickHandler.weapon.numMode;
            W_McClient.MOD_playSoundFX("pi", 0.5F, 0.9F);
        }

        if (this.KeyAttack.isKeyPress() || autoShot) {
            boolean pe = false;

            if (is.getItemDamage() < is.getMaxDamage() && MCH_ClientLightWeaponTickHandler.gs.isLockComplete()) {
                boolean canFire = true;

                if (MCH_ClientLightWeaponTickHandler.weaponMode > 0 && MCH_ClientLightWeaponTickHandler.gs.getTargetEntity() != null) {
                    double dx = MCH_ClientLightWeaponTickHandler.gs.getTargetEntity().posX - player.posX;
                    double dz = MCH_ClientLightWeaponTickHandler.gs.getTargetEntity().posZ - player.posZ;

                    canFire = Math.sqrt(dx * dx + dz * dz) >= 40.0D;
                }

                if (canFire) {
                    pc.useWeapon = true;
                    pc.useWeaponOption1 = W_Entity.getEntityId(MCH_ClientLightWeaponTickHandler.gs.lastLockEntity);
                    pc.useWeaponOption2 = MCH_ClientLightWeaponTickHandler.weaponMode;
                    pc.useWeaponPosX = player.posX;
                    pc.useWeaponPosY = player.posY;
                    pc.useWeaponPosZ = player.posZ;
                    MCH_ClientLightWeaponTickHandler.gs.clearLock();
                    send = true;
                    pe = true;
                }
            }

            if (this.KeyAttack.isKeyDown() && !pe && player.getItemInUseDuration() > 5) {
                playSoundNG();
            }
        }

        if (this.KeyZoom.isKeyDown()) {
            int pe1 = MCH_ClientLightWeaponTickHandler.selectedZoom;

            MCH_ClientLightWeaponTickHandler.selectedZoom = (MCH_ClientLightWeaponTickHandler.selectedZoom + 1) % MCH_ClientLightWeaponTickHandler.weapon.getInfo().zoom.length;
            if (pe1 != MCH_ClientLightWeaponTickHandler.selectedZoom) {
                playSound("zoom", 0.5F, 1.0F);
            }
        }

        if (this.KeyCameraMode.isKeyDown()) {
            PotionEffect pe2 = player.getActivePotionEffect(Potion.nightVision);

            MCH_Lib.DbgLog(true, "LWeapon NV %s", new Object[] { pe2 != null ? "ON->OFF" : "OFF->ON"});
            if (pe2 != null) {
                player.removePotionEffectClient(Potion.nightVision.getId());
                pc.camMode = 1;
                send = true;
                W_McClient.MOD_playSoundFX("pi", 0.5F, 0.9F);
            } else if (player.getItemInUseDuration() > 60) {
                pc.camMode = 2;
                send = true;
                W_McClient.MOD_playSoundFX("pi", 0.5F, 0.9F);
            } else {
                playSoundNG();
            }
        }

        if (send) {
            W_Network.sendToServer(pc);
        }

    }

    public static int getPotionNightVisionDuration(EntityPlayer player) {
        PotionEffect cpe = player.getActivePotionEffect(Potion.nightVision);

        return player != null && cpe != null ? cpe.getDuration() : 0;
    }
}

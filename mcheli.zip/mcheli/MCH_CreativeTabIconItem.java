package mcheli;

import mcheli.wrapper.W_Item;

public class MCH_CreativeTabIconItem extends W_Item {

    public MCH_CreativeTabIconItem(int a) {
        super(a);
    }
}

package mcheli.wrapper;

import net.minecraft.util.IIcon;

public class Icon implements IIcon {

    public int getIconWidth() {
        return 0;
    }

    public int getIconHeight() {
        return 0;
    }

    public float getMinU() {
        return 0.0F;
    }

    public float getMaxU() {
        return 0.0F;
    }

    public float getInterpolatedU(double d0) {
        return 0.0F;
    }

    public float getMinV() {
        return 0.0F;
    }

    public float getMaxV() {
        return 0.0F;
    }

    public float getInterpolatedV(double d0) {
        return 0.0F;
    }

    public String getIconName() {
        return null;
    }
}

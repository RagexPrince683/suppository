package mcheli.wrapper;

public class W_MOD {

    public static String DOMAIN = "mcheli";
}

package mcheli.wrapper;

import cpw.mods.fml.common.ObfuscationReflectionHelper;
import java.util.List;
import java.util.Queue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.NetworkSystem;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;

public class W_Reflection {

    public static RenderManager getRenderManager(Render render) {
        try {
            return (RenderManager) ObfuscationReflectionHelper.getPrivateValue(Render.class, render, new String[] { "renderManager", "renderManager"});
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static void restoreDefaultThirdPersonDistance() {
        setThirdPersonDistance(4.0F);
    }

    public static void setThirdPersonDistance(float dist) {
        if ((double) dist >= 0.1D) {
            try {
                Minecraft e = Minecraft.getMinecraft();

                ObfuscationReflectionHelper.setPrivateValue(EntityRenderer.class, e.entityRenderer, Float.valueOf(dist), new String[] { "thirdPersonDistance", "thirdPersonDistance"});
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        }
    }

    public static float getThirdPersonDistance() {
        try {
            Minecraft e = Minecraft.getMinecraft();

            return ((Float) ObfuscationReflectionHelper.getPrivateValue(EntityRenderer.class, e.entityRenderer, new String[] { "thirdPersonDistance", "thirdPersonDistance"})).floatValue();
        } catch (Exception exception) {
            exception.printStackTrace();
            return 4.0F;
        }
    }

    public static void setCameraRoll(float roll) {
        try {
            roll = MathHelper.wrapAngleTo180_float(roll);
            Minecraft e = Minecraft.getMinecraft();

            ObfuscationReflectionHelper.setPrivateValue(EntityRenderer.class, Minecraft.getMinecraft().entityRenderer, Float.valueOf(roll), new String[] { "camRoll", "camRoll"});
            ObfuscationReflectionHelper.setPrivateValue(EntityRenderer.class, Minecraft.getMinecraft().entityRenderer, Float.valueOf(roll), new String[] { "prevCamRoll", "prevCamRoll"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static float getPrevCameraRoll() {
        try {
            Minecraft e = Minecraft.getMinecraft();

            return ((Float) ObfuscationReflectionHelper.getPrivateValue(EntityRenderer.class, Minecraft.getMinecraft().entityRenderer, new String[] { "prevCamRoll", "prevCamRoll"})).floatValue();
        } catch (Exception exception) {
            exception.printStackTrace();
            return 0.0F;
        }
    }

    public static void restoreCameraZoom() {
        setCameraZoom(1.0F);
    }

    public static void setCameraZoom(float zoom) {
        try {
            Minecraft e = Minecraft.getMinecraft();

            ObfuscationReflectionHelper.setPrivateValue(EntityRenderer.class, e.entityRenderer, Float.valueOf(zoom), new String[] { "cameraZoom", "cameraZoom"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static void setItemRenderer(ItemRenderer r) {
        try {
            Minecraft e = Minecraft.getMinecraft();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static void setCreativeDigSpeed(int n) {
        try {
            Minecraft e = Minecraft.getMinecraft();

            ObfuscationReflectionHelper.setPrivateValue(PlayerControllerMP.class, e.playerController, Integer.valueOf(n), new String[] { "blockHitDelay", "blockHitDelay"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static ItemRenderer getItemRenderer() {
        return Minecraft.getMinecraft().entityRenderer.itemRenderer;
    }

    public static void setItemRenderer_ItemToRender(ItemStack itemToRender) {
        try {
            ObfuscationReflectionHelper.setPrivateValue(ItemRenderer.class, getItemRenderer(), itemToRender, new String[] { "itemToRender", "itemToRender"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static ItemStack getItemRenderer_ItemToRender() {
        try {
            ItemStack e = (ItemStack) ObfuscationReflectionHelper.getPrivateValue(ItemRenderer.class, getItemRenderer(), new String[] { "itemToRender", "itemToRender"});

            return e;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static void setItemRendererProgress(float equippedProgress) {
        try {
            ObfuscationReflectionHelper.setPrivateValue(ItemRenderer.class, getItemRenderer(), Float.valueOf(equippedProgress), new String[] { "equippedProgress", "equippedProgress"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static void setBoundingBox(Entity entity, AxisAlignedBB bb) {
        try {
            ObfuscationReflectionHelper.setPrivateValue(Entity.class, entity, bb, new String[] { "boundingBox", "boundingBox"});
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public static List getNetworkManagers() {
        try {
            List e = (List) ObfuscationReflectionHelper.getPrivateValue(NetworkSystem.class, MinecraftServer.getServer().getNetworkSystem(), new String[] { "networkManagers", "networkManagers"});

            return e;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static Queue getReceivedPacketsQueue(NetworkManager nm) {
        try {
            Queue e = (Queue) ObfuscationReflectionHelper.getPrivateValue(NetworkManager.class, nm, new String[] { "receivedPacketsQueue", "receivedPacketsQueue"});

            return e;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static Queue getSendPacketsQueue(NetworkManager nm) {
        try {
            Queue e = (Queue) ObfuscationReflectionHelper.getPrivateValue(NetworkManager.class, nm, new String[] { "outboundPacketsQueue", "outboundPacketsQueue"});

            return e;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }
}

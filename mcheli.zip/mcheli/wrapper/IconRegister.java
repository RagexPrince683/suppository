package mcheli.wrapper;

import net.minecraft.util.IIcon;

public interface IconRegister {

    IIcon registerIcon(String s);
}

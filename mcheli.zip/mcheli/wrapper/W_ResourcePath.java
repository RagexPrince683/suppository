package mcheli.wrapper;

public class W_ResourcePath {

    public static String getModelPath() {
        return "";
    }
}

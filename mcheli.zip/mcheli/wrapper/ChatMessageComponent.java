package mcheli.wrapper;

public class ChatMessageComponent {

}

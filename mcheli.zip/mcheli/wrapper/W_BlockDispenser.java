package mcheli.wrapper;

import net.minecraft.block.BlockDispenser;
import net.minecraft.util.EnumFacing;

public class W_BlockDispenser {

    public static EnumFacing getFacing(int par0) {
        return BlockDispenser.getFacingDirection(par0);
    }
}

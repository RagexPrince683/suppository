package mcheli.wrapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import mcheli.MCH_Lib;
import mcheli.MCH_OutputFile;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.stats.Achievement;

public class W_LanguageRegistry {

    private static HashMap map = new HashMap();

    public static void addName(Object objectToName, String name) {
        addNameForObject(objectToName, "en_US", name);
    }

    public static void addNameForObject(Object o, String lang, String name) {
        addNameForObject(o, lang, name, "", "");
    }

    public static void addNameForObject(Object o, String lang, String name, String key, String desc) {
        if (o != null) {
            if (!W_LanguageRegistry.map.containsKey(lang)) {
                W_LanguageRegistry.map.put(lang, new ArrayList());
            }

            if (o instanceof Item) {
                ((ArrayList) W_LanguageRegistry.map.get(lang)).add(((Item) o).getUnlocalizedName() + ".name=" + name);
            }

            if (o instanceof Block) {
                ((ArrayList) W_LanguageRegistry.map.get(lang)).add(((Block) o).getUnlocalizedName() + ".name=" + name);
            } else if (o instanceof Achievement) {
                ((ArrayList) W_LanguageRegistry.map.get(lang)).add("achievement." + key + "=" + name);
                ((ArrayList) W_LanguageRegistry.map.get(lang)).add("achievement." + key + ".desc=" + desc);
            }

        }
    }

    public static void updateLang(String filePath) {
        Iterator i$ = W_LanguageRegistry.map.keySet().iterator();

        while (i$.hasNext()) {
            String key = (String) i$.next();
            ArrayList list = (ArrayList) W_LanguageRegistry.map.get(key);
            MCH_OutputFile file = new MCH_OutputFile();

            if (file.openUTF8(filePath + key + ".lang")) {
                Iterator i$1 = list.iterator();

                while (i$1.hasNext()) {
                    String s = (String) i$1.next();

                    file.writeLine(s);
                }

                MCH_Lib.Log("[mcheli] Update lang:" + file.file.getAbsolutePath(), new Object[0]);
                file.close();
            }
        }

        W_LanguageRegistry.map = null;
    }
}

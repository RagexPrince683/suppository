package mcheli.wrapper;

import mcheli.MCH_MOD;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class W_Lib {

    public static boolean isEntityLivingBase(Entity entity) {
        return entity instanceof EntityLivingBase;
    }

    public static EntityLivingBase castEntityLivingBase(Object entity) {
        return (EntityLivingBase) entity;
    }

    public static Class getEntityLivingBaseClass() {
        return EntityLivingBase.class;
    }

    public static double getEntityMoveDist(Entity entity) {
        return entity == null ? 0.0D : (entity instanceof EntityLivingBase ? (double) ((EntityLivingBase) entity).moveForward : 0.0D);
    }

    public static boolean isClientPlayer(Entity entity) {
        return entity instanceof EntityPlayer && entity.worldObj.isRemote ? W_Entity.isEqual(MCH_MOD.proxy.getClientPlayer(), entity) : false;
    }

    public static boolean isFirstPerson() {
        return MCH_MOD.proxy.isFirstPerson();
    }
}

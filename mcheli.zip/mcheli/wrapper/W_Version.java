package mcheli.wrapper;

public class W_Version {

    public static final boolean VER_1_7 = true;
    public static final boolean VER_1_6 = false;
    public static final boolean VER_1_5 = false;
    public static final boolean VER_1_4 = false;
    public static final int VER = 173;
    public static final int MC150 = 150;
    public static final int MC160 = 160;
    public static final int MC170 = 170;
    public static final String VER_STR = "1.7.10";
}

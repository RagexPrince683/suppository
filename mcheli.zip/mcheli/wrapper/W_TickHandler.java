package mcheli.wrapper;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent.ClientTickEvent;
import cpw.mods.fml.common.gameevent.TickEvent.Phase;
import cpw.mods.fml.common.gameevent.TickEvent.PlayerTickEvent;
import cpw.mods.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public abstract class W_TickHandler implements ITickHandler {

    protected Minecraft mc;

    public W_TickHandler(Minecraft m) {
        this.mc = m;
    }

    public void onPlayerTickPre(EntityPlayer player) {}

    public void onPlayerTickPost(EntityPlayer player) {}

    public void onRenderTickPre(float partialTicks) {}

    public void onRenderTickPost(float partialTicks) {}

    public void onTickPre() {}

    public void onTickPost() {}

    @SubscribeEvent
    public void onPlayerTickEvent(PlayerTickEvent event) {
        Phase phase = event.phase;

        if (event.phase == Phase.START) {
            this.onPlayerTickPre(event.player);
        }

        phase = event.phase;
        if (event.phase == Phase.END) {
            this.onPlayerTickPost(event.player);
        }

    }

    @SubscribeEvent
    public void onClientTickEvent(ClientTickEvent event) {
        Phase phase = event.phase;

        if (event.phase == Phase.START) {
            this.onTickPre();
        }

        phase = event.phase;
        if (event.phase == Phase.END) {
            this.onTickPost();
        }

    }

    @SubscribeEvent
    public void onRenderTickEvent(RenderTickEvent event) {
        Phase phase = event.phase;

        if (event.phase == Phase.START) {
            this.onRenderTickPre(event.renderTickTime);
        }

        phase = event.phase;
        if (event.phase == Phase.END) {
            this.onRenderTickPost(event.renderTickTime);
        }

    }

    static enum TickType {

        RENDER, CLIENT;
    }
}

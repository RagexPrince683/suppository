package mcheli.wrapper;

import net.minecraft.init.Blocks;

public class W_Blocks extends Blocks {

}

package mcheli.wrapper;

public interface ITickHandler {}

package mcheli.wrapper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class W_ScaledResolution extends ScaledResolution {

    public W_ScaledResolution(Minecraft mc, int x, int y) {
        super(mc, x, y);
    }
}

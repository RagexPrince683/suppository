package mcheli.wrapper;

public @interface NetworkMod {

    boolean clientSideRequired();

    boolean serverSideRequired();
}

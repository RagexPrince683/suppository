package mcheli.wrapper;

public interface IPacketHandler {}

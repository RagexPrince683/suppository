package mcheli.wrapper;

import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemArmor.ArmorMaterial;

public class W_ItemArmor extends ItemArmor {

    public W_ItemArmor(int par1, int par3, int par4) {
        super((ArmorMaterial) null, par3, par4);
    }
}

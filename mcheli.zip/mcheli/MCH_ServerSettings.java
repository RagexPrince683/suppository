package mcheli;

public class MCH_ServerSettings {

    public static boolean enableCamDistChange = true;
    public static boolean enableEntityMarker = true;
    public static boolean enablePVP = true;
    public static double stingerLockRange = 120.0D;
    public static boolean enableDebugBoundingBox = true;
}

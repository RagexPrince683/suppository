package mcheli.multiplay;

public enum MCH_TargetType {

    NONE, OTHER_MOB, MONSTER, NO_TEAM_PLAYER, SAME_TEAM_PLAYER, OTHER_TEAM_PLAYER, POINT;
}

package mcheli.multiplay;

public interface MCH_IGuiScoreboard {

    void switchScreen(MCH_GuiScoreboard_Base.SCREEN_ID mch_guiscoreboard_base_screen_id);
}

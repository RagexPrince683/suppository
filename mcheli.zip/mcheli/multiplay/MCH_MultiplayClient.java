package mcheli.multiplay;

import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.ModContainer;
import cpw.mods.fml.relauncher.CoreModManager;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import javax.imageio.ImageIO;
import mcheli.MCH_Config;
import mcheli.MCH_FileSearch;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.MCH_OStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class MCH_MultiplayClient {

    private static IntBuffer pixelBuffer;
    private static int[] pixelValues;
    private static MCH_OStream dataOutputStream;
    private static List modList = new ArrayList();

    public static void startSendImageData() {
        Minecraft mc = Minecraft.getMinecraft();

        sendScreenShot(mc.displayWidth, mc.displayHeight, mc.getFramebuffer());
    }

    public static void sendScreenShot(int displayWidth, int displayHeight, Framebuffer framebufferMc) {
        try {
            if (OpenGlHelper.isFramebufferEnabled()) {
                displayWidth = framebufferMc.framebufferTextureWidth;
                displayHeight = framebufferMc.framebufferTextureHeight;
            }

            int exception = displayWidth * displayHeight;

            if (MCH_MultiplayClient.pixelBuffer == null || MCH_MultiplayClient.pixelBuffer.capacity() < exception) {
                MCH_MultiplayClient.pixelBuffer = BufferUtils.createIntBuffer(exception);
                MCH_MultiplayClient.pixelValues = new int[exception];
            }

            GL11.glPixelStorei(3333, 1);
            GL11.glPixelStorei(3317, 1);
            MCH_MultiplayClient.pixelBuffer.clear();
            if (OpenGlHelper.isFramebufferEnabled()) {
                GL11.glBindTexture(3553, framebufferMc.framebufferTexture);
                GL11.glGetTexImage(3553, 0, '胡', '�?�', MCH_MultiplayClient.pixelBuffer);
            } else {
                GL11.glReadPixels(0, 0, displayWidth, displayHeight, '胡', '�?�', MCH_MultiplayClient.pixelBuffer);
            }

            MCH_MultiplayClient.pixelBuffer.get(MCH_MultiplayClient.pixelValues);
            TextureUtil.func_147953_a(MCH_MultiplayClient.pixelValues, displayWidth, displayHeight);
            BufferedImage bufferedimage = null;

            if (OpenGlHelper.isFramebufferEnabled()) {
                bufferedimage = new BufferedImage(framebufferMc.framebufferWidth, framebufferMc.framebufferHeight, 1);
                int l = framebufferMc.framebufferTextureHeight - framebufferMc.framebufferHeight;

                for (int i1 = l; i1 < framebufferMc.framebufferTextureHeight; ++i1) {
                    for (int j1 = 0; j1 < framebufferMc.framebufferWidth; ++j1) {
                        bufferedimage.setRGB(j1, i1 - l, MCH_MultiplayClient.pixelValues[i1 * framebufferMc.framebufferTextureWidth + j1]);
                    }
                }
            } else {
                bufferedimage = new BufferedImage(displayWidth, displayHeight, 1);
                bufferedimage.setRGB(0, 0, displayWidth, displayHeight, MCH_MultiplayClient.pixelValues, 0, displayWidth);
            }

            MCH_MultiplayClient.dataOutputStream = new MCH_OStream();
            ImageIO.write(bufferedimage, "png", MCH_MultiplayClient.dataOutputStream);
        } catch (Exception exception) {
            ;
        }

    }

    public static void readImageData(DataOutputStream dos) throws IOException {
        MCH_MultiplayClient.dataOutputStream.write(dos);
    }

    public static void sendImageData() {
        if (MCH_MultiplayClient.dataOutputStream != null) {
            MCH_PacketLargeData.send();
            if (MCH_MultiplayClient.dataOutputStream.isDataEnd()) {
                MCH_MultiplayClient.dataOutputStream = null;
            }
        }

    }

    public static double getPerData() {
        return MCH_MultiplayClient.dataOutputStream == null ? -1.0D : (double) MCH_MultiplayClient.dataOutputStream.index / (double) MCH_MultiplayClient.dataOutputStream.size();
    }

    public static void readModList(String playerName) {
        MCH_MultiplayClient.modList = new ArrayList();
        MCH_MultiplayClient.modList.add(EnumChatFormatting.RED + "###### " + playerName + " ######");
        String[] classFileNameList = System.getProperty("java.class.path").split(File.pathSeparator);
        String[] mc = classFileNameList;
        int search = classFileNameList.length;

        for (int files = 0; files < search; ++files) {
            String arr$ = mc[files];

            MCH_Lib.DbgLog(true, "java.class.path=" + arr$, new Object[0]);
            if (arr$.length() > 1) {
                File len$ = new File(arr$);

                if (len$.getAbsolutePath().toLowerCase().indexOf("versions") >= 0) {
                    MCH_MultiplayClient.modList.add(EnumChatFormatting.AQUA + "# Client class=" + len$.getName() + " : file size= " + len$.length());
                }
            }
        }

        MCH_MultiplayClient.modList.add(EnumChatFormatting.YELLOW + "=== ActiveModList ===");
        Iterator iterator = Loader.instance().getActiveModList().iterator();

        while (iterator.hasNext()) {
            ModContainer modcontainer = (ModContainer) iterator.next();

            MCH_MultiplayClient.modList.add("" + modcontainer + "  [" + modcontainer.getModId() + "]  " + modcontainer.getName() + "[" + modcontainer.getDisplayVersion() + "]  " + modcontainer.getSource().getName());
        }

        String s;

        if (CoreModManager.getAccessTransformers().size() > 0) {
            MCH_MultiplayClient.modList.add(EnumChatFormatting.YELLOW + "=== AccessTransformers ===");
            iterator = CoreModManager.getAccessTransformers().iterator();

            while (iterator.hasNext()) {
                s = (String) iterator.next();
                MCH_MultiplayClient.modList.add(s);
            }
        }

        if (CoreModManager.getLoadedCoremods().size() > 0) {
            MCH_MultiplayClient.modList.add(EnumChatFormatting.YELLOW + "=== LoadedCoremods ===");
            iterator = CoreModManager.getLoadedCoremods().iterator();

            while (iterator.hasNext()) {
                s = (String) iterator.next();
                MCH_MultiplayClient.modList.add(s);
            }
        }

        if (CoreModManager.getReparseableCoremods().size() > 0) {
            MCH_MultiplayClient.modList.add(EnumChatFormatting.YELLOW + "=== ReparseableCoremods ===");
            iterator = CoreModManager.getReparseableCoremods().iterator();

            while (iterator.hasNext()) {
                s = (String) iterator.next();
                MCH_MultiplayClient.modList.add(s);
            }
        }

        Minecraft minecraft = Minecraft.getMinecraft();
        MCH_FileSearch mch_filesearch = new MCH_FileSearch();
        File[] afile = mch_filesearch.listFiles((new File(minecraft.mcDataDir, "mods")).getAbsolutePath(), "*.jar");

        MCH_MultiplayClient.modList.add(EnumChatFormatting.YELLOW + "=== Manifest ===");
        File[] afile1 = afile;
        int i = afile.length;

        int i$;
        File file;
        String e;
        JarFile jarFile;
        Enumeration jarEntries;
        String litemod_json;
        ZipEntry zipEntry;

        for (i$ = 0; i$ < i; ++i$) {
            file = afile1[i$];

            try {
                e = file.getCanonicalPath();
                jarFile = new JarFile(e);
                jarEntries = jarFile.entries();
                litemod_json = "";

                while (jarEntries.hasMoreElements()) {
                    zipEntry = (ZipEntry) jarEntries.nextElement();
                    if (zipEntry.getName().equalsIgnoreCase("META-INF/MANIFEST.MF") && !zipEntry.isDirectory()) {
                        InputStream fname = jarFile.getInputStream(zipEntry);
                        BufferedReader index = new BufferedReader(new InputStreamReader(fname));

                        for (String br = index.readLine(); br != null; br = index.readLine()) {
                            br = br.replace(" ", "").trim();
                            if (!br.isEmpty()) {
                                litemod_json = litemod_json + " [" + br + "]";
                            }
                        }

                        fname.close();
                        break;
                    }
                }

                jarFile.close();
                if (!litemod_json.isEmpty()) {
                    MCH_MultiplayClient.modList.add(file.getName() + litemod_json);
                }
            } catch (Exception exception) {
                MCH_MultiplayClient.modList.add(file.getName() + " : Read Manifest failed.");
            }
        }

        mch_filesearch = new MCH_FileSearch();
        afile = mch_filesearch.listFiles((new File(minecraft.mcDataDir, "mods")).getAbsolutePath(), "*.litemod");
        MCH_MultiplayClient.modList.add(EnumChatFormatting.LIGHT_PURPLE + "=== LiteLoader ===");
        afile1 = afile;
        i = afile.length;

        for (i$ = 0; i$ < i; ++i$) {
            file = afile1[i$];

            try {
                e = file.getCanonicalPath();
                jarFile = new JarFile(e);
                jarEntries = jarFile.entries();
                litemod_json = "";

                while (jarEntries.hasMoreElements()) {
                    zipEntry = (ZipEntry) jarEntries.nextElement();
                    String s1 = zipEntry.getName().toLowerCase();

                    if (!zipEntry.isDirectory()) {
                        if (!s1.equals("litemod.json")) {
                            int j = s1.lastIndexOf("/");

                            if (j >= 0) {
                                s1 = s1.substring(j + 1);
                            }

                            if (s1.indexOf("litemod") >= 0 && s1.endsWith("class")) {
                                s1 = zipEntry.getName();
                                if (j >= 0) {
                                    s1 = s1.substring(j + 1);
                                }

                                litemod_json = litemod_json + " [" + s1 + "]";
                            }
                        } else {
                            InputStream inputstream = jarFile.getInputStream(zipEntry);
                            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream));

                            for (String line = bufferedreader.readLine(); line != null; line = bufferedreader.readLine()) {
                                line = line.replace(" ", "").trim();
                                if (line.toLowerCase().indexOf("name") >= 0) {
                                    litemod_json = litemod_json + " [" + line + "]";
                                    break;
                                }
                            }

                            inputstream.close();
                        }
                    }
                }

                jarFile.close();
                if (!litemod_json.isEmpty()) {
                    MCH_MultiplayClient.modList.add(file.getName() + litemod_json);
                }
            } catch (Exception exception1) {
                MCH_MultiplayClient.modList.add(file.getName() + " : Read LiteLoader failed.");
            }
        }

    }

    public static void sendModsInfo(String playerName, int id) {
        MCH_Config mch_config = MCH_MOD.config;

        if (MCH_Config.DebugLog) {
            MCH_MultiplayClient.modList.clear();
            readModList(playerName);
        }

        MCH_PacketModList.send(MCH_MultiplayClient.modList, id);
    }
}

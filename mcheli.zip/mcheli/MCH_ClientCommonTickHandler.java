package mcheli;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import mcheli.aircraft.MCH_AircraftInfo;
import mcheli.aircraft.MCH_ClientSeatTickHandler;
import mcheli.aircraft.MCH_EntityAircraft;
import mcheli.aircraft.MCH_EntitySeat;
import mcheli.aircraft.MCH_SeatInfo;
import mcheli.command.MCH_GuiTitle;
import mcheli.gltd.MCH_ClientGLTDTickHandler;
import mcheli.gltd.MCH_EntityGLTD;
import mcheli.gltd.MCH_GuiGLTD;
import mcheli.gui.MCH_Gui;
import mcheli.helicopter.MCH_ClientHeliTickHandler;
import mcheli.helicopter.MCH_EntityHeli;
import mcheli.helicopter.MCH_GuiHeli;
import mcheli.lweapon.MCH_ClientLightWeaponTickHandler;
import mcheli.lweapon.MCH_GuiLightWeapon;
import mcheli.multiplay.MCH_GuiScoreboard;
import mcheli.multiplay.MCH_GuiTargetMarker;
import mcheli.multiplay.MCH_MultiplayClient;
import mcheli.plane.MCP_ClientPlaneTickHandler;
import mcheli.plane.MCP_EntityPlane;
import mcheli.plane.MCP_GuiPlane;
import mcheli.tank.MCH_ClientTankTickHandler;
import mcheli.tank.MCH_EntityTank;
import mcheli.tank.MCH_GuiTank;
import mcheli.tool.MCH_ClientToolTickHandler;
import mcheli.tool.MCH_GuiWrench;
import mcheli.tool.MCH_ItemWrench;
import mcheli.tool.rangefinder.MCH_GuiRangeFinder;
import mcheli.uav.MCH_EntityUavStation;
import mcheli.vehicle.MCH_ClientVehicleTickHandler;
import mcheli.vehicle.MCH_EntityVehicle;
import mcheli.vehicle.MCH_GuiVehicle;
import mcheli.weapon.MCH_WeaponSet;
import mcheli.wrapper.W_Lib;
import mcheli.wrapper.W_McClient;
import mcheli.wrapper.W_Reflection;
import mcheli.wrapper.W_TickHandler;
import mcheli.wrapper.W_Vec3;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.Display;

@SideOnly(Side.CLIENT)
public class MCH_ClientCommonTickHandler extends W_TickHandler {

    public static MCH_ClientCommonTickHandler instance;
    public MCH_GuiCommon gui_Common;
    public MCH_Gui gui_Heli;
    public MCH_Gui gui_Plane;
    public MCH_Gui gui_Tank;
    public MCH_Gui gui_GLTD;
    public MCH_Gui gui_Vehicle;
    public MCH_Gui gui_LWeapon;
    public MCH_Gui gui_Wrench;
    public MCH_Gui gui_EMarker;
    public MCH_Gui gui_RngFndr;
    public MCH_Gui gui_Title;
    public MCH_Gui[] guis;
    public MCH_Gui[] guiTicks;
    public MCH_ClientTickHandlerBase[] ticks;
    public MCH_Key[] Keys;
    public MCH_Key KeyCamDistUp;
    public MCH_Key KeyCamDistDown;
    public MCH_Key KeyScoreboard;
    public MCH_Key KeyMultiplayManager;
    public static int cameraMode = 0;
    public static MCH_EntityAircraft ridingAircraft = null;
    public static boolean isDrawScoreboard = false;
    public static int sendLDCount = 0;
    public static boolean isLocked = false;
    public static int lockedSoundCount = 0;
    int debugcnt;
    private static double prevMouseDeltaX;
    private static double prevMouseDeltaY;
    private static double mouseDeltaX = 0.0D;
    private static double mouseDeltaY = 0.0D;
    private static double mouseRollDeltaX = 0.0D;
    private static double mouseRollDeltaY = 0.0D;
    private static boolean isRideAircraft = false;
    private static float prevTick = 0.0F;

    public MCH_ClientCommonTickHandler(Minecraft minecraft, MCH_Config config) {
        super(minecraft);
        this.gui_Common = new MCH_GuiCommon(minecraft);
        this.gui_Heli = new MCH_GuiHeli(minecraft);
        this.gui_Plane = new MCP_GuiPlane(minecraft);
        this.gui_Tank = new MCH_GuiTank(minecraft);
        this.gui_GLTD = new MCH_GuiGLTD(minecraft);
        this.gui_Vehicle = new MCH_GuiVehicle(minecraft);
        this.gui_LWeapon = new MCH_GuiLightWeapon(minecraft);
        this.gui_Wrench = new MCH_GuiWrench(minecraft);
        this.gui_RngFndr = new MCH_GuiRangeFinder(minecraft);
        this.gui_EMarker = new MCH_GuiTargetMarker(minecraft);
        this.gui_Title = new MCH_GuiTitle(minecraft);
        this.guis = new MCH_Gui[] { this.gui_RngFndr, this.gui_LWeapon, this.gui_Heli, this.gui_Plane, this.gui_Tank, this.gui_GLTD, this.gui_Vehicle};
        this.guiTicks = new MCH_Gui[] { this.gui_Common, this.gui_Heli, this.gui_Plane, this.gui_Tank, this.gui_GLTD, this.gui_Vehicle, this.gui_LWeapon, this.gui_Wrench, this.gui_RngFndr, this.gui_EMarker, this.gui_Title};
        this.ticks = new MCH_ClientTickHandlerBase[] { new MCH_ClientHeliTickHandler(minecraft, config), new MCP_ClientPlaneTickHandler(minecraft, config), new MCH_ClientTankTickHandler(minecraft, config), new MCH_ClientGLTDTickHandler(minecraft, config), new MCH_ClientVehicleTickHandler(minecraft, config), new MCH_ClientLightWeaponTickHandler(minecraft, config), new MCH_ClientSeatTickHandler(minecraft, config), new MCH_ClientToolTickHandler(minecraft, config)};
        this.updatekeybind(config);
    }

    public void updatekeybind(MCH_Config config) {
        this.KeyCamDistUp = new MCH_Key(MCH_Config.KeyCameraDistUp.prmInt);
        this.KeyCamDistDown = new MCH_Key(MCH_Config.KeyCameraDistDown.prmInt);
        this.KeyScoreboard = new MCH_Key(MCH_Config.KeyScoreboard.prmInt);
        this.KeyMultiplayManager = new MCH_Key(MCH_Config.KeyMultiplayManager.prmInt);
        this.Keys = new MCH_Key[] { this.KeyCamDistUp, this.KeyCamDistDown, this.KeyScoreboard, this.KeyMultiplayManager};
        MCH_ClientTickHandlerBase[] arr$ = this.ticks;
        int len$ = arr$.length;

        for (int i$ = 0; i$ < len$; ++i$) {
            MCH_ClientTickHandlerBase t = arr$[i$];

            t.updateKeybind(config);
        }

    }

    public String getLabel() {
        return null;
    }

    public void onTick() {
        MCH_ClientTickHandlerBase.initRotLimit();
        MCH_Key[] player = this.Keys;
        int inOtherGui = player.length;

        for (int ac = 0; ac < inOtherGui; ++ac) {
            MCH_Key len$ = player[ac];

            len$.update();
        }

        EntityClientPlayerMP entityclientplayermp = this.mc.thePlayer;

        if (entityclientplayermp != null && this.mc.currentScreen == null) {
            if (MCH_ServerSettings.enableCamDistChange && (this.KeyCamDistUp.isKeyDown() || this.KeyCamDistDown.isKeyDown())) {
                inOtherGui = (int) W_Reflection.getThirdPersonDistance();
                if (this.KeyCamDistUp.isKeyDown() && inOtherGui < 60) {
                    inOtherGui += 4;
                    if (inOtherGui > 60) {
                        inOtherGui = 60;
                    }

                    W_Reflection.setThirdPersonDistance((float) inOtherGui);
                } else if (this.KeyCamDistDown.isKeyDown()) {
                    inOtherGui -= 4;
                    if (inOtherGui < 4) {
                        inOtherGui = 4;
                    }

                    W_Reflection.setThirdPersonDistance((float) inOtherGui);
                }
            }

            if (this.mc.currentScreen == null) {
                label85: {
                    if (this.mc.isSingleplayer()) {
                        MCH_Config mch_config = MCH_MOD.config;

                        if (!MCH_Config.DebugLog) {
                            break label85;
                        }
                    }

                    MCH_ClientCommonTickHandler.isDrawScoreboard = this.KeyScoreboard.isKeyPress();
                    if (!MCH_ClientCommonTickHandler.isDrawScoreboard && this.KeyMultiplayManager.isKeyDown()) {
                        MCH_PacketIndOpenScreen.send(5);
                    }
                }
            }
        }

        if (MCH_ClientCommonTickHandler.sendLDCount < 10) {
            ++MCH_ClientCommonTickHandler.sendLDCount;
        } else {
            MCH_MultiplayClient.sendImageData();
            MCH_ClientCommonTickHandler.sendLDCount = 0;
        }

        boolean flag = this.mc.currentScreen != null;
        MCH_ClientTickHandlerBase[] amch_clienttickhandlerbase = this.ticks;
        int i = amch_clienttickhandlerbase.length;

        int i$;

        for (i$ = 0; i$ < i; ++i$) {
            MCH_ClientTickHandlerBase g = amch_clienttickhandlerbase[i$];

            g.onTick(flag);
        }

        MCH_Gui[] amch_gui = this.guiTicks;

        i = amch_gui.length;

        for (i$ = 0; i$ < i; ++i$) {
            MCH_Gui mch_gui = amch_gui[i$];

            mch_gui.onTick();
        }

        MCH_EntityAircraft mch_entityaircraft = MCH_EntityAircraft.getAircraft_RiddenOrControl(entityclientplayermp);

        if (entityclientplayermp != null && mch_entityaircraft != null && !mch_entityaircraft.isDestroyed()) {
            if (MCH_ClientCommonTickHandler.isLocked && MCH_ClientCommonTickHandler.lockedSoundCount == 0) {
                MCH_ClientCommonTickHandler.isLocked = false;
                MCH_ClientCommonTickHandler.lockedSoundCount = 20;
                MCH_ClientTickHandlerBase.playSound("locked");
            }
        } else {
            MCH_ClientCommonTickHandler.lockedSoundCount = 0;
            MCH_ClientCommonTickHandler.isLocked = false;
        }

        if (MCH_ClientCommonTickHandler.lockedSoundCount > 0) {
            --MCH_ClientCommonTickHandler.lockedSoundCount;
        }

    }

    public void onTickPre() {
        if (this.mc.thePlayer != null && this.mc.theWorld != null) {
            this.onTick();
        }

    }

    public void onTickPost() {
        if (this.mc.thePlayer != null && this.mc.theWorld != null) {
            MCH_GuiTargetMarker.onClientTick();
        }

    }

    public static double getCurrentStickX() {
        return MCH_ClientCommonTickHandler.mouseRollDeltaX;
    }

    public static double getCurrentStickY() {
        double inv = 1.0D;

        if (Minecraft.getMinecraft().gameSettings.invertMouse) {
            inv = -inv;
        }

        MCH_Config mch_config = MCH_MOD.config;

        if (MCH_Config.InvertMouse.prmBool) {
            inv = -inv;
        }

        return MCH_ClientCommonTickHandler.mouseRollDeltaY * inv;
    }

    public static double getMaxStickLength() {
        return 40.0D;
    }

    public void updateMouseDelta(boolean stickMode, float partialTicks) {
        MCH_ClientCommonTickHandler.prevMouseDeltaX = MCH_ClientCommonTickHandler.mouseDeltaX;
        MCH_ClientCommonTickHandler.prevMouseDeltaY = MCH_ClientCommonTickHandler.mouseDeltaY;
        MCH_ClientCommonTickHandler.mouseDeltaX = 0.0D;
        MCH_ClientCommonTickHandler.mouseDeltaY = 0.0D;
        if (this.mc.inGameHasFocus && Display.isActive() && this.mc.currentScreen == null) {
            if (stickMode) {
                if (Math.abs(MCH_ClientCommonTickHandler.mouseRollDeltaX) < getMaxStickLength() * 0.2D) {
                    MCH_ClientCommonTickHandler.mouseRollDeltaX *= (double) (1.0F - 0.15F * partialTicks);
                }

                if (Math.abs(MCH_ClientCommonTickHandler.mouseRollDeltaY) < getMaxStickLength() * 0.2D) {
                    MCH_ClientCommonTickHandler.mouseRollDeltaY *= (double) (1.0F - 0.15F * partialTicks);
                }
            }

            this.mc.mouseHelper.mouseXYChange();
            float f1 = this.mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
            float f2 = f1 * f1 * f1 * 8.0F;
            MCH_Config mch_config = MCH_MOD.config;
            double ms = MCH_Config.MouseSensitivity.prmDouble * 0.1D;

            MCH_ClientCommonTickHandler.mouseDeltaX = ms * (double) this.mc.mouseHelper.deltaX * (double) f2;
            MCH_ClientCommonTickHandler.mouseDeltaY = ms * (double) this.mc.mouseHelper.deltaY * (double) f2;
            byte inv = 1;

            if (this.mc.gameSettings.invertMouse) {
                inv = -1;
            }

            mch_config = MCH_MOD.config;
            if (MCH_Config.InvertMouse.prmBool) {
                inv *= -1;
            }

            MCH_ClientCommonTickHandler.mouseRollDeltaX += MCH_ClientCommonTickHandler.mouseDeltaX;
            MCH_ClientCommonTickHandler.mouseRollDeltaY += MCH_ClientCommonTickHandler.mouseDeltaY * (double) inv;
            double dist = MCH_ClientCommonTickHandler.mouseRollDeltaX * MCH_ClientCommonTickHandler.mouseRollDeltaX + MCH_ClientCommonTickHandler.mouseRollDeltaY * MCH_ClientCommonTickHandler.mouseRollDeltaY;

            if (dist > 1.0D) {
                dist = (double) MathHelper.sqrt_double(dist);
                double d = dist;

                if (dist > getMaxStickLength()) {
                    d = getMaxStickLength();
                }

                MCH_ClientCommonTickHandler.mouseRollDeltaX /= dist;
                MCH_ClientCommonTickHandler.mouseRollDeltaY /= dist;
                MCH_ClientCommonTickHandler.mouseRollDeltaX *= d;
                MCH_ClientCommonTickHandler.mouseRollDeltaY *= d;
            }
        }

    }

    public void onRenderTickPre(float partialTicks) {
        MCH_GuiTargetMarker.clearMarkEntityPos();
        if (!MCH_ServerSettings.enableDebugBoundingBox) {
            RenderManager.debugBoundingBox = false;
        }

        MCH_ClientEventHook.haveSearchLightAircraft.clear();
        if (this.mc != null && this.mc.theWorld != null) {
            Iterator player = Minecraft.getMinecraft().theWorld.loadedEntityList.iterator();

            while (player.hasNext()) {
                Object currentItemstack = player.next();

                if (currentItemstack instanceof MCH_EntityAircraft && ((MCH_EntityAircraft) currentItemstack).haveSearchLight()) {
                    MCH_ClientEventHook.haveSearchLightAircraft.add((MCH_EntityAircraft) currentItemstack);
                }
            }
        }

        if (!W_McClient.isGamePaused()) {
            EntityClientPlayerMP entityclientplayermp = this.mc.thePlayer;

            if (entityclientplayermp != null) {
                ItemStack itemstack = entityclientplayermp.getCurrentEquippedItem();

                if (itemstack != null && itemstack.getItem() instanceof MCH_ItemWrench && entityclientplayermp.getItemInUseCount() > 0) {
                    W_Reflection.setItemRendererProgress(1.0F);
                }

                MCH_ClientCommonTickHandler.ridingAircraft = MCH_EntityAircraft.getAircraft_RiddenOrControl(entityclientplayermp);
                if (MCH_ClientCommonTickHandler.ridingAircraft != null) {
                    MCH_ClientCommonTickHandler.cameraMode = MCH_ClientCommonTickHandler.ridingAircraft.getCameraMode(entityclientplayermp);
                } else if (entityclientplayermp.ridingEntity instanceof MCH_EntityGLTD) {
                    MCH_EntityGLTD ac = (MCH_EntityGLTD) entityclientplayermp.ridingEntity;

                    MCH_ClientCommonTickHandler.cameraMode = ac.camera.getMode(0);
                } else {
                    MCH_ClientCommonTickHandler.cameraMode = 0;
                }

                MCH_EntityAircraft mch_entityaircraft = null;

                if (!(entityclientplayermp.ridingEntity instanceof MCH_EntityHeli) && !(entityclientplayermp.ridingEntity instanceof MCP_EntityPlane) && !(entityclientplayermp.ridingEntity instanceof MCH_EntityTank)) {
                    if (entityclientplayermp.ridingEntity instanceof MCH_EntityUavStation) {
                        mch_entityaircraft = ((MCH_EntityUavStation) entityclientplayermp.ridingEntity).getControlAircract();
                    } else if (entityclientplayermp.ridingEntity instanceof MCH_EntityVehicle) {
                        MCH_EntityAircraft stickMode = (MCH_EntityAircraft) entityclientplayermp.ridingEntity;

                        stickMode.setupAllRiderRenderPosition(partialTicks, entityclientplayermp);
                    }
                } else {
                    mch_entityaircraft = (MCH_EntityAircraft) entityclientplayermp.ridingEntity;
                }

                boolean flag = false;
                MCH_Config mch_config;

                if (mch_entityaircraft instanceof MCH_EntityHeli) {
                    mch_config = MCH_MOD.config;
                    flag = MCH_Config.MouseControlStickModeHeli.prmBool;
                }

                if (mch_entityaircraft instanceof MCP_EntityPlane) {
                    mch_config = MCH_MOD.config;
                    flag = MCH_Config.MouseControlStickModePlane.prmBool;
                }

                for (int de = 0; de < 10 && MCH_ClientCommonTickHandler.prevTick > partialTicks; ++de) {
                    --MCH_ClientCommonTickHandler.prevTick;
                }

                float p;
                float r;

                if (mch_entityaircraft != null && mch_entityaircraft.canMouseRot()) {
                    if (!MCH_ClientCommonTickHandler.isRideAircraft) {
                        mch_entityaircraft.onInteractFirst(entityclientplayermp);
                    }

                    MCH_ClientCommonTickHandler.isRideAircraft = true;
                    this.updateMouseDelta(flag, partialTicks);
                    boolean flag1 = false;
                    float f = 0.0F;
                    float f1 = 0.0F;
                    MCH_SeatInfo mch_seatinfo = mch_entityaircraft.getSeatInfo(entityclientplayermp);

                    if (mch_seatinfo != null && mch_seatinfo.fixRot && mch_entityaircraft.getIsGunnerMode(entityclientplayermp) && !mch_entityaircraft.isGunnerLookMode(entityclientplayermp)) {
                        flag1 = true;
                        f = mch_seatinfo.fixYaw;
                        f1 = mch_seatinfo.fixPitch;
                        MCH_ClientCommonTickHandler.mouseRollDeltaX *= 0.0D;
                        MCH_ClientCommonTickHandler.mouseRollDeltaY *= 0.0D;
                        MCH_ClientCommonTickHandler.mouseDeltaX *= 0.0D;
                        MCH_ClientCommonTickHandler.mouseDeltaY *= 0.0D;
                    } else if (mch_entityaircraft.isPilot(entityclientplayermp)) {
                        MCH_AircraftInfo.CameraPosition mch_aircraftinfo_cameraposition = mch_entityaircraft.getCameraPosInfo();

                        if (mch_aircraftinfo_cameraposition != null) {
                            f = mch_aircraftinfo_cameraposition.yaw;
                            f1 = mch_aircraftinfo_cameraposition.pitch;
                        }
                    }

                    if (mch_entityaircraft.getAcInfo() == null) {
                        entityclientplayermp.setAngles((float) MCH_ClientCommonTickHandler.mouseDeltaX, (float) MCH_ClientCommonTickHandler.mouseDeltaY);
                    } else {
                        mch_entityaircraft.setAngles(entityclientplayermp, flag1, f, f1, (float) (MCH_ClientCommonTickHandler.mouseDeltaX + MCH_ClientCommonTickHandler.prevMouseDeltaX) / 2.0F, (float) (MCH_ClientCommonTickHandler.mouseDeltaY + MCH_ClientCommonTickHandler.prevMouseDeltaY) / 2.0F, (float) MCH_ClientCommonTickHandler.mouseRollDeltaX, (float) MCH_ClientCommonTickHandler.mouseRollDeltaY, partialTicks - MCH_ClientCommonTickHandler.prevTick);
                    }

                    mch_entityaircraft.setupAllRiderRenderPosition(partialTicks, entityclientplayermp);
                    double d0 = (double) MathHelper.sqrt_double(MCH_ClientCommonTickHandler.mouseRollDeltaX * MCH_ClientCommonTickHandler.mouseRollDeltaX + MCH_ClientCommonTickHandler.mouseRollDeltaY * MCH_ClientCommonTickHandler.mouseRollDeltaY);

                    if (!flag || d0 < getMaxStickLength() * 0.1D) {
                        MCH_ClientCommonTickHandler.mouseRollDeltaX *= 0.95D;
                        MCH_ClientCommonTickHandler.mouseRollDeltaY *= 0.95D;
                    }

                    p = MathHelper.wrapAngleTo180_float(mch_entityaircraft.getRotRoll());
                    r = MathHelper.wrapAngleTo180_float(mch_entityaircraft.getRotYaw() - entityclientplayermp.rotationYaw);
                    p *= MathHelper.cos((float) ((double) r * 3.141592653589793D / 180.0D));
                    if (mch_entityaircraft.getTVMissile() != null && W_Lib.isClientPlayer(mch_entityaircraft.getTVMissile().shootingEntity) && mch_entityaircraft.getIsGunnerMode(entityclientplayermp)) {
                        p = 0.0F;
                    }

                    W_Reflection.setCameraRoll(p);
                    this.correctViewEntityDummy(entityclientplayermp);
                } else {
                    MCH_EntitySeat mch_entityseat = entityclientplayermp.ridingEntity instanceof MCH_EntitySeat ? (MCH_EntitySeat) entityclientplayermp.ridingEntity : null;

                    if (mch_entityseat != null && mch_entityseat.getParent() != null) {
                        this.updateMouseDelta(flag, partialTicks);
                        mch_entityaircraft = mch_entityseat.getParent();
                        boolean wi = false;
                        MCH_SeatInfo seatInfo = mch_entityaircraft.getSeatInfo(entityclientplayermp);

                        if (seatInfo != null && seatInfo.fixRot && mch_entityaircraft.getIsGunnerMode(entityclientplayermp) && !mch_entityaircraft.isGunnerLookMode(entityclientplayermp)) {
                            wi = true;
                            MCH_ClientCommonTickHandler.mouseRollDeltaX *= 0.0D;
                            MCH_ClientCommonTickHandler.mouseRollDeltaY *= 0.0D;
                            MCH_ClientCommonTickHandler.mouseDeltaX *= 0.0D;
                            MCH_ClientCommonTickHandler.mouseDeltaY *= 0.0D;
                        }

                        Vec3 v = Vec3.createVectorHelper(MCH_ClientCommonTickHandler.mouseDeltaX, MCH_ClientCommonTickHandler.mouseRollDeltaY, 0.0D);

                        W_Vec3.rotateAroundZ((float) ((double) (mch_entityaircraft.calcRotRoll(partialTicks) / 180.0F) * 3.141592653589793D), v);
                        MCH_WeaponSet ws = mch_entityaircraft.getCurrentWeapon(entityclientplayermp);

                        MCH_ClientCommonTickHandler.mouseDeltaY *= ws != null && ws.getInfo() != null ? (double) ws.getInfo().cameraRotationSpeedPitch : 1.0D;
                        entityclientplayermp.setAngles((float) MCH_ClientCommonTickHandler.mouseDeltaX, (float) MCH_ClientCommonTickHandler.mouseDeltaY);
                        float y = mch_entityaircraft.getRotYaw();

                        p = mch_entityaircraft.getRotPitch();
                        r = mch_entityaircraft.getRotRoll();
                        mch_entityaircraft.setRotYaw(mch_entityaircraft.calcRotYaw(partialTicks));
                        mch_entityaircraft.setRotPitch(mch_entityaircraft.calcRotPitch(partialTicks));
                        mch_entityaircraft.setRotRoll(mch_entityaircraft.calcRotRoll(partialTicks));
                        float revRoll = 0.0F;

                        if (wi) {
                            entityclientplayermp.rotationYaw = mch_entityaircraft.getRotYaw() + seatInfo.fixYaw;
                            entityclientplayermp.rotationPitch = mch_entityaircraft.getRotPitch() + seatInfo.fixPitch;
                            if (entityclientplayermp.rotationPitch > 90.0F) {
                                entityclientplayermp.prevRotationPitch -= (entityclientplayermp.rotationPitch - 90.0F) * 2.0F;
                                entityclientplayermp.rotationPitch -= (entityclientplayermp.rotationPitch - 90.0F) * 2.0F;
                                entityclientplayermp.prevRotationYaw += 180.0F;
                                entityclientplayermp.rotationYaw += 180.0F;
                                revRoll = 180.0F;
                            } else if (entityclientplayermp.rotationPitch < -90.0F) {
                                entityclientplayermp.prevRotationPitch -= (entityclientplayermp.rotationPitch - 90.0F) * 2.0F;
                                entityclientplayermp.rotationPitch -= (entityclientplayermp.rotationPitch - 90.0F) * 2.0F;
                                entityclientplayermp.prevRotationYaw += 180.0F;
                                entityclientplayermp.rotationYaw += 180.0F;
                                revRoll = 180.0F;
                            }
                        }

                        mch_entityaircraft.setupAllRiderRenderPosition(partialTicks, entityclientplayermp);
                        mch_entityaircraft.setRotYaw(y);
                        mch_entityaircraft.setRotPitch(p);
                        mch_entityaircraft.setRotRoll(r);
                        MCH_ClientCommonTickHandler.mouseRollDeltaX *= 0.9D;
                        MCH_ClientCommonTickHandler.mouseRollDeltaY *= 0.9D;
                        float roll = MathHelper.wrapAngleTo180_float(mch_entityaircraft.getRotRoll());
                        float yaw = MathHelper.wrapAngleTo180_float(mch_entityaircraft.getRotYaw() - entityclientplayermp.rotationYaw);

                        roll *= MathHelper.cos((float) ((double) yaw * 3.141592653589793D / 180.0D));
                        if (mch_entityaircraft.getTVMissile() != null && W_Lib.isClientPlayer(mch_entityaircraft.getTVMissile().shootingEntity) && mch_entityaircraft.getIsGunnerMode(entityclientplayermp)) {
                            roll = 0.0F;
                        }

                        W_Reflection.setCameraRoll(roll + revRoll);
                        this.correctViewEntityDummy(entityclientplayermp);
                    } else {
                        if (MCH_ClientCommonTickHandler.isRideAircraft) {
                            W_Reflection.setCameraRoll(0.0F);
                            MCH_ClientCommonTickHandler.isRideAircraft = false;
                        }

                        MCH_ClientCommonTickHandler.mouseRollDeltaX = 0.0D;
                        MCH_ClientCommonTickHandler.mouseRollDeltaY = 0.0D;
                    }
                }

                if (mch_entityaircraft != null) {
                    if (mch_entityaircraft.getSeatIdByEntity(entityclientplayermp) == 0 && !mch_entityaircraft.isDestroyed()) {
                        mch_entityaircraft.lastRiderYaw = entityclientplayermp.rotationYaw;
                        mch_entityaircraft.prevLastRiderYaw = entityclientplayermp.prevRotationYaw;
                        mch_entityaircraft.lastRiderPitch = entityclientplayermp.rotationPitch;
                        mch_entityaircraft.prevLastRiderPitch = entityclientplayermp.prevRotationPitch;
                    }

                    mch_entityaircraft.updateWeaponsRotation();
                }

                MCH_ViewEntityDummy mch_viewentitydummy = MCH_ViewEntityDummy.getInstance(entityclientplayermp.worldObj);

                if (mch_viewentitydummy != null) {
                    mch_viewentitydummy.rotationYaw = entityclientplayermp.rotationYaw;
                    mch_viewentitydummy.prevRotationYaw = entityclientplayermp.prevRotationYaw;
                    if (mch_entityaircraft != null) {
                        MCH_WeaponSet mch_weaponset = mch_entityaircraft.getCurrentWeapon(entityclientplayermp);

                        if (mch_weaponset != null && mch_weaponset.getInfo() != null && mch_weaponset.getInfo().fixCameraPitch) {
                            mch_viewentitydummy.rotationPitch = mch_viewentitydummy.prevRotationPitch = 0.0F;
                        }
                    }
                }

                MCH_ClientCommonTickHandler.prevTick = partialTicks;
            }
        }
    }

    public void correctViewEntityDummy(Entity entity) {
        MCH_ViewEntityDummy de = MCH_ViewEntityDummy.getInstance(entity.worldObj);

        if (de != null) {
            if (de.rotationYaw - de.prevRotationYaw > 180.0F) {
                de.prevRotationYaw += 360.0F;
            } else if (de.rotationYaw - de.prevRotationYaw < -180.0F) {
                de.prevRotationYaw -= 360.0F;
            }
        }

    }

    public void onPlayerTickPre(EntityPlayer player) {
        if (player.worldObj.isRemote) {
            ItemStack currentItemstack = player.getCurrentEquippedItem();

            if (currentItemstack != null && currentItemstack.getItem() instanceof MCH_ItemWrench && player.getItemInUseCount() > 0 && player.getItemInUse() != currentItemstack) {
                int maxdm = currentItemstack.getMaxDamage();
                int dm = currentItemstack.getItemDamage();

                if (dm <= maxdm && dm > 0) {
                    player.setItemInUse(currentItemstack, player.getItemInUseCount());
                }
            }
        }

    }

    public void onPlayerTickPost(EntityPlayer player) {}

    public void onRenderTickPost(float partialTicks) {
        if (this.mc.thePlayer != null) {
            MCH_ClientTickHandlerBase.applyRotLimit(this.mc.thePlayer);
            MCH_ViewEntityDummy arr$ = MCH_ViewEntityDummy.getInstance(this.mc.thePlayer.worldObj);

            if (arr$ != null) {
                arr$.rotationPitch = this.mc.thePlayer.rotationPitch;
                arr$.rotationYaw = this.mc.thePlayer.rotationYaw;
                arr$.prevRotationPitch = this.mc.thePlayer.prevRotationPitch;
                arr$.prevRotationYaw = this.mc.thePlayer.prevRotationYaw;
            }
        }

        if (this.mc.currentScreen == null || this.mc.currentScreen instanceof GuiChat || this.mc.currentScreen.getClass().toString().indexOf("GuiDriveableController") >= 0) {
            MCH_Gui[] amch_gui = this.guis;
            int len$ = amch_gui.length;

            for (int i$ = 0; i$ < len$; ++i$) {
                MCH_Gui gui = amch_gui[i$];

                if (this.drawGui(gui, partialTicks)) {
                    break;
                }
            }

            this.drawGui(this.gui_Common, partialTicks);
            this.drawGui(this.gui_Wrench, partialTicks);
            this.drawGui(this.gui_EMarker, partialTicks);
            if (MCH_ClientCommonTickHandler.isDrawScoreboard) {
                MCH_GuiScoreboard.drawList(this.mc, this.mc.fontRenderer, false);
            }

            this.drawGui(this.gui_Title, partialTicks);
        }

    }

    public boolean drawGui(MCH_Gui gui, float partialTicks) {
        if (gui.isDrawGui(this.mc.thePlayer)) {
            gui.drawScreen(0, 0, partialTicks);
            return true;
        } else {
            return false;
        }
    }
}

package mcheli.plane;

import mcheli.MCH_Config;
import mcheli.MCH_Key;
import mcheli.MCH_Lib;
import mcheli.MCH_ViewEntityDummy;
import mcheli.aircraft.MCH_AircraftClientTickHandler;
import mcheli.aircraft.MCH_EntitySeat;
import mcheli.aircraft.MCH_SeatInfo;
import mcheli.uav.MCH_EntityUavStation;
import mcheli.wrapper.W_Network;
import mcheli.wrapper.W_Reflection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.entity.player.EntityPlayer;

public class MCP_ClientPlaneTickHandler extends MCH_AircraftClientTickHandler {

    public MCH_Key KeySwitchMode;
    public MCH_Key KeyEjectSeat;
    public MCH_Key KeyZoom;
    public MCH_Key[] Keys;

    public MCP_ClientPlaneTickHandler(Minecraft minecraft, MCH_Config config) {
        super(minecraft, config);
        this.updateKeybind(config);
    }

    public void updateKeybind(MCH_Config config) {
        super.updateKeybind(config);
        this.KeySwitchMode = new MCH_Key(MCH_Config.KeySwitchMode.prmInt);
        this.KeyEjectSeat = new MCH_Key(MCH_Config.KeySwitchHovering.prmInt);
        this.KeyZoom = new MCH_Key(MCH_Config.KeyZoom.prmInt);
        this.Keys = new MCH_Key[] { this.KeyUp, this.KeyDown, this.KeyRight, this.KeyLeft, this.KeySwitchMode, this.KeyEjectSeat, this.KeyUseWeapon, this.KeySwWeaponMode, this.KeySwitchWeapon1, this.KeySwitchWeapon2, this.KeyZoom, this.KeyCameraMode, this.KeyUnmount, this.KeyUnmountForce, this.KeyFlare, this.KeyExtra, this.KeyFreeLook, this.KeyGUI, this.KeyGearUpDown, this.KeyPutToRack, this.KeyDownFromRack};
    }

    protected void update(EntityPlayer player, MCP_EntityPlane plane) {
        if (plane.getIsGunnerMode(player)) {
            MCH_SeatInfo seatInfo = plane.getSeatInfo(player);

            if (seatInfo != null) {
                setRotLimitPitch(seatInfo.minPitch, seatInfo.maxPitch, player);
            }
        }

        plane.updateRadar(10);
        plane.updateCameraRotate(player.rotationYaw, player.rotationPitch);
    }

    protected void onTick(boolean inGUI) {
        MCH_Key[] player = this.Keys;
        int plane = player.length;

        for (int isPilot = 0; isPilot < plane; ++isPilot) {
            MCH_Key viewEntityDummy = player[isPilot];

            viewEntityDummy.update();
        }

        this.isBeforeRiding = this.isRiding;
        EntityClientPlayerMP entityclientplayermp = this.mc.thePlayer;
        MCP_EntityPlane mcp_entityplane = null;
        boolean flag = true;

        if (entityclientplayermp != null) {
            if (entityclientplayermp.ridingEntity instanceof MCP_EntityPlane) {
                mcp_entityplane = (MCP_EntityPlane) entityclientplayermp.ridingEntity;
            } else if (entityclientplayermp.ridingEntity instanceof MCH_EntitySeat) {
                MCH_EntitySeat mch_entityseat = (MCH_EntitySeat) entityclientplayermp.ridingEntity;

                if (mch_entityseat.getParent() instanceof MCP_EntityPlane) {
                    flag = false;
                    mcp_entityplane = (MCP_EntityPlane) mch_entityseat.getParent();
                }
            } else if (entityclientplayermp.ridingEntity instanceof MCH_EntityUavStation) {
                MCH_EntityUavStation mch_entityuavstation = (MCH_EntityUavStation) entityclientplayermp.ridingEntity;

                if (mch_entityuavstation.getControlAircract() instanceof MCP_EntityPlane) {
                    mcp_entityplane = (MCP_EntityPlane) mch_entityuavstation.getControlAircract();
                }
            }
        }

        if (mcp_entityplane != null && mcp_entityplane.getAcInfo() != null) {
            this.update(entityclientplayermp, mcp_entityplane);
            MCH_ViewEntityDummy mch_viewentitydummy = MCH_ViewEntityDummy.getInstance(this.mc.theWorld);

            mch_viewentitydummy.update(mcp_entityplane.camera);
            if (!inGUI) {
                if (!mcp_entityplane.isDestroyed()) {
                    this.playerControl(entityclientplayermp, mcp_entityplane, flag);
                }
            } else {
                this.playerControlInGUI(entityclientplayermp, mcp_entityplane, flag);
            }

            boolean hideHand = true;

            if ((!flag || !mcp_entityplane.isAlwaysCameraView()) && !mcp_entityplane.getIsGunnerMode(entityclientplayermp) && mcp_entityplane.getCameraId() <= 0) {
                MCH_Lib.setRenderViewEntity(entityclientplayermp);
                if (!flag && mcp_entityplane.getCurrentWeaponID(entityclientplayermp) < 0) {
                    hideHand = false;
                }
            } else {
                MCH_Lib.setRenderViewEntity(mch_viewentitydummy);
            }

            if (hideHand) {
                MCH_Lib.disableFirstPersonItemRender(entityclientplayermp.getCurrentEquippedItem());
            }

            this.isRiding = true;
        } else {
            this.isRiding = false;
        }

        if (!this.isBeforeRiding && this.isRiding && mcp_entityplane != null) {
            MCH_ViewEntityDummy.getInstance(this.mc.theWorld).setPosition(mcp_entityplane.posX, mcp_entityplane.posY + 0.5D, mcp_entityplane.posZ);
        } else if (this.isBeforeRiding && !this.isRiding) {
            MCH_Lib.enableFirstPersonItemRender();
            MCH_Lib.setRenderViewEntity(entityclientplayermp);
            W_Reflection.setCameraRoll(0.0F);
        }

    }

    protected void playerControlInGUI(EntityPlayer player, MCP_EntityPlane plane, boolean isPilot) {
        this.commonPlayerControlInGUI(player, plane, isPilot, new MCP_PlanePacketPlayerControl());
    }

    protected void playerControl(EntityPlayer player, MCP_EntityPlane plane, boolean isPilot) {
        MCP_PlanePacketPlayerControl pc = new MCP_PlanePacketPlayerControl();
        boolean send = false;

        send = this.commonPlayerControl(player, plane, isPilot, pc);
        boolean isUav;

        if (isPilot) {
            if (this.KeySwitchMode.isKeyDown()) {
                if (plane.getIsGunnerMode(player) && plane.canSwitchCameraPos()) {
                    pc.switchMode = 0;
                    plane.switchGunnerMode(false);
                    send = true;
                    plane.setCameraId(1);
                } else if (plane.getCameraId() > 0) {
                    plane.setCameraId(plane.getCameraId() + 1);
                    if (plane.getCameraId() >= plane.getCameraPosNum()) {
                        plane.setCameraId(0);
                    }
                } else if (plane.canSwitchGunnerMode()) {
                    pc.switchMode = (byte) (plane.getIsGunnerMode(player) ? 0 : 1);
                    plane.switchGunnerMode(!plane.getIsGunnerMode(player));
                    send = true;
                    plane.setCameraId(0);
                } else if (plane.canSwitchCameraPos()) {
                    plane.setCameraId(1);
                } else {
                    playSoundNG();
                }
            }

            if (this.KeyExtra.isKeyDown()) {
                if (plane.canSwitchVtol()) {
                    isUav = plane.getNozzleStat();
                    if (!isUav) {
                        pc.switchVtol = 1;
                    } else {
                        pc.switchVtol = 0;
                    }

                    plane.swithVtolMode(!isUav);
                    send = true;
                } else {
                    playSoundNG();
                }
            }
        } else if (this.KeySwitchMode.isKeyDown()) {
            if (plane.canSwitchGunnerModeOtherSeat(player)) {
                plane.switchGunnerModeOtherSeat(player);
                send = true;
            } else {
                playSoundNG();
            }
        }

        if (this.KeyZoom.isKeyDown()) {
            isUav = plane.isUAV() && !plane.getAcInfo().haveHatch() && !plane.getPlaneInfo().haveWing();
            if (!plane.getIsGunnerMode(player) && !isUav) {
                if (isPilot) {
                    if (plane.getAcInfo().haveHatch()) {
                        if (plane.canFoldHatch()) {
                            pc.switchHatch = 2;
                            send = true;
                        } else if (plane.canUnfoldHatch()) {
                            pc.switchHatch = 1;
                            send = true;
                        }
                    } else if (plane.canFoldWing()) {
                        pc.switchHatch = 2;
                        send = true;
                    } else if (plane.canUnfoldWing()) {
                        pc.switchHatch = 1;
                        send = true;
                    }
                }
            } else {
                plane.zoomCamera();
                playSound("zoom", 0.5F, 1.0F);
            }
        }

        if (this.KeyEjectSeat.isKeyDown() && plane.canEjectSeat(player)) {
            pc.ejectSeat = true;
            send = true;
        }

        if (send) {
            W_Network.sendToServer(pc);
        }

    }
}

package mcheli.throwable;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import mcheli.MCH_InputFile;
import mcheli.MCH_Lib;
import net.minecraft.item.Item;

public class MCH_ThrowableInfoManager {

    private static MCH_ThrowableInfoManager instance = new MCH_ThrowableInfoManager();
    private static HashMap map = new LinkedHashMap();

    public static boolean load(String path) {
        path = path.replace('\\', '/');
        File dir = new File(path);
        File[] files = dir.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                String s = pathname.getName().toLowerCase();

                return pathname.isFile() && s.length() >= 5 && s.substring(s.length() - 4).compareTo(".txt") == 0;
            }
        });

        if (files != null && files.length > 0) {
            File[] arr$ = files;
            int len$ = files.length;

            for (int i$ = 0; i$ < len$; ++i$) {
                File f = arr$[i$];
                MCH_InputFile inFile = new MCH_InputFile();
                int line = 0;

                try {
                    String e = f.getName().toLowerCase();

                    e = e.substring(0, e.length() - 4);
                    if (!MCH_ThrowableInfoManager.map.containsKey(e) && inFile.openUTF8(f)) {
                        MCH_ThrowableInfo info = new MCH_ThrowableInfo(e);

                        String str;

                        while ((str = inFile.br.readLine()) != null) {
                            ++line;
                            str = str.trim();
                            int eqIdx = str.indexOf(61);

                            if (eqIdx >= 0 && str.length() > eqIdx + 1) {
                                info.loadItemData(str.substring(0, eqIdx).trim().toLowerCase(), str.substring(eqIdx + 1).trim());
                            }
                        }

                        info.checkData();
                        MCH_ThrowableInfoManager.map.put(e, info);
                    }
                } catch (IOException ioexception) {
                    if (line > 0) {
                        MCH_Lib.Log("### Load failed %s : line=%d", new Object[] { f.getName(), Integer.valueOf(line)});
                    } else {
                        MCH_Lib.Log("### Load failed %s", new Object[] { f.getName()});
                    }

                    ioexception.printStackTrace();
                } finally {
                    inFile.close();
                }
            }

            MCH_Lib.Log("Read %d throwable", new Object[] { Integer.valueOf(MCH_ThrowableInfoManager.map.size())});
            return MCH_ThrowableInfoManager.map.size() > 0;
        } else {
            return false;
        }
    }

    public static MCH_ThrowableInfo get(String name) {
        return (MCH_ThrowableInfo) MCH_ThrowableInfoManager.map.get(name);
    }

    public static MCH_ThrowableInfo get(Item item) {
        Iterator i$ = MCH_ThrowableInfoManager.map.values().iterator();

        MCH_ThrowableInfo info;

        do {
            if (!i$.hasNext()) {
                return null;
            }

            info = (MCH_ThrowableInfo) i$.next();
        } while (info.item != item);

        return info;
    }

    public static boolean contains(String name) {
        return MCH_ThrowableInfoManager.map.containsKey(name);
    }

    public static Set getKeySet() {
        return MCH_ThrowableInfoManager.map.keySet();
    }

    public static Collection getValues() {
        return MCH_ThrowableInfoManager.map.values();
    }
}

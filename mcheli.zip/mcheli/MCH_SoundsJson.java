package mcheli;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class MCH_SoundsJson {

    public static boolean update(String path) {
        boolean result = true;

        path = path.replace('\\', '/');
        File dir = new File(path + "sounds");
        File[] files = dir.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                String s = pathname.getName().toLowerCase();

                return pathname.isFile() && s.length() >= 5 && s.substring(s.length() - 4).compareTo(".ogg") == 0;
            }
        });
        int cnt = 0;
        PrintWriter pw = null;

        try {
            File e = new File(path + "sounds.json");

            pw = new PrintWriter(e);
            pw.println("{");
            if (files != null) {
                LinkedHashMap map = new LinkedHashMap();
                File[] i$ = files;
                int key = files.length;

                for (int list = 0; list < key; ++list) {
                    File line = i$[list];
                    String fi = line.getName().toLowerCase();
                    int ei = fi.lastIndexOf(".");

                    fi = fi.substring(0, ei);
                    String key1 = fi;
                    char c = fi.charAt(fi.length() - 1);

                    if (c >= 48 && c <= 57) {
                        key1 = fi.substring(0, fi.length() - 1);
                    }

                    if (!map.containsKey(key1)) {
                        map.put(key1, new ArrayList());
                    }

                    ((ArrayList) map.get(key1)).add(fi);
                }

                String s;

                for (Iterator iterator = map.keySet().iterator(); iterator.hasNext(); pw.println(s)) {
                    String s1 = (String) iterator.next();

                    ++cnt;
                    ArrayList arraylist = (ArrayList) map.get(s1);

                    s = "";
                    s = "\"" + s1 + "\": {\"category\": \"master\",\"sounds\": [";

                    for (int i = 0; i < arraylist.size(); ++i) {
                        s = s + (i > 0 ? "," : "") + "\"" + (String) arraylist.get(i) + "\"";
                    }

                    s = s + "]}";
                    if (cnt < map.size()) {
                        s = s + ",";
                    }
                }
            }

            pw.println("}");
            pw.println("");
            result = true;
        } catch (IOException ioexception) {
            result = false;
            ioexception.printStackTrace();
        } finally {
            if (pw != null) {
                pw.close();
            }

        }

        if (result) {
            MCH_Lib.Log("Update sounds.json. %d sounds", new Object[] { Integer.valueOf(cnt)});
        } else {
            MCH_Lib.Log("Failed sounds.json update! %d sounds", new Object[] { Integer.valueOf(cnt)});
        }

        return result;
    }
}

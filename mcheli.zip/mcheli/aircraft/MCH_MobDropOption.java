package mcheli.aircraft;

import net.minecraft.util.Vec3;

public class MCH_MobDropOption {

    public Vec3 pos = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
    public int interval = 1;
}

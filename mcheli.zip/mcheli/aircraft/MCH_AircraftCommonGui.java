package mcheli.aircraft;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import mcheli.MCH_Config;
import mcheli.MCH_KeyName;
import mcheli.MCH_Lib;
import mcheli.MCH_MOD;
import mcheli.gui.MCH_Gui;
import mcheli.hud.MCH_Hud;
import mcheli.weapon.MCH_EntityTvMissile;
import mcheli.weapon.MCH_WeaponSet;
import mcheli.wrapper.W_McClient;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public abstract class MCH_AircraftCommonGui extends MCH_Gui {

    public MCH_AircraftCommonGui(Minecraft minecraft) {
        super(minecraft);
    }

    public void drawHud(MCH_EntityAircraft ac, EntityPlayer player, int seatId) {
        MCH_AircraftInfo info = ac.getAcInfo();

        if (info != null) {
            if (ac.isMissileCameraMode(player) && ac.getTVMissile() != null && info.hudTvMissile != null) {
                info.hudTvMissile.draw(ac, player, this.smoothCamPartialTicks);
            } else {
                if (seatId < 0) {
                    return;
                }

                if (seatId < info.hudList.size()) {
                    MCH_Hud hud = (MCH_Hud) info.hudList.get(seatId);

                    if (hud != null) {
                        hud.draw(ac, player, this.smoothCamPartialTicks);
                    }
                }
            }

        }
    }

    public void drawDebugtInfo(MCH_EntityAircraft ac) {
        MCH_Config mch_config = MCH_MOD.config;

        if (MCH_Config.DebugLog) {
            int LX = this.centerX - 100;
        }

    }

    public void drawNightVisionNoise() {
        GL11.glEnable(3042);
        GL11.glColor4f(0.0F, 1.0F, 0.0F, 0.3F);
        int srcBlend = GL11.glGetInteger(3041);
        int dstBlend = GL11.glGetInteger(3040);

        GL11.glBlendFunc(1, 1);
        W_McClient.MOD_bindTexture("textures/gui/alpha.png");
        this.drawTexturedModalRectRotate(0.0D, 0.0D, (double) this.width, (double) this.height, (double) this.rand.nextInt(256), (double) this.rand.nextInt(256), 256.0D, 256.0D, 0.0F);
        GL11.glBlendFunc(srcBlend, dstBlend);
        GL11.glDisable(3042);
    }

    public void drawHitBullet(int hs, int hsMax, int color) {
        if (hs > 0) {
            int cx = this.centerX;
            int cy = this.centerY;
            byte IVX = 10;
            byte IVY = 10;
            byte SZX = 5;
            byte SZY = 5;
            double[] ls = new double[] { (double) (cx - IVX), (double) (cy - IVY), (double) (cx - SZX), (double) (cy - SZY), (double) (cx - IVX), (double) (cy + IVY), (double) (cx - SZX), (double) (cy + SZY), (double) (cx + IVX), (double) (cy - IVY), (double) (cx + SZX), (double) (cy - SZY), (double) (cx + IVX), (double) (cy + IVY), (double) (cx + SZX), (double) (cy + SZY)};
            MCH_Config mch_config = MCH_MOD.config;

            color = MCH_Config.hitMarkColorRGB;
            int alpha = hs * (256 / hsMax);
            MCH_Config mch_config1 = MCH_MOD.config;

            color |= (int) (MCH_Config.hitMarkColorAlpha * (float) alpha) << 24;
            this.drawLine(ls, color);
        }

    }

    public void drawHitBullet(MCH_EntityAircraft ac, int color, int seatID) {
        this.drawHitBullet(ac.getHitStatus(), ac.getMaxHitStatus(), color);
    }

    protected void drawTvMissileNoise(MCH_EntityAircraft ac, MCH_EntityTvMissile tvmissile) {
        GL11.glEnable(3042);
        GL11.glColor4f(0.5F, 0.5F, 0.5F, 0.4F);
        int srcBlend = GL11.glGetInteger(3041);
        int dstBlend = GL11.glGetInteger(3040);

        GL11.glBlendFunc(1, 1);
        W_McClient.MOD_bindTexture("textures/gui/noise.png");
        this.drawTexturedModalRectRotate(0.0D, 0.0D, (double) this.width, (double) this.height, (double) this.rand.nextInt(256), (double) this.rand.nextInt(256), 256.0D, 256.0D, 0.0F);
        GL11.glBlendFunc(srcBlend, dstBlend);
        GL11.glDisable(3042);
    }

    public void drawKeyBind(MCH_EntityAircraft ac, MCH_AircraftInfo info, EntityPlayer player, int seatID, int RX, int LX, int colorActive, int colorInactive) {
        String msg = "";
        boolean c = false;
        StringBuilder stringbuilder;
        MCH_Config mch_config;

        if (seatID == 0 && ac.canPutToRack()) {
            stringbuilder = (new StringBuilder()).append("PutRack : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyPutToRack.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 10, colorActive);
        }

        if (seatID == 0 && ac.canDownFromRack()) {
            stringbuilder = (new StringBuilder()).append("DownRack : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyDownFromRack.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 0, colorActive);
        }

        if (seatID == 0 && ac.canRideRack()) {
            stringbuilder = (new StringBuilder()).append("RideRack : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyPutToRack.prmInt)).toString();
            this.drawString(msg, LX, this.centerY + 10, colorActive);
        }

        if (seatID == 0 && ac.ridingEntity != null) {
            stringbuilder = (new StringBuilder()).append("DismountRack : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyDownFromRack.prmInt)).toString();
            this.drawString(msg, LX, this.centerY + 10, colorActive);
        }

        int c1;
        label133: {
            if (seatID <= 0 || ac.getSeatNum() <= 1) {
                MCH_Config mch_config1 = MCH_MOD.config;

                if (!Keyboard.isKeyDown(MCH_Config.KeyFreeLook.prmInt)) {
                    break label133;
                }
            }

            c1 = seatID == 0 ? -208 : colorActive;
            String s;

            if (seatID == 0) {
                stringbuilder = new StringBuilder();
                mch_config = MCH_MOD.config;
                s = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyFreeLook.prmInt)).append(" + ").toString();
            } else {
                s = "";
            }

            String ws = s;

            stringbuilder = (new StringBuilder()).append("NextSeat : ").append(ws);
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyGUI.prmInt)).toString();
            this.drawString(msg, RX, this.centerY - 70, c1);
            stringbuilder = (new StringBuilder()).append("PrevSeat : ").append(ws);
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyExtra.prmInt)).toString();
            this.drawString(msg, RX, this.centerY - 60, c1);
        }

        if (seatID >= 0 && seatID <= 1 && ac.haveFlare()) {
            c1 = ac.isFlarePreparation() ? colorInactive : colorActive;
            stringbuilder = (new StringBuilder()).append("Flare : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyFlare.prmInt)).toString();
            this.drawString(msg, RX, this.centerY - 50, c1);
        }

        if (seatID == 0 && info.haveLandingGear()) {
            if (ac.canFoldLandingGear()) {
                stringbuilder = (new StringBuilder()).append("Gear Up : ");
                mch_config = MCH_MOD.config;
                msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyGearUpDown.prmInt)).toString();
                this.drawString(msg, RX, this.centerY - 40, colorActive);
            } else if (ac.canUnfoldLandingGear()) {
                stringbuilder = (new StringBuilder()).append("Gear Down : ");
                mch_config = MCH_MOD.config;
                msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyGearUpDown.prmInt)).toString();
                this.drawString(msg, RX, this.centerY - 40, colorActive);
            }
        }

        MCH_WeaponSet ws1 = ac.getCurrentWeapon(player);

        if (ac.getWeaponNum() > 1) {
            stringbuilder = (new StringBuilder()).append("Weapon : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeySwitchWeapon2.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 70, colorActive);
        }

        if (ws1.getCurrentWeapon().numMode > 0) {
            stringbuilder = (new StringBuilder()).append("WeaponMode : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeySwWeaponMode.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 60, colorActive);
        }

        if (ac.canSwitchSearchLight(player)) {
            stringbuilder = (new StringBuilder()).append("SearchLight : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyCameraMode.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 50, colorActive);
        } else if (ac.canSwitchCameraMode(seatID)) {
            stringbuilder = (new StringBuilder()).append("CameraMode : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyCameraMode.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 50, colorActive);
        }

        if (seatID == 0 && ac.getSeatNum() >= 1) {
            int color = colorActive;

            if (info.isEnableParachuting && MCH_Lib.getBlockIdY(ac, 3, -10) == 0) {
                stringbuilder = (new StringBuilder()).append("Parachuting : ");
                mch_config = MCH_MOD.config;
                msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyUnmount.prmInt)).toString();
            } else if (ac.canStartRepelling()) {
                stringbuilder = (new StringBuilder()).append("Repelling : ");
                mch_config = MCH_MOD.config;
                msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyUnmount.prmInt)).toString();
                color = -256;
            } else {
                stringbuilder = (new StringBuilder()).append("Dismount : ");
                mch_config = MCH_MOD.config;
                msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyUnmount.prmInt)).toString();
            }

            this.drawString(msg, LX, this.centerY - 30, color);
        }

        if (seatID == 0 && ac.canSwitchFreeLook() || seatID > 0 && ac.canSwitchGunnerModeOtherSeat(player)) {
            stringbuilder = (new StringBuilder()).append("FreeLook : ");
            mch_config = MCH_MOD.config;
            msg = stringbuilder.append(MCH_KeyName.getDescOrName(MCH_Config.KeyFreeLook.prmInt)).toString();
            this.drawString(msg, LX, this.centerY - 20, colorActive);
        }

    }
}

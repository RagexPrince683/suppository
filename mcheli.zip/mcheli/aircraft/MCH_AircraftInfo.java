package mcheli.aircraft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import mcheli.MCH_BaseInfo;
import mcheli.MCH_MOD;
import mcheli.hud.MCH_Hud;
import mcheli.hud.MCH_HudManager;
import mcheli.weapon.MCH_WeaponInfoManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.model.IModelCustom;

public abstract class MCH_AircraftInfo extends MCH_BaseInfo {

    public final String name;
    public String displayName;
    public HashMap displayNameLang;
    public int itemID;
    public List recipeString;
    public List recipe;
    public boolean isShapedRecipe;
    public String category;
    public boolean isEnableGunnerMode;
    public int cameraZoom;
    public boolean isEnableConcurrentGunnerMode;
    public boolean isEnableNightVision;
    public boolean isEnableEntityRadar;
    public boolean isEnableEjectionSeat;
    public boolean isEnableParachuting;
    public MCH_AircraftInfo.Flare flare;
    public float bodyHeight;
    public float bodyWidth;
    public boolean isFloat;
    public float floatOffset;
    public float gravity;
    public float gravityInWater;
    public int maxHp;
    public float armorMinDamage;
    public float armorMaxDamage;
    public float armorDamageFactor;
    public boolean enableBack;
    public int inventorySize;
    public boolean isUAV;
    public boolean isSmallUAV;
    public boolean isTargetDrone;
    public float autoPilotRot;
    public float onGroundPitch;
    public boolean canMoveOnGround;
    public boolean canRotOnGround;
    public List weaponSetList;
    public List seatList;
    public List exclusionSeatList;
    public List hudList;
    public MCH_Hud hudTvMissile;
    public float damageFactor;
    public float submergedDamageHeight;
    public boolean regeneration;
    public List extraBoundingBox;
    public List wheels;
    public int maxFuel;
    public float fuelConsumption;
    public float fuelSupplyRange;
    public float ammoSupplyRange;
    public float repairOtherVehiclesRange;
    public int repairOtherVehiclesValue;
    public float stealth;
    public boolean canRide;
    public float entityWidth;
    public float entityHeight;
    public float entityPitch;
    public float entityRoll;
    public float stepHeight;
    public List entityRackList;
    public int mobSeatNum;
    public int entityRackNum;
    public MCH_MobDropOption mobDropOption;
    public List repellingHooks;
    public List rideRacks;
    public List particleSplashs;
    public List searchLights;
    public float rotorSpeed;
    public boolean enableSeaSurfaceParticle;
    public float pivotTurnThrottle;
    public float trackRollerRot;
    public float partWheelRot;
    public float onGroundPitchFactor;
    public float onGroundRollFactor;
    public Vec3 turretPosition;
    public boolean defaultFreelook;
    public Vec3 unmountPosition;
    public float markerWidth;
    public float markerHeight;
    public float bbZmin;
    public float bbZmax;
    public float bbZ;
    public boolean alwaysCameraView;
    public List cameraPosition;
    public float cameraRotationSpeed;
    public float speed;
    public float motionFactor;
    public float mobilityYaw;
    public float mobilityPitch;
    public float mobilityRoll;
    public float mobilityYawOnGround;
    public float minRotationPitch;
    public float maxRotationPitch;
    public float minRotationRoll;
    public float maxRotationRoll;
    public boolean limitRotation;
    public float throttleUpDown;
    public float throttleUpDownOnEntity;
    private List textureNameList;
    public int textureCount;
    public float particlesScale;
    public boolean hideEntity;
    public boolean smoothShading;
    public String soundMove;
    public float soundRange;
    public float soundVolume;
    public float soundPitch;
    public IModelCustom model;
    public List hatchList;
    public List cameraList;
    public List partWeapon;
    public List partWeaponBay;
    public List canopyList;
    public List landingGear;
    public List partThrottle;
    public List partRotPart;
    public List partCrawlerTrack;
    public List partTrackRoller;
    public List partWheel;
    public List partSteeringWheel;
    public List lightHatchList;
    private String lastWeaponType = "";
    private int lastWeaponIndex = -1;
    private MCH_AircraftInfo.PartWeapon lastWeaponPart;

    public abstract Item getItem();

    public ItemStack getItemStack() {
        return new ItemStack(this.getItem());
    }

    public abstract String getDirectoryName();

    public abstract String getKindName();

    public MCH_AircraftInfo(String s) {
        this.name = s;
        this.displayName = this.name;
        this.displayNameLang = new HashMap();
        this.itemID = 0;
        this.recipeString = new ArrayList();
        this.recipe = new ArrayList();
        this.isShapedRecipe = true;
        this.category = "zzz";
        this.isEnableGunnerMode = false;
        this.isEnableConcurrentGunnerMode = false;
        this.isEnableNightVision = false;
        this.isEnableEntityRadar = false;
        this.isEnableEjectionSeat = false;
        this.isEnableParachuting = false;
        this.flare = new MCH_AircraftInfo.Flare();
        this.weaponSetList = new ArrayList();
        this.seatList = new ArrayList();
        this.exclusionSeatList = new ArrayList();
        this.hudList = new ArrayList();
        this.hudTvMissile = null;
        this.bodyHeight = 0.7F;
        this.bodyWidth = 2.0F;
        this.isFloat = false;
        this.floatOffset = 0.0F;
        this.gravity = -0.04F;
        this.gravityInWater = -0.04F;
        this.maxHp = 50;
        this.damageFactor = 0.2F;
        this.submergedDamageHeight = 0.0F;
        this.inventorySize = 0;
        this.armorDamageFactor = 1.0F;
        this.armorMaxDamage = 100000.0F;
        this.armorMinDamage = 0.0F;
        this.enableBack = false;
        this.isUAV = false;
        this.isSmallUAV = false;
        this.isTargetDrone = false;
        this.autoPilotRot = -0.6F;
        this.regeneration = false;
        this.onGroundPitch = 0.0F;
        this.canMoveOnGround = true;
        this.canRotOnGround = true;
        this.cameraZoom = this.getDefaultMaxZoom();
        this.extraBoundingBox = new ArrayList();
        this.maxFuel = 0;
        this.fuelConsumption = 1.0F;
        this.fuelSupplyRange = 0.0F;
        this.ammoSupplyRange = 0.0F;
        this.repairOtherVehiclesRange = 0.0F;
        this.repairOtherVehiclesValue = 10;
        this.stealth = 0.0F;
        this.canRide = true;
        this.entityWidth = 1.0F;
        this.entityHeight = 1.0F;
        this.entityPitch = 0.0F;
        this.entityRoll = 0.0F;
        this.stepHeight = this.getDefaultStepHeight();
        this.entityRackList = new ArrayList();
        this.mobSeatNum = 0;
        this.entityRackNum = 0;
        this.mobDropOption = new MCH_MobDropOption();
        this.repellingHooks = new ArrayList();
        this.rideRacks = new ArrayList();
        this.particleSplashs = new ArrayList();
        this.searchLights = new ArrayList();
        this.markerHeight = 1.0F;
        this.markerWidth = 2.0F;
        this.bbZmax = 1.0F;
        this.bbZmin = -1.0F;
        this.rotorSpeed = this.getDefaultRotorSpeed();
        this.wheels = this.getDefaultWheelList();
        this.onGroundPitchFactor = 0.0F;
        this.onGroundRollFactor = 0.0F;
        this.turretPosition = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
        this.defaultFreelook = false;
        this.unmountPosition = null;
        this.cameraPosition = new ArrayList();
        this.alwaysCameraView = false;
        this.cameraRotationSpeed = 1000.0F;
        this.speed = 0.1F;
        this.motionFactor = 0.96F;
        this.mobilityYaw = 1.0F;
        this.mobilityPitch = 1.0F;
        this.mobilityRoll = 1.0F;
        this.mobilityYawOnGround = 1.0F;
        this.minRotationPitch = this.getMinRotationPitch();
        this.maxRotationPitch = this.getMaxRotationPitch();
        this.minRotationRoll = this.getMinRotationPitch();
        this.maxRotationRoll = this.getMaxRotationPitch();
        this.limitRotation = false;
        this.throttleUpDown = 1.0F;
        this.throttleUpDownOnEntity = 2.0F;
        this.pivotTurnThrottle = 0.0F;
        this.trackRollerRot = 30.0F;
        this.partWheelRot = 30.0F;
        this.textureNameList = new ArrayList();
        this.textureNameList.add(this.name);
        this.textureCount = 0;
        this.particlesScale = 1.0F;
        this.enableSeaSurfaceParticle = false;
        this.hideEntity = false;
        this.smoothShading = true;
        this.soundMove = "";
        this.soundPitch = 1.0F;
        this.soundVolume = 1.0F;
        this.soundRange = this.getDefaultSoundRange();
        this.model = null;
        this.hatchList = new ArrayList();
        this.cameraList = new ArrayList();
        this.partWeapon = new ArrayList();
        this.lastWeaponPart = null;
        this.partWeaponBay = new ArrayList();
        this.canopyList = new ArrayList();
        this.landingGear = new ArrayList();
        this.partThrottle = new ArrayList();
        this.partRotPart = new ArrayList();
        this.partCrawlerTrack = new ArrayList();
        this.partTrackRoller = new ArrayList();
        this.partWheel = new ArrayList();
        this.partSteeringWheel = new ArrayList();
        this.lightHatchList = new ArrayList();
    }

    public float getDefaultSoundRange() {
        return 100.0F;
    }

    public List getDefaultWheelList() {
        return new ArrayList();
    }

    public float getDefaultRotorSpeed() {
        return 0.0F;
    }

    private float getDefaultStepHeight() {
        return 0.0F;
    }

    public boolean haveRepellingHook() {
        return this.repellingHooks.size() > 0;
    }

    public boolean haveFlare() {
        return this.flare.types.length > 0;
    }

    public boolean haveCanopy() {
        return this.canopyList.size() > 0;
    }

    public boolean haveLandingGear() {
        return this.landingGear.size() > 0;
    }

    public abstract String getDefaultHudName(int i);

    public boolean isValidData() throws Exception {
        if (this.cameraPosition.size() <= 0) {
            this.cameraPosition.add(new MCH_AircraftInfo.CameraPosition());
        }

        this.bbZ = (this.bbZmax + this.bbZmin) / 2.0F;
        if (this.isTargetDrone) {
            this.isUAV = true;
        }

        if (this.isEnableParachuting && this.repellingHooks.size() > 0) {
            this.isEnableParachuting = false;
            this.repellingHooks.clear();
        }

        if (this.isUAV) {
            this.alwaysCameraView = true;
            if (this.seatList.size() == 0) {
                MCH_SeatInfo i = new MCH_SeatInfo(Vec3.createVectorHelper(0.0D, 0.0D, 0.0D), false);

                this.seatList.add(i);
            }
        }

        this.mobSeatNum = this.seatList.size();
        this.entityRackNum = this.entityRackList.size();
        if (this.getNumSeat() < 1) {
            throw new Exception();
        } else {
            int i;

            if (this.getNumHud() < this.getNumSeat()) {
                for (i = this.getNumHud(); i < this.getNumSeat(); ++i) {
                    this.hudList.add(MCH_HudManager.get(this.getDefaultHudName(i)));
                }
            }

            if (this.getNumSeat() == 1 && this.getNumHud() == 1) {
                this.hudList.add(MCH_HudManager.get(this.getDefaultHudName(1)));
            }

            Iterator iterator = this.entityRackList.iterator();

            while (iterator.hasNext()) {
                MCH_SeatRackInfo wb = (MCH_SeatRackInfo) iterator.next();

                this.seatList.add(wb);
            }

            this.entityRackList.clear();
            if (this.hudTvMissile == null) {
                this.hudTvMissile = MCH_HudManager.get("tv_missile");
            }

            if (this.textureNameList.size() < 1) {
                throw new Exception();
            } else {
                if (this.itemID <= 0) {
                    ;
                }

                for (i = 0; i < this.partWeaponBay.size(); ++i) {
                    MCH_AircraftInfo.WeaponBay mch_aircraftinfo_weaponbay = (MCH_AircraftInfo.WeaponBay) this.partWeaponBay.get(i);
                    String[] weaponNames = mch_aircraftinfo_weaponbay.weaponName.split("\\s*/\\s*");

                    if (weaponNames.length <= 0) {
                        this.partWeaponBay.remove(i);
                    } else {
                        ArrayList list = new ArrayList();
                        String[] arr$ = weaponNames;
                        int len$ = weaponNames.length;

                        for (int i$ = 0; i$ < len$; ++i$) {
                            String s = arr$[i$];
                            int id = this.getWeaponIdByName(s);

                            if (id >= 0) {
                                list.add(Integer.valueOf(id));
                            }
                        }

                        if (list.size() <= 0) {
                            this.partWeaponBay.remove(i);
                        } else {
                            ((MCH_AircraftInfo.WeaponBay) this.partWeaponBay.get(i)).weaponIds = (Integer[]) list.toArray(new Integer[0]);
                        }
                    }
                }

                return true;
            }
        }
    }

    public int getInfo_MaxSeatNum() {
        return 30;
    }

    public int getNumSeatAndRack() {
        return this.seatList.size();
    }

    public int getNumSeat() {
        return this.mobSeatNum;
    }

    public int getNumRack() {
        return this.entityRackNum;
    }

    public int getNumHud() {
        return this.hudList.size();
    }

    public float getMaxSpeed() {
        return 0.8F;
    }

    public float getMinRotationPitch() {
        return -89.9F;
    }

    public float getMaxRotationPitch() {
        return 80.0F;
    }

    public float getMinRotationRoll() {
        return -80.0F;
    }

    public float getMaxRotationRoll() {
        return 80.0F;
    }

    public int getDefaultMaxZoom() {
        return 1;
    }

    public boolean haveHatch() {
        return this.hatchList.size() > 0;
    }

    public boolean havePartCamera() {
        return this.cameraList.size() > 0;
    }

    public boolean havePartThrottle() {
        return this.partThrottle.size() > 0;
    }

    public MCH_AircraftInfo.WeaponSet getWeaponSetById(int id) {
        return id >= 0 && id < this.weaponSetList.size() ? (MCH_AircraftInfo.WeaponSet) this.weaponSetList.get(id) : null;
    }

    public MCH_AircraftInfo.Weapon getWeaponById(int id) {
        MCH_AircraftInfo.WeaponSet ws = this.getWeaponSetById(id);

        return ws != null ? (MCH_AircraftInfo.Weapon) ws.weapons.get(0) : null;
    }

    public int getWeaponIdByName(String s) {
        for (int i = 0; i < this.weaponSetList.size(); ++i) {
            if (((MCH_AircraftInfo.WeaponSet) this.weaponSetList.get(i)).type.equalsIgnoreCase(s)) {
                return i;
            }
        }

        return -1;
    }

    public MCH_AircraftInfo.Weapon getWeaponByName(String s) {
        for (int i = 0; i < this.weaponSetList.size(); ++i) {
            if (((MCH_AircraftInfo.WeaponSet) this.weaponSetList.get(i)).type.equalsIgnoreCase(s)) {
                return this.getWeaponById(i);
            }
        }

        return null;
    }

    public int getWeaponNum() {
        return this.weaponSetList.size();
    }

    public void loadItemData(String item, String data) {
        if (item.compareTo("displayname") == 0) {
            this.displayName = data.trim();
        } else {
            String[] s;

            if (item.compareTo("adddisplayname") == 0) {
                s = data.split("\\s*,\\s*");
                if (s != null && s.length == 2) {
                    this.displayNameLang.put(s[0].trim(), s[1].trim());
                }
            } else if (item.equalsIgnoreCase("Category")) {
                this.category = data.toUpperCase().replaceAll("[,;:]", ".").replaceAll("[ \t]", "");
            } else if (item.equalsIgnoreCase("CanRide")) {
                this.canRide = this.toBool(data, true);
            } else if (item.equalsIgnoreCase("MaxFuel")) {
                this.maxFuel = this.toInt(data, 0, 100000000);
            } else if (item.equalsIgnoreCase("FuelConsumption")) {
                this.fuelConsumption = this.toFloat(data, 0.0F, 10000.0F);
            } else if (item.equalsIgnoreCase("FuelSupplyRange")) {
                this.fuelSupplyRange = this.toFloat(data, 0.0F, 1000.0F);
            } else if (item.equalsIgnoreCase("AmmoSupplyRange")) {
                this.ammoSupplyRange = this.toFloat(data, 0.0F, 1000.0F);
            } else if (item.equalsIgnoreCase("RepairOtherVehicles")) {
                s = this.splitParam(data);
                if (s.length >= 1) {
                    this.repairOtherVehiclesRange = this.toFloat(s[0], 0.0F, 1000.0F);
                    if (s.length >= 2) {
                        this.repairOtherVehiclesValue = this.toInt(s[1], 0, 10000000);
                    }
                }
            } else if (item.compareTo("itemid") == 0) {
                this.itemID = this.toInt(data, 0, '\uffff');
            } else if (item.compareTo("addtexture") == 0) {
                this.textureNameList.add(data.toLowerCase());
            } else if (item.compareTo("particlesscale") == 0) {
                this.particlesScale = this.toFloat(data, 0.0F, 50.0F);
            } else if (item.equalsIgnoreCase("EnableSeaSurfaceParticle")) {
                this.enableSeaSurfaceParticle = this.toBool(data);
            } else {
                Vec3 df;
                int c;
                float ry;
                float rz;
                int px;
                float py;
                float pz;

                if (item.equalsIgnoreCase("AddParticleSplash")) {
                    s = this.splitParam(data);
                    if (s.length >= 3) {
                        df = this.toVec3(s[0], s[1], s[2]);
                        c = s.length >= 4 ? this.toInt(s[3], 1, 100) : 2;
                        ry = s.length >= 5 ? this.toFloat(s[4]) : 2.0F;
                        rz = s.length >= 6 ? this.toFloat(s[5]) : 1.0F;
                        px = s.length >= 7 ? this.toInt(s[6], 1, 100000) : 80;
                        py = s.length >= 8 ? this.toFloat(s[7]) : 0.01F;
                        pz = s.length >= 9 ? this.toFloat(s[8]) : 0.0F;
                        this.particleSplashs.add(new MCH_AircraftInfo.ParticleSplash(df, c, ry, rz, px, py, pz));
                    }
                } else {
                    float w;
                    int i;
                    float f;

                    if (!item.equalsIgnoreCase("AddSearchLight") && !item.equalsIgnoreCase("AddFixedSearchLight") && !item.equalsIgnoreCase("AddSteeringSearchLight")) {
                        float f1;

                        if (item.equalsIgnoreCase("AddPartLightHatch")) {
                            s = this.splitParam(data);
                            if (s.length >= 6) {
                                f1 = s.length >= 7 ? this.toFloat(s[6], -1800.0F, 1800.0F) : 90.0F;
                                this.lightHatchList.add(new MCH_AircraftInfo.Hatch(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), f1, "light_hatch" + this.lightHatchList.size(), false));
                            }
                        } else {
                            int j;

                            if (item.equalsIgnoreCase("AddRepellingHook")) {
                                s = this.splitParam(data);
                                if (s != null && s.length >= 3) {
                                    j = s.length >= 4 ? this.toInt(s[3], 1, 100000) : 10;
                                    this.repellingHooks.add(new MCH_AircraftInfo.RepellingHook(this.toVec3(s[0], s[1], s[2]), j));
                                }
                            } else {
                                String[] astring;
                                float f2;
                                boolean flag;

                                if (item.equalsIgnoreCase("AddRack")) {
                                    s = data.toLowerCase().split("\\s*,\\s*");
                                    if (s != null && s.length >= 7) {
                                        astring = s[0].split("\\s*/\\s*");
                                        f2 = s.length >= 8 ? this.toFloat(s[7]) : 6.0F;
                                        ry = s.length >= 9 ? this.toFloat(s[8], 0.0F, 1000000.0F) : 20.0F;
                                        rz = s.length >= 10 ? this.toFloat(s[9]) : 0.0F;
                                        f = s.length >= 11 ? this.toFloat(s[10]) : 0.0F;
                                        flag = s.length >= 12 ? this.toBool(s[11]) : false;
                                        this.entityRackList.add(new MCH_SeatRackInfo(astring, this.toDouble(s[1]), this.toDouble(s[2]), this.toDouble(s[3]), new MCH_AircraftInfo.CameraPosition(this.toVec3(s[4], s[5], s[6]).addVector(0.0D, 1.5D, 0.0D)), f2, ry, rz, f, flag));
                                    }
                                } else if (item.equalsIgnoreCase("RideRack")) {
                                    s = this.splitParam(data);
                                    if (s.length >= 2) {
                                        MCH_AircraftInfo.RideRack mch_aircraftinfo_riderack = new MCH_AircraftInfo.RideRack(s[0].trim().toLowerCase(), this.toInt(s[1], 1, 10000));

                                        this.rideRacks.add(mch_aircraftinfo_riderack);
                                    }
                                } else {
                                    Vec3 vec3;
                                    boolean flag1;
                                    boolean flag2;
                                    boolean flag3;

                                    if (!item.equalsIgnoreCase("AddSeat") && !item.equalsIgnoreCase("AddGunnerSeat") && !item.equalsIgnoreCase("AddFixRotSeat")) {
                                        if (item.equalsIgnoreCase("SetWheelPos")) {
                                            s = this.splitParam(data);
                                            if (s.length >= 4) {
                                                f1 = Math.abs(this.toFloat(s[0]));
                                                f2 = this.toFloat(s[1]);
                                                this.wheels.clear();

                                                for (i = 2; i < s.length; ++i) {
                                                    this.wheels.add(new MCH_AircraftInfo.Wheel(Vec3.createVectorHelper((double) f1, (double) f2, (double) this.toFloat(s[i]))));
                                                }

                                                Collections.sort(this.wheels, new Comparator() {
                                                    public int compare(MCH_AircraftInfo.Wheel arg0, MCH_AircraftInfo.Wheel arg1) {
                                                        return arg0.pos.zCoord > arg1.pos.zCoord ? -1 : 1;
                                                    }
                                                });
                                            }
                                        } else if (item.equalsIgnoreCase("ExclusionSeat")) {
                                            s = this.splitParam(data);
                                            if (s.length >= 2) {
                                                Integer[] ainteger = new Integer[s.length];

                                                for (c = 0; c < ainteger.length; ++c) {
                                                    ainteger[c] = Integer.valueOf(this.toInt(s[c], 1, 10000) - 1);
                                                }

                                                this.exclusionSeatList.add(ainteger);
                                            }
                                        } else if (MCH_MOD.proxy.isRemote() && item.equalsIgnoreCase("HUD")) {
                                            this.hudList.clear();
                                            s = data.split("\\s*,\\s*");
                                            astring = s;
                                            c = s.length;

                                            for (i = 0; i < c; ++i) {
                                                String s = astring[i];
                                                MCH_Hud mch_hud = MCH_HudManager.get(s);

                                                if (mch_hud == null) {
                                                    mch_hud = MCH_Hud.NoDisp;
                                                }

                                                this.hudList.add(mch_hud);
                                            }
                                        } else if (item.compareTo("enablenightvision") == 0) {
                                            this.isEnableNightVision = this.toBool(data);
                                        } else if (item.compareTo("enableentityradar") == 0) {
                                            this.isEnableEntityRadar = this.toBool(data);
                                        } else if (item.equalsIgnoreCase("EnableEjectionSeat")) {
                                            this.isEnableEjectionSeat = this.toBool(data);
                                        } else if (item.equalsIgnoreCase("EnableParachuting")) {
                                            this.isEnableParachuting = this.toBool(data);
                                        } else if (item.equalsIgnoreCase("MobDropOption")) {
                                            s = this.splitParam(data);
                                            if (s.length >= 3) {
                                                this.mobDropOption.pos = this.toVec3(s[0], s[1], s[2]);
                                                this.mobDropOption.interval = s.length >= 4 ? this.toInt(s[3]) : 12;
                                            }
                                        } else if (item.equalsIgnoreCase("Width")) {
                                            this.bodyWidth = this.toFloat(data, 0.1F, 1000.0F);
                                        } else if (item.equalsIgnoreCase("Height")) {
                                            this.bodyHeight = this.toFloat(data, 0.1F, 1000.0F);
                                        } else if (item.compareTo("float") == 0) {
                                            this.isFloat = this.toBool(data);
                                        } else if (item.compareTo("floatoffset") == 0) {
                                            this.floatOffset = -this.toFloat(data);
                                        } else if (item.compareTo("gravity") == 0) {
                                            this.gravity = this.toFloat(data, -50.0F, 50.0F);
                                        } else if (item.compareTo("gravityinwater") == 0) {
                                            this.gravityInWater = this.toFloat(data, -50.0F, 50.0F);
                                        } else {
                                            boolean flag4;

                                            if (item.compareTo("cameraposition") == 0) {
                                                s = data.split("\\s*,\\s*");
                                                if (s.length >= 3) {
                                                    this.alwaysCameraView = s.length >= 4 ? this.toBool(s[3]) : false;
                                                    flag4 = s.length >= 5;
                                                    f2 = s.length >= 5 ? this.toFloat(s[4]) : 0.0F;
                                                    ry = s.length >= 6 ? this.toFloat(s[5]) : 0.0F;
                                                    this.cameraPosition.add(new MCH_AircraftInfo.CameraPosition(this.toVec3(s[0], s[1], s[2]), flag4, f2, ry));
                                                }
                                            } else if (item.equalsIgnoreCase("UnmountPosition")) {
                                                s = data.split("\\s*,\\s*");
                                                if (s.length >= 3) {
                                                    this.unmountPosition = this.toVec3(s[0], s[1], s[2]);
                                                }
                                            } else if (item.equalsIgnoreCase("TurretPosition")) {
                                                s = data.split("\\s*,\\s*");
                                                if (s.length >= 3) {
                                                    this.turretPosition = this.toVec3(s[0], s[1], s[2]);
                                                }
                                            } else if (item.equalsIgnoreCase("CameraRotationSpeed")) {
                                                this.cameraRotationSpeed = this.toFloat(data, 0.0F, 10000.0F);
                                            } else if (item.compareTo("regeneration") == 0) {
                                                this.regeneration = this.toBool(data);
                                            } else if (item.compareTo("speed") == 0) {
                                                this.speed = this.toFloat(data, 0.0F, this.getMaxSpeed());
                                            } else if (item.equalsIgnoreCase("EnableBack")) {
                                                this.enableBack = this.toBool(data);
                                            } else if (item.equalsIgnoreCase("MotionFactor")) {
                                                this.motionFactor = this.toFloat(data, 0.0F, 1.0F);
                                            } else if (item.equalsIgnoreCase("MobilityYawOnGround")) {
                                                this.mobilityYawOnGround = this.toFloat(data, 0.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("MobilityYaw")) {
                                                this.mobilityYaw = this.toFloat(data, 0.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("MobilityPitch")) {
                                                this.mobilityPitch = this.toFloat(data, 0.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("MobilityRoll")) {
                                                this.mobilityRoll = this.toFloat(data, 0.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("MinRotationPitch")) {
                                                this.limitRotation = true;
                                                this.minRotationPitch = this.toFloat(data, this.getMinRotationPitch(), 0.0F);
                                            } else if (item.equalsIgnoreCase("MaxRotationPitch")) {
                                                this.limitRotation = true;
                                                this.maxRotationPitch = this.toFloat(data, 0.0F, this.getMaxRotationPitch());
                                            } else if (item.equalsIgnoreCase("MinRotationRoll")) {
                                                this.limitRotation = true;
                                                this.minRotationRoll = this.toFloat(data, this.getMinRotationRoll(), 0.0F);
                                            } else if (item.equalsIgnoreCase("MaxRotationRoll")) {
                                                this.limitRotation = true;
                                                this.maxRotationRoll = this.toFloat(data, 0.0F, this.getMaxRotationRoll());
                                            } else if (item.compareTo("throttleupdown") == 0) {
                                                this.throttleUpDown = this.toFloat(data, 0.0F, 3.0F);
                                            } else if (item.equalsIgnoreCase("ThrottleUpDownOnEntity")) {
                                                this.throttleUpDownOnEntity = this.toFloat(data, 0.0F, 100000.0F);
                                            } else if (item.equalsIgnoreCase("Stealth")) {
                                                this.stealth = this.toFloat(data, 0.0F, 1.0F);
                                            } else if (item.equalsIgnoreCase("EntityWidth")) {
                                                this.entityWidth = this.toFloat(data, -100.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("EntityHeight")) {
                                                this.entityHeight = this.toFloat(data, -100.0F, 100.0F);
                                            } else if (item.equalsIgnoreCase("EntityPitch")) {
                                                this.entityPitch = this.toFloat(data, -360.0F, 360.0F);
                                            } else if (item.equalsIgnoreCase("EntityRoll")) {
                                                this.entityRoll = this.toFloat(data, -360.0F, 360.0F);
                                            } else if (item.equalsIgnoreCase("StepHeight")) {
                                                this.stepHeight = this.toFloat(data, 0.0F, 1000.0F);
                                            } else if (item.equalsIgnoreCase("CanMoveOnGround")) {
                                                this.canMoveOnGround = this.toBool(data);
                                            } else if (item.equalsIgnoreCase("CanRotOnGround")) {
                                                this.canRotOnGround = this.toBool(data);
                                            } else if (!item.equalsIgnoreCase("AddWeapon") && !item.equalsIgnoreCase("AddTurretWeapon")) {
                                                if (!item.equalsIgnoreCase("AddPartWeapon") && !item.equalsIgnoreCase("AddPartRotWeapon") && !item.equalsIgnoreCase("AddPartTurretWeapon") && !item.equalsIgnoreCase("AddPartTurretRotWeapon") && !item.equalsIgnoreCase("AddPartWeaponMissile")) {
                                                    if (item.equalsIgnoreCase("AddPartWeaponChild")) {
                                                        s = data.split("\\s*,\\s*");
                                                        if (s.length >= 5 && this.lastWeaponPart != null) {
                                                            f1 = s.length >= 6 ? this.toFloat(s[5]) : 0.0F;
                                                            MCH_AircraftInfo.PartWeaponChild mch_aircraftinfo_partweaponchild = new MCH_AircraftInfo.PartWeaponChild(this.lastWeaponPart.name, this.toBool(s[0]), this.toBool(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.lastWeaponPart.modelName + "_" + this.lastWeaponPart.child.size(), 0.0F, 0.0F, 0.0F, f1);

                                                            this.lastWeaponPart.child.add(mch_aircraftinfo_partweaponchild);
                                                        }
                                                    } else if (item.compareTo("addrecipe") != 0 && item.compareTo("addshapelessrecipe") != 0) {
                                                        if (item.compareTo("maxhp") == 0) {
                                                            this.maxHp = this.toInt(data, 1, 100000);
                                                        } else if (item.compareTo("inventorysize") == 0) {
                                                            this.inventorySize = this.toInt(data, 0, 54);
                                                        } else if (item.compareTo("damagefactor") == 0) {
                                                            this.damageFactor = this.toFloat(data, 0.0F, 1.0F);
                                                        } else if (item.equalsIgnoreCase("SubmergedDamageHeight")) {
                                                            this.submergedDamageHeight = this.toFloat(data, -1000.0F, 1000.0F);
                                                        } else if (item.equalsIgnoreCase("ArmorDamageFactor")) {
                                                            this.armorDamageFactor = this.toFloat(data, 0.0F, 10000.0F);
                                                        } else if (item.equalsIgnoreCase("ArmorMinDamage")) {
                                                            this.armorMinDamage = this.toFloat(data, 0.0F, 1000000.0F);
                                                        } else if (item.equalsIgnoreCase("ArmorMaxDamage")) {
                                                            this.armorMaxDamage = this.toFloat(data, 0.0F, 1000000.0F);
                                                        } else if (item.equalsIgnoreCase("FlareType")) {
                                                            s = data.split("\\s*,\\s*");
                                                            this.flare.types = new int[s.length];

                                                            for (j = 0; j < s.length; ++j) {
                                                                this.flare.types[j] = this.toInt(s[j], 1, 10);
                                                            }
                                                        } else if (item.equalsIgnoreCase("FlareOption")) {
                                                            s = this.splitParam(data);
                                                            if (s.length >= 3) {
                                                                this.flare.pos = this.toVec3(s[0], s[1], s[2]);
                                                            }
                                                        } else if (item.equalsIgnoreCase("Sound")) {
                                                            this.soundMove = data.toLowerCase();
                                                        } else if (item.equalsIgnoreCase("SoundRange")) {
                                                            this.soundRange = this.toFloat(data, 1.0F, 1000.0F);
                                                        } else if (item.equalsIgnoreCase("SoundVolume")) {
                                                            this.soundVolume = this.toFloat(data, 0.0F, 10.0F);
                                                        } else if (item.equalsIgnoreCase("SoundPitch")) {
                                                            this.soundPitch = this.toFloat(data, 0.0F, 10.0F);
                                                        } else if (item.equalsIgnoreCase("UAV")) {
                                                            this.isUAV = this.toBool(data);
                                                            this.isSmallUAV = false;
                                                        } else if (item.equalsIgnoreCase("SmallUAV")) {
                                                            this.isUAV = this.toBool(data);
                                                            this.isSmallUAV = true;
                                                        } else if (item.equalsIgnoreCase("TargetDrone")) {
                                                            this.isTargetDrone = this.toBool(data);
                                                        } else if (item.compareTo("autopilotrot") == 0) {
                                                            this.autoPilotRot = this.toFloat(data, -5.0F, 5.0F);
                                                        } else if (item.compareTo("ongroundpitch") == 0) {
                                                            this.onGroundPitch = -this.toFloat(data, -90.0F, 90.0F);
                                                        } else if (item.compareTo("enablegunnermode") == 0) {
                                                            this.isEnableGunnerMode = this.toBool(data);
                                                        } else if (item.compareTo("hideentity") == 0) {
                                                            this.hideEntity = this.toBool(data);
                                                        } else if (item.equalsIgnoreCase("SmoothShading")) {
                                                            this.smoothShading = this.toBool(data);
                                                        } else if (item.compareTo("concurrentgunnermode") == 0) {
                                                            this.isEnableConcurrentGunnerMode = this.toBool(data);
                                                        } else {
                                                            boolean flag5;

                                                            if (!item.equalsIgnoreCase("AddPartWeaponBay") && !item.equalsIgnoreCase("AddPartSlideWeaponBay")) {
                                                                if (item.compareTo("addparthatch") != 0 && item.compareTo("addpartslidehatch") != 0) {
                                                                    if (item.compareTo("addpartcanopy") != 0 && item.compareTo("addpartslidecanopy") != 0) {
                                                                        if (!item.equalsIgnoreCase("AddPartLG") && !item.equalsIgnoreCase("AddPartSlideRotLG") && !item.equalsIgnoreCase("AddPartLGRev") && !item.equalsIgnoreCase("AddPartLGHatch")) {
                                                                            if (item.equalsIgnoreCase("AddPartThrottle")) {
                                                                                s = data.split("\\s*,\\s*");
                                                                                if (s.length >= 7) {
                                                                                    f1 = s.length >= 8 ? this.toFloat(s[7]) : 0.0F;
                                                                                    f2 = s.length >= 9 ? this.toFloat(s[8]) : 0.0F;
                                                                                    ry = s.length >= 10 ? this.toFloat(s[9]) : 0.0F;
                                                                                    MCH_AircraftInfo.Throttle mch_aircraftinfo_throttle = new MCH_AircraftInfo.Throttle(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), this.toFloat(s[6]), "throttle" + this.partThrottle.size(), f1, f2, ry);

                                                                                    this.partThrottle.add(mch_aircraftinfo_throttle);
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("AddPartRotation")) {
                                                                                s = data.split("\\s*,\\s*");
                                                                                if (s.length >= 7) {
                                                                                    flag4 = s.length >= 8 ? this.toBool(s[7]) : true;
                                                                                    MCH_AircraftInfo.RotPart mch_aircraftinfo_rotpart = new MCH_AircraftInfo.RotPart(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), this.toFloat(s[6]), flag4, "rotpart" + this.partThrottle.size());

                                                                                    this.partRotPart.add(mch_aircraftinfo_rotpart);
                                                                                }
                                                                            } else if (item.compareTo("addpartcamera") == 0) {
                                                                                s = data.split("\\s*,\\s*");
                                                                                if (s.length >= 3) {
                                                                                    flag4 = s.length >= 4 ? this.toBool(s[3]) : true;
                                                                                    boolean flag6 = s.length >= 5 ? this.toBool(s[4]) : false;
                                                                                    MCH_AircraftInfo.Camera mch_aircraftinfo_camera = new MCH_AircraftInfo.Camera(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), 0.0F, -1.0F, 0.0F, "camera" + this.cameraList.size(), flag4, flag6);

                                                                                    this.cameraList.add(mch_aircraftinfo_camera);
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("AddPartWheel")) {
                                                                                s = this.splitParam(data);
                                                                                if (s.length >= 3) {
                                                                                    f1 = s.length >= 4 ? this.toFloat(s[3], -1800.0F, 1800.0F) : 0.0F;
                                                                                    f2 = s.length >= 7 ? this.toFloat(s[4]) : 0.0F;
                                                                                    ry = s.length >= 7 ? this.toFloat(s[5]) : 1.0F;
                                                                                    rz = s.length >= 7 ? this.toFloat(s[6]) : 0.0F;
                                                                                    f = s.length >= 10 ? this.toFloat(s[7]) : this.toFloat(s[0]);
                                                                                    py = s.length >= 10 ? this.toFloat(s[8]) : this.toFloat(s[1]);
                                                                                    pz = s.length >= 10 ? this.toFloat(s[9]) : this.toFloat(s[2]);
                                                                                    this.partWheel.add(new MCH_AircraftInfo.PartWheel(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), f2, ry, rz, f1, f, py, pz, "wheel" + this.partWheel.size()));
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("AddPartSteeringWheel")) {
                                                                                s = this.splitParam(data);
                                                                                if (s.length >= 7) {
                                                                                    this.partSteeringWheel.add(new MCH_AircraftInfo.PartWheel(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), this.toFloat(s[6]), "steering_wheel" + this.partSteeringWheel.size()));
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("AddTrackRoller")) {
                                                                                s = this.splitParam(data);
                                                                                if (s.length >= 3) {
                                                                                    this.partTrackRoller.add(new MCH_AircraftInfo.TrackRoller(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), "track_roller" + this.partTrackRoller.size()));
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("AddCrawlerTrack")) {
                                                                                this.partCrawlerTrack.add(this.createCrawlerTrack(data, "crawler_track" + this.partCrawlerTrack.size()));
                                                                            } else if (item.equalsIgnoreCase("PivotTurnThrottle")) {
                                                                                this.pivotTurnThrottle = this.toFloat(data, 0.0F, 1.0F);
                                                                            } else if (item.equalsIgnoreCase("TrackRollerRot")) {
                                                                                this.trackRollerRot = this.toFloat(data, -10000.0F, 10000.0F);
                                                                            } else if (item.equalsIgnoreCase("PartWheelRot")) {
                                                                                this.partWheelRot = this.toFloat(data, -10000.0F, 10000.0F);
                                                                            } else if (item.compareTo("camerazoom") == 0) {
                                                                                this.cameraZoom = this.toInt(data, 1, 10);
                                                                            } else if (item.equalsIgnoreCase("DefaultFreelook")) {
                                                                                this.defaultFreelook = this.toBool(data);
                                                                            } else if (item.equalsIgnoreCase("BoundingBox")) {
                                                                                s = data.split("\\s*,\\s*");
                                                                                if (s.length >= 5) {
                                                                                    f1 = s.length >= 6 ? this.toFloat(s[5]) : 1.0F;
                                                                                    MCH_BoundingBox mch_boundingbox = new MCH_BoundingBox((double) this.toFloat(s[0]), (double) this.toFloat(s[1]), (double) this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), f1);

                                                                                    this.extraBoundingBox.add(mch_boundingbox);
                                                                                    if (mch_boundingbox.boundingBox.maxY > (double) this.markerHeight) {
                                                                                        this.markerHeight = (float) mch_boundingbox.boundingBox.maxY;
                                                                                    }

                                                                                    this.markerWidth = (float) Math.max((double) this.markerWidth, Math.abs(mch_boundingbox.boundingBox.maxX) / 2.0D);
                                                                                    this.markerWidth = (float) Math.max((double) this.markerWidth, Math.abs(mch_boundingbox.boundingBox.minX) / 2.0D);
                                                                                    this.markerWidth = (float) Math.max((double) this.markerWidth, Math.abs(mch_boundingbox.boundingBox.maxZ) / 2.0D);
                                                                                    this.markerWidth = (float) Math.max((double) this.markerWidth, Math.abs(mch_boundingbox.boundingBox.minZ) / 2.0D);
                                                                                    this.bbZmin = (float) Math.min((double) this.bbZmin, mch_boundingbox.boundingBox.minZ);
                                                                                    this.bbZmax = (float) Math.min((double) this.bbZmax, mch_boundingbox.boundingBox.maxZ);
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("RotorSpeed")) {
                                                                                this.rotorSpeed = this.toFloat(data, -10000.0F, 10000.0F);
                                                                                if ((double) this.rotorSpeed > 0.01D) {
                                                                                    this.rotorSpeed = (float) ((double) this.rotorSpeed - 0.01D);
                                                                                }

                                                                                if ((double) this.rotorSpeed < -0.01D) {
                                                                                    this.rotorSpeed = (float) ((double) this.rotorSpeed + 0.01D);
                                                                                }
                                                                            } else if (item.equalsIgnoreCase("OnGroundPitchFactor")) {
                                                                                this.onGroundPitchFactor = this.toFloat(data, 0.0F, 180.0F);
                                                                            } else if (item.equalsIgnoreCase("OnGroundRollFactor")) {
                                                                                this.onGroundRollFactor = this.toFloat(data, 0.0F, 180.0F);
                                                                            }
                                                                        } else {
                                                                            s = data.split("\\s*,\\s*");
                                                                            MCH_AircraftInfo.LandingGear mch_aircraftinfo_landinggear;

                                                                            if (!item.equalsIgnoreCase("AddPartSlideRotLG") && s.length >= 6) {
                                                                                f1 = s.length >= 7 ? this.toFloat(s[6], -180.0F, 180.0F) : 90.0F;
                                                                                f1 /= 90.0F;
                                                                                mch_aircraftinfo_landinggear = new MCH_AircraftInfo.LandingGear(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), "lg" + this.landingGear.size(), f1, item.equalsIgnoreCase("AddPartLgRev"), item.equalsIgnoreCase("AddPartLGHatch"));
                                                                                if (s.length >= 8) {
                                                                                    mch_aircraftinfo_landinggear.enableRot2 = true;
                                                                                    mch_aircraftinfo_landinggear.maxRotFactor2 = s.length >= 11 ? this.toFloat(s[10], -180.0F, 180.0F) : 90.0F;
                                                                                    mch_aircraftinfo_landinggear.maxRotFactor2 /= 90.0F;
                                                                                    mch_aircraftinfo_landinggear.rot2 = Vec3.createVectorHelper((double) this.toFloat(s[7]), (double) this.toFloat(s[8]), (double) this.toFloat(s[9]));
                                                                                }

                                                                                this.landingGear.add(mch_aircraftinfo_landinggear);
                                                                            }

                                                                            if (item.equalsIgnoreCase("AddPartSlideRotLG") && s.length >= 9) {
                                                                                f1 = s.length >= 10 ? this.toFloat(s[9], -180.0F, 180.0F) : 90.0F;
                                                                                f1 /= 90.0F;
                                                                                mch_aircraftinfo_landinggear = new MCH_AircraftInfo.LandingGear(this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), this.toFloat(s[6]), this.toFloat(s[7]), this.toFloat(s[8]), "lg" + this.landingGear.size(), f1, false, false);
                                                                                mch_aircraftinfo_landinggear.slide = Vec3.createVectorHelper((double) this.toFloat(s[0]), (double) this.toFloat(s[1]), (double) this.toFloat(s[2]));
                                                                                this.landingGear.add(mch_aircraftinfo_landinggear);
                                                                            }
                                                                        }
                                                                    } else {
                                                                        s = data.split("\\s*,\\s*");
                                                                        flag4 = item.compareTo("addpartslidecanopy") == 0;
                                                                        i = this.canopyList.size();
                                                                        if (i > 0) {
                                                                            --i;
                                                                        }

                                                                        MCH_AircraftInfo.Canopy mch_aircraftinfo_canopy;

                                                                        if (flag4) {
                                                                            if (s.length >= 3) {
                                                                                mch_aircraftinfo_canopy = new MCH_AircraftInfo.Canopy(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), 0.0F, 0.0F, 0.0F, 90.0F, "canopy" + i, flag4);
                                                                                this.canopyList.add(mch_aircraftinfo_canopy);
                                                                                if (i == 0) {
                                                                                    mch_aircraftinfo_canopy = new MCH_AircraftInfo.Canopy(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), 0.0F, 0.0F, 0.0F, 90.0F, "canopy", flag4);
                                                                                    this.canopyList.add(mch_aircraftinfo_canopy);
                                                                                }
                                                                            }
                                                                        } else if (s.length >= 6) {
                                                                            f2 = s.length >= 7 ? this.toFloat(s[6], -180.0F, 180.0F) : 90.0F;
                                                                            f2 /= 90.0F;
                                                                            mch_aircraftinfo_canopy = new MCH_AircraftInfo.Canopy(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), f2, "canopy" + i, flag4);
                                                                            this.canopyList.add(mch_aircraftinfo_canopy);
                                                                            if (i == 0) {
                                                                                mch_aircraftinfo_canopy = new MCH_AircraftInfo.Canopy(this.toFloat(s[0]), this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), f2, "canopy", flag4);
                                                                                this.canopyList.add(mch_aircraftinfo_canopy);
                                                                            }
                                                                        }
                                                                    }
                                                                } else {
                                                                    flag5 = item.compareTo("addpartslidehatch") == 0;
                                                                    astring = data.split("\\s*,\\s*");
                                                                    vec3 = null;
                                                                    MCH_AircraftInfo.Hatch mch_aircraftinfo_hatch;

                                                                    if (flag5) {
                                                                        if (astring.length >= 3) {
                                                                            mch_aircraftinfo_hatch = new MCH_AircraftInfo.Hatch(this.toFloat(astring[0]), this.toFloat(astring[1]), this.toFloat(astring[2]), 0.0F, 0.0F, 0.0F, 90.0F, "hatch" + this.hatchList.size(), flag5);
                                                                            this.hatchList.add(mch_aircraftinfo_hatch);
                                                                        }
                                                                    } else if (astring.length >= 6) {
                                                                        ry = astring.length >= 7 ? this.toFloat(astring[6], -180.0F, 180.0F) : 90.0F;
                                                                        mch_aircraftinfo_hatch = new MCH_AircraftInfo.Hatch(this.toFloat(astring[0]), this.toFloat(astring[1]), this.toFloat(astring[2]), this.toFloat(astring[3]), this.toFloat(astring[4]), this.toFloat(astring[5]), ry, "hatch" + this.hatchList.size(), flag5);
                                                                        this.hatchList.add(mch_aircraftinfo_hatch);
                                                                    }
                                                                }
                                                            } else {
                                                                flag5 = item.equalsIgnoreCase("AddPartSlideWeaponBay");
                                                                astring = data.split("\\s*,\\s*");
                                                                vec3 = null;
                                                                MCH_AircraftInfo.WeaponBay mch_aircraftinfo_weaponbay;

                                                                if (flag5) {
                                                                    if (astring.length >= 4) {
                                                                        mch_aircraftinfo_weaponbay = new MCH_AircraftInfo.WeaponBay(astring[0].trim().toLowerCase(), this.toFloat(astring[1]), this.toFloat(astring[2]), this.toFloat(astring[3]), 0.0F, 0.0F, 0.0F, 90.0F, "wb" + this.partWeaponBay.size(), flag5);
                                                                        this.partWeaponBay.add(mch_aircraftinfo_weaponbay);
                                                                    }
                                                                } else if (astring.length >= 7) {
                                                                    ry = astring.length >= 8 ? this.toFloat(astring[7], -180.0F, 180.0F) : 90.0F;
                                                                    mch_aircraftinfo_weaponbay = new MCH_AircraftInfo.WeaponBay(astring[0].trim().toLowerCase(), this.toFloat(astring[1]), this.toFloat(astring[2]), this.toFloat(astring[3]), this.toFloat(astring[4]), this.toFloat(astring[5]), this.toFloat(astring[6]), ry / 90.0F, "wb" + this.partWeaponBay.size(), flag5);
                                                                    this.partWeaponBay.add(mch_aircraftinfo_weaponbay);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        this.isShapedRecipe = item.compareTo("addrecipe") == 0;
                                                        this.recipeString.add(data.toUpperCase());
                                                    }
                                                } else {
                                                    s = data.split("\\s*,\\s*");
                                                    if (s.length >= 7) {
                                                        f1 = 0.0F;
                                                        f2 = 0.0F;
                                                        ry = 0.0F;
                                                        rz = 0.0F;
                                                        flag2 = item.equalsIgnoreCase("AddPartRotWeapon") || item.equalsIgnoreCase("AddPartTurretRotWeapon");
                                                        flag = item.equalsIgnoreCase("AddPartWeaponMissile");
                                                        flag3 = item.equalsIgnoreCase("AddPartTurretWeapon") || item.equalsIgnoreCase("AddPartTurretRotWeapon");
                                                        if (flag2) {
                                                            f1 = s.length >= 10 ? this.toFloat(s[7]) : 0.0F;
                                                            f2 = s.length >= 10 ? this.toFloat(s[8]) : 0.0F;
                                                            ry = s.length >= 10 ? this.toFloat(s[9]) : -1.0F;
                                                        } else {
                                                            rz = s.length >= 8 ? this.toFloat(s[7]) : 0.0F;
                                                        }

                                                        MCH_AircraftInfo.PartWeapon mch_aircraftinfo_partweapon = new MCH_AircraftInfo.PartWeapon(this.splitParamSlash(s[0].toLowerCase().trim()), flag2, flag, this.toBool(s[1]), this.toBool(s[2]), this.toBool(s[3]), this.toFloat(s[4]), this.toFloat(s[5]), this.toFloat(s[6]), "weapon" + this.partWeapon.size(), f1, f2, ry, rz, flag3);

                                                        this.lastWeaponPart = mch_aircraftinfo_partweapon;
                                                        this.partWeapon.add(mch_aircraftinfo_partweapon);
                                                    }
                                                }
                                            } else {
                                                s = data.split("\\s*,\\s*");
                                                String s1 = s[0].toLowerCase();

                                                if (s.length >= 4 && MCH_WeaponInfoManager.contains(s1)) {
                                                    f2 = s.length >= 5 ? this.toFloat(s[4]) : 0.0F;
                                                    ry = s.length >= 6 ? this.toFloat(s[5]) : 0.0F;
                                                    flag1 = s.length >= 7 ? this.toBool(s[6]) : true;
                                                    px = s.length >= 8 ? this.toInt(s[7], 1, this.getInfo_MaxSeatNum()) - 1 : 0;
                                                    if (px <= 0) {
                                                        flag1 = true;
                                                    }

                                                    py = s.length >= 9 ? this.toFloat(s[8]) : 0.0F;
                                                    py = MathHelper.wrapAngleTo180_float(py);
                                                    pz = s.length >= 10 ? this.toFloat(s[9]) : 0.0F;
                                                    w = s.length >= 11 ? this.toFloat(s[10]) : 0.0F;
                                                    float f3 = s.length >= 12 ? this.toFloat(s[11]) : 0.0F;
                                                    float f4 = s.length >= 13 ? this.toFloat(s[12]) : 0.0F;
                                                    MCH_AircraftInfo.Weapon e = new MCH_AircraftInfo.Weapon(this.toFloat(s[1]), this.toFloat(s[2]), this.toFloat(s[3]), f2, ry, flag1, px, py, pz, w, f3, f4, item.equalsIgnoreCase("AddTurretWeapon"));

                                                    if (s1.compareTo(this.lastWeaponType) != 0) {
                                                        this.weaponSetList.add(new MCH_AircraftInfo.WeaponSet(s1));
                                                        ++this.lastWeaponIndex;
                                                        this.lastWeaponType = s1;
                                                    }

                                                    ((MCH_AircraftInfo.WeaponSet) this.weaponSetList.get(this.lastWeaponIndex)).weapons.add(e);
                                                }
                                            }
                                        }
                                    } else {
                                        if (this.seatList.size() >= this.getInfo_MaxSeatNum()) {
                                            return;
                                        }

                                        s = this.splitParam(data);
                                        if (s.length < 3) {
                                            return;
                                        }

                                        vec3 = this.toVec3(s[0], s[1], s[2]);
                                        MCH_SeatInfo mch_seatinfo;

                                        if (item.equalsIgnoreCase("AddSeat")) {
                                            boolean flag7 = s.length >= 4 ? this.toBool(s[3]) : false;

                                            mch_seatinfo = new MCH_SeatInfo(vec3, flag7);
                                            this.seatList.add(mch_seatinfo);
                                        } else {
                                            if (s.length >= 6) {
                                                MCH_AircraftInfo.CameraPosition mch_aircraftinfo_cameraposition = new MCH_AircraftInfo.CameraPosition(this.toVec3(s[3], s[4], s[5]));

                                                flag1 = s.length >= 7 ? this.toBool(s[6]) : false;
                                                if (item.equalsIgnoreCase("AddGunnerSeat")) {
                                                    if (s.length >= 9) {
                                                        f = this.toFloat(s[7], -90.0F, 90.0F);
                                                        py = this.toFloat(s[8], -90.0F, 90.0F);
                                                        if (f > py) {
                                                            pz = f;
                                                            f = py;
                                                            py = pz;
                                                        }

                                                        flag3 = s.length >= 10 ? this.toBool(s[9]) : false;
                                                        mch_seatinfo = new MCH_SeatInfo(vec3, true, mch_aircraftinfo_cameraposition, true, flag1, false, 0.0F, 0.0F, f, py, flag3);
                                                    } else {
                                                        mch_seatinfo = new MCH_SeatInfo(vec3, true, mch_aircraftinfo_cameraposition, true, flag1, false, 0.0F, 0.0F, false);
                                                    }
                                                } else {
                                                    flag2 = s.length >= 9;
                                                    py = flag2 ? this.toFloat(s[7]) : 0.0F;
                                                    pz = flag2 ? this.toFloat(s[8]) : 0.0F;
                                                    boolean flag8 = s.length >= 10 ? this.toBool(s[9]) : false;

                                                    mch_seatinfo = new MCH_SeatInfo(vec3, true, mch_aircraftinfo_cameraposition, true, flag1, flag2, py, pz, flag8);
                                                }
                                            } else {
                                                mch_seatinfo = new MCH_SeatInfo(vec3, true, new MCH_AircraftInfo.CameraPosition(), false, false, false, 0.0F, 0.0F, false);
                                            }

                                            this.seatList.add(mch_seatinfo);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        s = this.splitParam(data);
                        if (s.length >= 7) {
                            df = this.toVec3(s[0], s[1], s[2]);
                            c = this.hex2dec(s[3]);
                            i = this.hex2dec(s[4]);
                            rz = this.toFloat(s[5]);
                            f = this.toFloat(s[6]);
                            py = s.length >= 8 ? this.toFloat(s[7]) : 0.0F;
                            pz = s.length >= 9 ? this.toFloat(s[8]) : 0.0F;
                            w = s.length >= 10 ? this.toFloat(s[9]) : 0.0F;
                            boolean mnp = !item.equalsIgnoreCase("AddSearchLight");
                            boolean mxp = item.equalsIgnoreCase("AddSteeringSearchLight");

                            this.searchLights.add(new MCH_AircraftInfo.SearchLight(df, c, i, rz, f, mnp, py, pz, mxp, w));
                        }
                    }
                }
            }
        }

    }

    public MCH_AircraftInfo.CrawlerTrack createCrawlerTrack(String data, String name) {
        String[] s = this.splitParam(data);
        int PC = s.length - 3;
        boolean REV = this.toBool(s[0]);
        float LEN = this.toFloat(s[1], 0.001F, 1000.0F) * 0.9F;
        float Z = this.toFloat(s[2]);

        if (PC < 4) {
            return null;
        } else {
            double[] cx = new double[PC];
            double[] cy = new double[PC];

            for (int lp = 0; lp < PC; ++lp) {
                int dist = !REV ? lp : PC - lp - 1;
                String[] xy = this.splitParamSlash(s[3 + dist]);

                cx[lp] = (double) this.toFloat(xy[0]);
                cy[lp] = (double) this.toFloat(xy[1]);
            }

            ArrayList arraylist = new ArrayList();

            arraylist.add(new MCH_AircraftInfo.CrawlerTrackPrm((float) cx[0], (float) cy[0]));
            double d0 = 0.0D;

            int c;

            for (c = 0; c < PC; ++c) {
                double pp = cx[(c + 1) % PC] - cx[c];
                double np = cy[(c + 1) % PC] - cy[c];

                d0 += Math.sqrt(pp * pp + np * np);
                double nr = d0;

                for (int nnr = 1; d0 >= (double) LEN; ++nnr) {
                    arraylist.add(new MCH_AircraftInfo.CrawlerTrackPrm((float) (cx[c] + pp * ((double) (LEN * (float) nnr) / nr)), (float) (cy[c] + np * ((double) (LEN * (float) nnr) / nr))));
                    d0 -= (double) LEN;
                }
            }

            for (c = 0; c < arraylist.size(); ++c) {
                MCH_AircraftInfo.CrawlerTrackPrm mch_aircraftinfo_crawlertrackprm = (MCH_AircraftInfo.CrawlerTrackPrm) arraylist.get((c + arraylist.size() - 1) % arraylist.size());
                MCH_AircraftInfo.CrawlerTrackPrm cp = (MCH_AircraftInfo.CrawlerTrackPrm) arraylist.get(c);
                MCH_AircraftInfo.CrawlerTrackPrm mch_aircraftinfo_crawlertrackprm1 = (MCH_AircraftInfo.CrawlerTrackPrm) arraylist.get((c + 1) % arraylist.size());
                float pr = (float) (Math.atan2((double) (mch_aircraftinfo_crawlertrackprm.x - cp.x), (double) (mch_aircraftinfo_crawlertrackprm.y - cp.y)) * 180.0D / 3.141592653589793D);
                float f = (float) (Math.atan2((double) (mch_aircraftinfo_crawlertrackprm1.x - cp.x), (double) (mch_aircraftinfo_crawlertrackprm1.y - cp.y)) * 180.0D / 3.141592653589793D);
                float ppr = (pr + 360.0F) % 360.0F;
                float f1 = f + 180.0F;

                if (((double) f1 < (double) ppr - 0.3D || (double) f1 > (double) ppr + 0.3D) && f1 - ppr < 100.0F && f1 - ppr > -100.0F) {
                    f1 = (f1 + ppr) / 2.0F;
                }

                cp.r = f1;
            }

            MCH_AircraftInfo.CrawlerTrack mch_aircraftinfo_crawlertrack = new MCH_AircraftInfo.CrawlerTrack(name);

            mch_aircraftinfo_crawlertrack.len = LEN;
            mch_aircraftinfo_crawlertrack.cx = cx;
            mch_aircraftinfo_crawlertrack.cy = cy;
            mch_aircraftinfo_crawlertrack.lp = arraylist;
            mch_aircraftinfo_crawlertrack.z = Z;
            mch_aircraftinfo_crawlertrack.side = Z >= 0.0F ? 1 : 0;
            return mch_aircraftinfo_crawlertrack;
        }
    }

    public String getTextureName() {
        String s = (String) this.textureNameList.get(this.textureCount);

        this.textureCount = (this.textureCount + 1) % this.textureNameList.size();
        return s;
    }

    public String getNextTextureName(String base) {
        if (this.textureNameList.size() >= 2) {
            for (int i = 0; i < this.textureNameList.size(); ++i) {
                String s = (String) this.textureNameList.get(i);

                if (s.equalsIgnoreCase(base)) {
                    i = (i + 1) % this.textureNameList.size();
                    return (String) this.textureNameList.get(i);
                }
            }
        }

        return base;
    }

    public void preReload() {
        this.textureNameList.clear();
        this.textureNameList.add(this.name);
        this.cameraList.clear();
        this.cameraPosition.clear();
        this.canopyList.clear();
        this.flare = new MCH_AircraftInfo.Flare();
        this.hatchList.clear();
        this.hudList.clear();
        this.landingGear.clear();
        this.particleSplashs.clear();
        this.searchLights.clear();
        this.partThrottle.clear();
        this.partRotPart.clear();
        this.partCrawlerTrack.clear();
        this.partTrackRoller.clear();
        this.partWheel.clear();
        this.partSteeringWheel.clear();
        this.lightHatchList.clear();
        this.partWeapon.clear();
        this.partWeaponBay.clear();
        this.repellingHooks.clear();
        this.rideRacks.clear();
        this.seatList.clear();
        this.exclusionSeatList.clear();
        this.entityRackList.clear();
        this.extraBoundingBox.clear();
        this.weaponSetList.clear();
        this.lastWeaponIndex = -1;
        this.lastWeaponType = "";
        this.lastWeaponPart = null;
        this.wheels.clear();
        this.unmountPosition = null;
    }

    public static String[] getCannotReloadItem() {
        return new String[] { "DisplayName", "AddDisplayName", "ItemID", "AddRecipe", "AddShapelessRecipe", "InventorySize", "Sound", "UAV", "SmallUAV", "TargetDrone", "Category"};
    }

    public boolean canReloadItem(String item) {
        String[] ignoreItems = getCannotReloadItem();
        String[] arr$ = ignoreItems;
        int len$ = ignoreItems.length;

        for (int i$ = 0; i$ < len$; ++i$) {
            String s = arr$[i$];

            if (s.equalsIgnoreCase(item)) {
                return false;
            }
        }

        return true;
    }

    public class CameraPosition {

        public final Vec3 pos;
        public final boolean fixRot;
        public final float yaw;
        public final float pitch;

        public CameraPosition(Vec3 vec3, boolean fixRot, float yaw, float pitch) {
            this.pos = vec3;
            this.fixRot = fixRot;
            this.yaw = yaw;
            this.pitch = pitch;
        }

        public CameraPosition(Vec3 vec3) {
            this(vec3, false, 0.0F, 0.0F);
        }

        public CameraPosition() {
            this(Vec3.createVectorHelper(0.0D, 0.0D, 0.0D));
        }
    }

    public class RotPart extends MCH_AircraftInfo.DrawnPart {

        public final float rotSpeed;
        public final boolean rotAlways;

        public RotPart(float px, float py, float pz, float rx, float ry, float rz, float mr, boolean a, String name) {
            super(px, py, pz, rx, ry, rz, name);
            this.rotSpeed = mr;
            this.rotAlways = a;
        }
    }

    public class WeaponBay extends MCH_AircraftInfo.DrawnPart {

        public final float maxRotFactor;
        public final boolean isSlide;
        private final String weaponName;
        public Integer[] weaponIds;

        public WeaponBay(String wn, float px, float py, float pz, float rx, float ry, float rz, float mr, String name, boolean slide) {
            super(px, py, pz, rx, ry, rz, name);
            this.maxRotFactor = mr;
            this.isSlide = slide;
            this.weaponName = wn;
            this.weaponIds = new Integer[0];
        }
    }

    public class PartWeaponChild extends MCH_AircraftInfo.DrawnPart {

        public final String[] name;
        public final boolean yaw;
        public final boolean pitch;
        public final float recoilBuf;

        public PartWeaponChild(String[] name, boolean y, boolean p, float px, float py, float pz, String modelName, float rx, float ry, float rz, float rb) {
            super(px, py, pz, rx, ry, rz, modelName);
            this.name = name;
            this.yaw = y;
            this.pitch = p;
            this.recoilBuf = rb;
        }
    }

    public class PartWeapon extends MCH_AircraftInfo.DrawnPart {

        public final String[] name;
        public final boolean rotBarrel;
        public final boolean isMissile;
        public final boolean hideGM;
        public final boolean yaw;
        public final boolean pitch;
        public final float recoilBuf;
        public List child;
        public final boolean turret;

        public PartWeapon(String[] name, boolean rotBrl, boolean missile, boolean hgm, boolean y, boolean p, float px, float py, float pz, String modelName, float rx, float ry, float rz, float rb, boolean turret) {
            super(px, py, pz, rx, ry, rz, modelName);
            this.name = name;
            this.rotBarrel = rotBrl;
            this.isMissile = missile;
            this.hideGM = hgm;
            this.yaw = y;
            this.pitch = p;
            this.recoilBuf = rb;
            this.child = new ArrayList();
            this.turret = turret;
        }
    }

    public class Canopy extends MCH_AircraftInfo.DrawnPart {

        public final float maxRotFactor;
        public final boolean isSlide;

        public Canopy(float px, float py, float pz, float rx, float ry, float rz, float mr, String name, boolean slide) {
            super(px, py, pz, rx, ry, rz, name);
            this.maxRotFactor = mr;
            this.isSlide = slide;
        }
    }

    public class LandingGear extends MCH_AircraftInfo.DrawnPart {

        public Vec3 slide = null;
        public final float maxRotFactor;
        public boolean enableRot2;
        public Vec3 rot2;
        public float maxRotFactor2;
        public final boolean reverse;
        public final boolean hatch;

        public LandingGear(float x, float y, float z, float rx, float ry, float rz, String model, float maxRotF, boolean rev, boolean isHatch) {
            super(x, y, z, rx, ry, rz, model);
            this.maxRotFactor = maxRotF;
            this.enableRot2 = false;
            this.rot2 = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
            this.maxRotFactor2 = 0.0F;
            this.reverse = rev;
            this.hatch = isHatch;
        }
    }

    public class Throttle extends MCH_AircraftInfo.DrawnPart {

        public final Vec3 slide;
        public final float rot2;

        public Throttle(float px, float py, float pz, float rx, float ry, float rz, float rot, String name, float px2, float py2, float pz2) {
            super(px, py, pz, rx, ry, rz, name);
            this.rot2 = rot;
            this.slide = Vec3.createVectorHelper((double) px2, (double) py2, (double) pz2);
        }
    }

    public class Camera extends MCH_AircraftInfo.DrawnPart {

        public final boolean yawSync;
        public final boolean pitchSync;

        public Camera(float px, float py, float pz, float rx, float ry, float rz, String name, boolean ys, boolean ps) {
            super(px, py, pz, rx, ry, rz, name);
            this.yawSync = ys;
            this.pitchSync = ps;
        }
    }

    public class CrawlerTrack extends MCH_AircraftInfo.DrawnPart {

        public float len = 0.35F;
        public double[] cx;
        public double[] cy;
        public List lp;
        public float z;
        public int side;

        public CrawlerTrack(String name) {
            super(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, name);
        }
    }

    public class CrawlerTrackPrm {

        float x;
        float y;
        float nx;
        float ny;
        float r;

        public CrawlerTrackPrm(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }

    public class TrackRoller extends MCH_AircraftInfo.DrawnPart {

        final int side;

        public TrackRoller(float px, float py, float pz, String name) {
            super(px, py, pz, 0.0F, 0.0F, 0.0F, name);
            this.side = px >= 0.0F ? 1 : 0;
        }
    }

    public class PartWheel extends MCH_AircraftInfo.DrawnPart {

        final float rotDir;
        final Vec3 pos2;

        public PartWheel(float px, float py, float pz, float rx, float ry, float rz, float rd, float px2, float py2, float pz2, String name) {
            super(px, py, pz, rx, ry, rz, name);
            this.rotDir = rd;
            this.pos2 = Vec3.createVectorHelper((double) px2, (double) py2, (double) pz2);
        }

        public PartWheel(float px, float py, float pz, float rx, float ry, float rz, float rd, String name) {
            this(px, py, pz, rx, ry, rz, rd, px, py, pz, name);
        }
    }

    public class Hatch extends MCH_AircraftInfo.DrawnPart {

        public final float maxRotFactor;
        public final float maxRot;
        public final boolean isSlide;

        public Hatch(float px, float py, float pz, float rx, float ry, float rz, float mr, String name, boolean slide) {
            super(px, py, pz, rx, ry, rz, name);
            this.maxRot = mr;
            this.maxRotFactor = this.maxRot / 90.0F;
            this.isSlide = slide;
        }
    }

    public class DrawnPart {

        public final Vec3 pos;
        public final Vec3 rot;
        public final String modelName;
        public IModelCustom model;

        public DrawnPart(float px, float py, float pz, float rx, float ry, float rz, String name) {
            this.pos = Vec3.createVectorHelper((double) px, (double) py, (double) pz);
            this.rot = Vec3.createVectorHelper((double) rx, (double) ry, (double) rz);
            this.modelName = name;
            this.model = null;
        }
    }

    public class Weapon {

        public final Vec3 pos;
        public final float yaw;
        public final float pitch;
        public final boolean canUsePilot;
        public final int seatID;
        public final float defaultYaw;
        public final float minYaw;
        public final float maxYaw;
        public final float minPitch;
        public final float maxPitch;
        public final boolean turret;

        public Weapon(float x, float y, float z, float yaw, float pitch, boolean canPirot, int seatId, float defy, float mny, float mxy, float mnp, float mxp, boolean turret) {
            this.pos = Vec3.createVectorHelper((double) x, (double) y, (double) z);
            this.yaw = yaw;
            this.pitch = pitch;
            this.canUsePilot = canPirot;
            this.seatID = seatId;
            this.defaultYaw = defy;
            this.minYaw = mny;
            this.maxYaw = mxy;
            this.minPitch = mnp;
            this.maxPitch = mxp;
            this.turret = turret;
        }
    }

    public class WeaponSet {

        public final String type;
        public ArrayList weapons;

        public WeaponSet(String t) {
            this.type = t;
            this.weapons = new ArrayList();
        }
    }

    public class RepellingHook {

        final Vec3 pos;
        final int interval;

        public RepellingHook(Vec3 pos, int inv) {
            this.pos = pos;
            this.interval = inv;
        }
    }

    public class ParticleSplash {

        public final int num;
        public final float acceleration;
        public final float size;
        public final Vec3 pos;
        public final int age;
        public final float motionY;
        public final float gravity;

        public ParticleSplash(Vec3 v, int nm, float siz, float acc, int ag, float my, float gr) {
            this.num = nm;
            this.pos = v;
            this.size = siz;
            this.acceleration = acc;
            this.age = ag;
            this.motionY = my;
            this.gravity = gr;
        }
    }

    public class RideRack {

        public final String name;
        public final int rackID;

        public RideRack(String n, int id) {
            this.name = n;
            this.rackID = id;
        }
    }

    public class SearchLight {

        public final int colorStart;
        public final int colorEnd;
        public final Vec3 pos;
        public final float height;
        public final float width;
        public final float angle;
        public final boolean fixDir;
        public final float yaw;
        public final float pitch;
        public final boolean steering;
        public final float stRot;

        public SearchLight(Vec3 pos, int cs, int ce, float h, float w, boolean fix, float y, float p, boolean st, float stRot) {
            this.colorStart = cs;
            this.colorEnd = ce;
            this.pos = pos;
            this.height = h;
            this.width = w;
            this.angle = (float) (Math.atan2((double) (w / 2.0F), (double) h) * 180.0D / 3.141592653589793D);
            this.fixDir = fix;
            this.steering = st;
            this.yaw = y;
            this.pitch = p;
            this.stRot = stRot;
        }
    }

    public class Flare {

        public int[] types = new int[0];
        public Vec3 pos = Vec3.createVectorHelper(0.0D, 0.0D, 0.0D);
    }

    public class Wheel {

        public final float size;
        public final Vec3 pos;

        public Wheel(Vec3 v, float sz) {
            this.pos = v;
            this.size = sz;
        }

        public Wheel(Vec3 v) {
            this(v, 1.0F);
        }
    }
}

package mcheli.aircraft;

public interface MCH_IEntityCanRideAircraft {

    boolean isSkipNormalRender();

    boolean canRideAircraft(MCH_EntityAircraft mch_entityaircraft, int i, MCH_SeatRackInfo mch_seatrackinfo);
}

package mcheli.aircraft;

import mcheli.MCH_Lib;
import mcheli.parachute.MCH_ItemParachute;
import mcheli.uav.MCH_EntityUavStation;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class MCH_AircraftGuiContainer extends Container {

    public final EntityPlayer player;
    public final MCH_EntityAircraft aircraft;

    public MCH_AircraftGuiContainer(EntityPlayer player, MCH_EntityAircraft ac) {
        this.player = player;
        this.aircraft = ac;
        MCH_AircraftInventory iv = this.aircraft.getGuiInventory();

        iv.getClass();
        this.addSlotToContainer(new Slot(iv, 0, 10, 30));
        iv.getClass();
        this.addSlotToContainer(new Slot(iv, 1, 10, 48));
        iv.getClass();
        this.addSlotToContainer(new Slot(iv, 2, 10, 66));
        int num = this.aircraft.getNumEjectionSeat();

        int x;

        for (x = 0; x < num; ++x) {
            iv.getClass();
            this.addSlotToContainer(new Slot(iv, 3 + x, 10 + 18 * x, 105));
        }

        for (x = 0; x < 3; ++x) {
            for (int x1 = 0; x1 < 9; ++x1) {
                this.addSlotToContainer(new Slot(player.inventory, 9 + x1 + x * 9, 25 + x1 * 18, 135 + x * 18));
            }
        }

        for (x = 0; x < 9; ++x) {
            this.addSlotToContainer(new Slot(player.inventory, x, 25 + x * 18, 195));
        }

    }

    public int getInventoryStartIndex() {
        return this.aircraft == null ? 3 : 3 + this.aircraft.getNumEjectionSeat();
    }

    public void detectAndSendChanges() {
        super.detectAndSendChanges();
    }

    public boolean canInteractWith(EntityPlayer player) {
        if (this.aircraft.getGuiInventory().isUseableByPlayer(player)) {
            return true;
        } else {
            if (this.aircraft.isUAV()) {
                MCH_EntityUavStation us = this.aircraft.getUavStation();

                if (us != null) {
                    double x = us.posX + (double) us.posUavX;
                    double z = us.posZ + (double) us.posUavZ;

                    if (this.aircraft.posX < x + 10.0D && this.aircraft.posX > x - 10.0D && this.aircraft.posZ < z + 10.0D && this.aircraft.posZ > z - 10.0D) {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    public ItemStack transferStackInSlot(EntityPlayer player, int slotIndex) {
        MCH_AircraftInventory iv = this.aircraft.getGuiInventory();
        Slot slot = (Slot) this.inventorySlots.get(slotIndex);

        if (slot == null) {
            return null;
        } else {
            ItemStack itemStack = slot.getStack();

            MCH_Lib.DbgLog(player.worldObj, "transferStackInSlot : %d :" + itemStack, new Object[] { Integer.valueOf(slotIndex)});
            if (itemStack == null) {
                return null;
            } else {
                int num;

                if (slotIndex < this.getInventoryStartIndex()) {
                    for (num = this.getInventoryStartIndex(); num < this.inventorySlots.size(); ++num) {
                        Slot i = (Slot) this.inventorySlots.get(num);

                        if (i.getStack() == null) {
                            i.putStack(itemStack);
                            slot.putStack((ItemStack) null);
                            return itemStack;
                        }
                    }
                } else if (itemStack.getItem() instanceof MCH_ItemFuel) {
                    for (num = 0; num < 3; ++num) {
                        if (iv.getFuelSlotItemStack(num) == null) {
                            iv.getClass();
                            iv.setInventorySlotContents(0 + num, itemStack);
                            slot.putStack((ItemStack) null);
                            return itemStack;
                        }
                    }
                } else if (itemStack.getItem() instanceof MCH_ItemParachute) {
                    num = this.aircraft.getNumEjectionSeat();

                    for (int i = 0; i < num; ++i) {
                        if (iv.getParachuteSlotItemStack(i) == null) {
                            iv.getClass();
                            iv.setInventorySlotContents(3 + i, itemStack);
                            slot.putStack((ItemStack) null);
                            return itemStack;
                        }
                    }
                }

                return null;
            }
        }
    }

    public void onContainerClosed(EntityPlayer player) {
        super.onContainerClosed(player);
        if (!player.worldObj.isRemote) {
            MCH_AircraftInventory iv = this.aircraft.getGuiInventory();

            int i;
            ItemStack is;

            for (i = 0; i < 3; ++i) {
                is = iv.getFuelSlotItemStack(i);
                if (is != null && !(is.getItem() instanceof MCH_ItemFuel)) {
                    iv.getClass();
                    this.dropPlayerItem(player, 0 + i);
                }
            }

            for (i = 0; i < 2; ++i) {
                is = iv.getParachuteSlotItemStack(i);
                if (is != null && !(is.getItem() instanceof MCH_ItemParachute)) {
                    iv.getClass();
                    this.dropPlayerItem(player, 3 + i);
                }
            }
        }

    }

    public void dropPlayerItem(EntityPlayer player, int slotID) {
        if (!player.worldObj.isRemote) {
            ItemStack itemstack = this.aircraft.getGuiInventory().getStackInSlotOnClosing(slotID);

            if (itemstack != null) {
                player.dropPlayerItemWithRandomChoice(itemstack, false);
            }
        }

    }
}

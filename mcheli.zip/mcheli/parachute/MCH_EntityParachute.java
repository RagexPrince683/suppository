package mcheli.parachute;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import mcheli.MCH_Lib;
import mcheli.particles.MCH_ParticleParam;
import mcheli.particles.MCH_ParticlesUtil;
import mcheli.wrapper.W_AxisAlignedBB;
import mcheli.wrapper.W_Block;
import mcheli.wrapper.W_Entity;
import mcheli.wrapper.W_Lib;
import mcheli.wrapper.W_WorldFunc;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class MCH_EntityParachute extends W_Entity {

    private double speedMultiplier;
    private int paraPosRotInc;
    private double paraX;
    private double paraY;
    private double paraZ;
    private double paraYaw;
    private double paraPitch;
    @SideOnly(Side.CLIENT)
    private double velocityX;
    @SideOnly(Side.CLIENT)
    private double velocityY;
    @SideOnly(Side.CLIENT)
    private double velocityZ;
    public Entity user;
    public int onGroundCount;

    public MCH_EntityParachute(World par1World) {
        super(par1World);
        this.speedMultiplier = 0.07D;
        this.preventEntitySpawning = true;
        this.setSize(1.5F, 0.6F);
        this.yOffset = this.height / 2.0F;
        this.user = null;
        this.onGroundCount = 0;
    }

    public MCH_EntityParachute(World par1World, double par2, double par4, double par6) {
        this(par1World);
        this.setPosition(par2, par4 + (double) this.yOffset, par6);
        this.motionX = 0.0D;
        this.motionY = 0.0D;
        this.motionZ = 0.0D;
        this.prevPosX = par2;
        this.prevPosY = par4;
        this.prevPosZ = par6;
    }

    protected boolean canTriggerWalking() {
        return false;
    }

    protected void entityInit() {
        this.getDataWatcher().addObject(31, Byte.valueOf((byte) 0));
    }

    public void setType(int n) {
        this.getDataWatcher().updateObject(31, Byte.valueOf((byte) n));
    }

    public int getType() {
        return this.getDataWatcher().getWatchableObjectByte(31);
    }

    public AxisAlignedBB getCollisionBox(Entity par1Entity) {
        return par1Entity.boundingBox;
    }

    public AxisAlignedBB getBoundingBox() {
        return this.boundingBox;
    }

    public boolean canBePushed() {
        return true;
    }

    public double getMountedYOffset() {
        return (double) this.height * 0.0D - 0.30000001192092896D;
    }

    public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
        return false;
    }

    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @SideOnly(Side.CLIENT)
    public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9) {
        this.paraPosRotInc = par9 + 10;
        this.paraX = par1;
        this.paraY = par3;
        this.paraZ = par5;
        this.paraYaw = (double) par7;
        this.paraPitch = (double) par8;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }

    @SideOnly(Side.CLIENT)
    public void setVelocity(double par1, double par3, double par5) {
        this.velocityX = this.motionX = par1;
        this.velocityY = this.motionY = par3;
        this.velocityZ = this.motionZ = par5;
    }

    public void setDead() {
        super.setDead();
    }

    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.isRemote && this.ticksExisted % 10 == 0) {
            MCH_Lib.DbgLog(this.worldObj, "MCH_EntityParachute.onUpdate %d, %.3f", new Object[] { Integer.valueOf(this.ticksExisted), Double.valueOf(this.motionY)});
        }

        if (this.isOpenParachute() && this.motionY > -0.3D && this.ticksExisted > 20) {
            this.fallDistance = (float) ((double) this.fallDistance * 0.85D);
        }

        if (!this.worldObj.isRemote && this.user != null && this.user.ridingEntity == null) {
            this.user.mountEntity(this);
            this.rotationYaw = this.prevRotationYaw = this.user.rotationYaw;
            this.user = null;
        }

        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        double d1 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * 0.0D / 5.0D - 0.125D;
        double d2 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * 1.0D / 5.0D - 0.125D;
        AxisAlignedBB axisalignedbb = W_AxisAlignedBB.getAABB(this.boundingBox.minX, d1, this.boundingBox.minZ, this.boundingBox.maxX, d2, this.boundingBox.maxZ);

        if (this.worldObj.isAABBInMaterial(axisalignedbb, Material.water)) {
            this.onWaterSetBoat();
            this.setDead();
        }

        if (this.worldObj.isRemote) {
            this.onUpdateClient();
        } else {
            this.onUpdateServer();
        }

    }

    public void onUpdateClient() {
        if (this.paraPosRotInc > 0) {
            double color = this.posX + (this.paraX - this.posX) / (double) this.paraPosRotInc;
            double y = this.posY + (this.paraY - this.posY) / (double) this.paraPosRotInc;
            double z = this.posZ + (this.paraZ - this.posZ) / (double) this.paraPosRotInc;
            double yaw = MathHelper.wrapAngleTo180_double(this.paraYaw - (double) this.rotationYaw);

            this.rotationYaw = (float) ((double) this.rotationYaw + yaw / (double) this.paraPosRotInc);
            this.rotationPitch = (float) ((double) this.rotationPitch + (this.paraPitch - (double) this.rotationPitch) / (double) this.paraPosRotInc);
            --this.paraPosRotInc;
            this.setPosition(color, y, z);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            if (this.riddenByEntity != null) {
                this.setRotation(this.riddenByEntity.prevRotationYaw, this.rotationPitch);
            }
        } else {
            this.setPosition(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            if (this.onGround) {
                ;
            }

            this.motionX *= 0.99D;
            this.motionY *= 0.95D;
            this.motionZ *= 0.99D;
        }

        if (!this.isOpenParachute() && this.motionY > 0.01D) {
            float f = 0.6F + this.rand.nextFloat() * 0.2F;
            double dx = this.prevPosX - this.posX;
            double dy = this.prevPosY - this.posY;
            double dz = this.prevPosZ - this.posZ;
            int num = 1 + (int) ((double) MathHelper.sqrt_double(dx * dx + dy * dy + dz * dz) * 2.0D);

            for (double i = 0.0D; i < (double) num; ++i) {
                MCH_ParticleParam prm = new MCH_ParticleParam(this.worldObj, "smoke", this.prevPosX + (this.posX - this.prevPosX) * (i / (double) num) * 0.8D, this.prevPosY + (this.posY - this.prevPosY) * (i / (double) num) * 0.8D, this.prevPosZ + (this.posZ - this.prevPosZ) * (i / (double) num) * 0.8D);

                prm.motionX = this.motionX * 0.5D + (this.rand.nextDouble() - 0.5D) * 0.5D;
                prm.motionX = this.motionY * -0.5D + (this.rand.nextDouble() - 0.5D) * 0.5D;
                prm.motionX = this.motionZ * 0.5D + (this.rand.nextDouble() - 0.5D) * 0.5D;
                prm.size = 5.0F;
                prm.setColor(0.8F + this.rand.nextFloat(), f, f, f);
                MCH_ParticlesUtil.spawnParticle(prm);
            }
        }

    }

    public void onUpdateServer() {
        double prevSpeed = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        double gravity = this.onGround ? 0.01D : 0.03D;

        if (this.getType() == 2 && this.ticksExisted < 20) {
            gravity = 0.01D;
        }

        this.motionY -= gravity;
        double yaw;
        double dx;
        double dz;

        if (this.isOpenParachute()) {
            if (W_Lib.isEntityLivingBase(this.riddenByEntity)) {
                yaw = W_Lib.getEntityMoveDist(this.riddenByEntity);
                if (!this.isOpenParachute()) {
                    yaw = 0.0D;
                }

                if (yaw > 0.0D) {
                    dx = -Math.sin((double) (this.riddenByEntity.rotationYaw * 3.1415927F / 180.0F));
                    dz = Math.cos((double) (this.riddenByEntity.rotationYaw * 3.1415927F / 180.0F));
                    this.motionX += dx * this.speedMultiplier * 0.05D;
                    this.motionZ += dz * this.speedMultiplier * 0.05D;
                }
            }

            yaw = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (yaw > 0.35D) {
                this.motionX *= 0.35D / yaw;
                this.motionZ *= 0.35D / yaw;
                yaw = 0.35D;
            }

            if (yaw > prevSpeed && this.speedMultiplier < 0.35D) {
                this.speedMultiplier += (0.35D - this.speedMultiplier) / 35.0D;
                if (this.speedMultiplier > 0.35D) {
                    this.speedMultiplier = 0.35D;
                }
            } else {
                this.speedMultiplier -= (this.speedMultiplier - 0.07D) / 35.0D;
                if (this.speedMultiplier < 0.07D) {
                    this.speedMultiplier = 0.07D;
                }
            }
        }

        if (this.onGround) {
            ++this.onGroundCount;
            if (this.onGroundCount > 5) {
                this.onGroundAndDead();
                return;
            }
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        if (this.getType() == 2 && this.ticksExisted < 20) {
            this.motionY *= 0.95D;
        } else {
            this.motionY *= 0.9D;
        }

        if (this.isOpenParachute()) {
            this.motionX *= 0.95D;
            this.motionZ *= 0.95D;
        } else {
            this.motionX *= 0.99D;
            this.motionZ *= 0.99D;
        }

        this.rotationPitch = 0.0F;
        yaw = (double) this.rotationYaw;
        dx = this.prevPosX - this.posX;
        dz = this.prevPosZ - this.posZ;
        if (dx * dx + dz * dz > 0.001D) {
            yaw = (double) ((float) (Math.atan2(dx, dz) * 180.0D / 3.141592653589793D));
        }

        double yawDiff = MathHelper.wrapAngleTo180_double(yaw - (double) this.rotationYaw);

        if (yawDiff > 20.0D) {
            yawDiff = 20.0D;
        }

        if (yawDiff < -20.0D) {
            yawDiff = -20.0D;
        }

        if (this.riddenByEntity != null) {
            this.setRotation(this.riddenByEntity.rotationYaw, this.rotationPitch);
        } else {
            this.rotationYaw = (float) ((double) this.rotationYaw + yawDiff);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }

        List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.2D, 0.0D, 0.2D));

        if (list != null && !list.isEmpty()) {
            for (int l = 0; l < list.size(); ++l) {
                Entity entity = (Entity) list.get(l);

                if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof MCH_EntityParachute) {
                    entity.applyEntityCollision(this);
                }
            }
        }

        if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
            this.riddenByEntity = null;
            this.setDead();
        }

    }

    public void onGroundAndDead() {
        ++this.posY;
        this.updateRiderPosition();
        this.setDead();
    }

    public void onWaterSetBoat() {
        if (!this.worldObj.isRemote) {
            if (this.getType() == 2) {
                if (this.riddenByEntity != null) {
                    int px = (int) (this.posX + 0.5D);
                    int py = (int) (this.posY + 0.5D);
                    int pz = (int) (this.posZ + 0.5D);
                    boolean foundBlock = false;

                    int countWater;

                    for (countWater = 0; countWater < 5 && py + countWater >= 0 && py + countWater <= 255; ++countWater) {
                        Block size = W_WorldFunc.getBlock(this.worldObj, px, py - countWater, pz);

                        if (size == W_Block.getWater()) {
                            py -= countWater;
                            foundBlock = true;
                            break;
                        }
                    }

                    if (foundBlock) {
                        countWater = 0;
                        boolean flag = true;

                        for (int entityboat = 0; entityboat < 3 && py + entityboat >= 0 && py + entityboat <= 255; ++entityboat) {
                            int x = -2;

                            while (x <= 2) {
                                int z = -2;

                                while (true) {
                                    if (z <= 2) {
                                        label61: {
                                            Block block = W_WorldFunc.getBlock(this.worldObj, px + x, py - entityboat, pz + z);

                                            if (block == W_Block.getWater()) {
                                                ++countWater;
                                                if (countWater > 37) {
                                                    break label61;
                                                }
                                            }

                                            ++z;
                                            continue;
                                        }
                                    }

                                    ++x;
                                    break;
                                }
                            }
                        }

                        if (countWater > 37) {
                            EntityBoat entityboat = new EntityBoat(this.worldObj, (double) px, (double) ((float) py + 1.0F), (double) pz);

                            entityboat.rotationYaw = this.rotationYaw - 90.0F;
                            this.worldObj.spawnEntityInWorld(entityboat);
                            this.riddenByEntity.mountEntity(entityboat);
                        }

                    }
                }
            }
        }
    }

    public boolean isOpenParachute() {
        return this.getType() != 2 || this.motionY < -0.1D;
    }

    public void updateRiderPosition() {
        if (this.riddenByEntity != null) {
            double x = -Math.sin((double) this.rotationYaw * 3.141592653589793D / 180.0D) * 0.1D;
            double z = Math.cos((double) this.rotationYaw * 3.141592653589793D / 180.0D) * 0.1D;

            this.riddenByEntity.setPosition(this.posX + x, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ + z);
        }

    }

    protected void writeEntityToNBT(NBTTagCompound nbt) {
        nbt.setByte("ParachuteModelType", (byte) this.getType());
    }

    protected void readEntityFromNBT(NBTTagCompound nbt) {
        this.setType(nbt.getByte("ParachuteModelType"));
    }

    @SideOnly(Side.CLIENT)
    public float getShadowSize() {
        return 4.0F;
    }

    public boolean interactFirst(EntityPlayer par1EntityPlayer) {
        return false;
    }
}
